/* PromptSnap — preset preview art
 *
 * Every preset shows a small before → after illustration of what it
 * does. Nothing is a picture file: each preview is drawn here as SVG
 * from a SCENE (what is in the photo: a portrait, an aircraft, a
 * product…) and an EFFECT (what the preset changes: remove the
 * background, day to night, watercolour…). That keeps the whole library
 * a few kilobytes, crisp at any size, and consistent in style.
 *
 *   PSNAP_ART.html({ scene: "portrait", fx: "remove-bg" })
 *     → '<span class="psa">…before svg… …after svg… divider</span>'
 *
 * A spec can override either side: { scene, fx, before: {...}, after: {...} }.
 * Scenes are registered with PSNAP_ART.scene(name, draw). draw(P, o)
 * gets a palette P and the side's options o, and returns
 *   { bg, subject, extra?, face? }
 * bg/subject/extra are SVG markup in a 160×100 box; face is {x, y, r}.
 */

(() => {
  if (window.PSNAP_ART) return;

  const W = 160, H = 100;
  const scenes = {};
  let uid = 0;

  /* ------------------------------------------------------------------
     Palettes. Scenes colour themselves only from these keys, so one
     drawing works in daylight, at night, at golden hour or in snow.
     ------------------------------------------------------------------ */
  const base = {
    sun: "#ffd45a", cloud: "#ffffff",
    far: "#9cb8d6", mid: "#6aa874", near: "#4b8a57", water: "#5aa6e0", ground: "#76c07a",
    road: "#59616d", line: "#f4f6f8",
    wall: "#e9edf2", wall2: "#cfd6df", floor: "#c7cdd6", wood: "#b9875a", wood2: "#93663f",
    skin: "#f1c6a3", skin2: "#d9a07c", hair: "#3b2a22", lip: "#c9706a",
    cloth: "#2f7de1", cloth2: "#1f5fb8", cloth3: "#ff7a59", cloth4: "#2fb38a",
    metal: "#e7ecf2", metal2: "#b7c1cc", metal3: "#8c98a6",
    glass: "#9fd2ff", glass2: "#6fb6ee",
    ink: "#1f2633", paper: "#fbfaf7", light: "#ffffff",
    accent: "#ff7a59", accent2: "#14c294",
    lamp: "#ffd77a", shadow: "rgba(0,0,0,.18)", shade: "rgba(0,0,0,.10)"
  };
  const PAL = {
    day: Object.assign({}, base, { id: "day", night: false }),
    golden: Object.assign({}, base, {
      id: "golden", night: false, sun: "#ffb347",
      far: "#d8a37f", mid: "#9a9a5c", near: "#6f7a45", water: "#e8a36d", ground: "#b9b36a",
      wall: "#f6dcc0", wall2: "#e3bf9d", skin: "#f3bf92", cloth: "#3a74c9",
      metal: "#f7dfc6", metal2: "#d6b597", glass: "#ffd9a8", glass2: "#f5b97c", shadow: "rgba(90,40,0,.22)"
    }),
    sunset: Object.assign({}, base, {
      id: "sunset", night: false, sun: "#ffef9a",
      far: "#a1728f", mid: "#6e5a7c", near: "#4b3f5e", water: "#d9799a", ground: "#7a5a6e",
      wall: "#f1c9c0", wall2: "#d9a6a2", metal: "#f3cfc4", metal2: "#cfa1a6",
      glass: "#ffc1a1", glass2: "#f59d8a", shadow: "rgba(60,0,40,.25)"
    }),
    night: Object.assign({}, base, {
      id: "night", night: true, sun: "#f3f0cf", cloud: "#3a4a6a",
      far: "#2d3c5c", mid: "#233350", near: "#1a2740", water: "#1c3456", ground: "#22324a",
      road: "#2a313c", line: "#8a93a3",
      wall: "#3a4459", wall2: "#2c3446", floor: "#2b3242", wood: "#5d4634", wood2: "#46331f",
      skin: "#c79a80", skin2: "#a87a62", hair: "#20160f",
      cloth: "#2b5598", cloth2: "#1d3d72", cloth3: "#b8573e", cloth4: "#1f7a5f",
      metal: "#8f9bb0", metal2: "#66728a", metal3: "#4e5970",
      glass: "#ffd77a", glass2: "#e8b453", paper: "#d9dbe2", light: "#e9ecf3",
      shadow: "rgba(0,0,0,.35)", shade: "rgba(0,0,0,.2)"
    }),
    winter: Object.assign({}, base, {
      id: "winter", night: false, sun: "#fff6d6",
      far: "#b9c9dc", mid: "#d8e2ee", near: "#eef3f8", water: "#a9c6e0", ground: "#f4f8fb",
      road: "#8d96a3", wall: "#eef2f6", skin: "#efc6a8", cloth: "#c2413a", cloth2: "#94302b"
    })
  };

  /* ------------------------------------------------------------------
     Shared definitions — injected once per page, used by every preview.
     ------------------------------------------------------------------ */
  const sky = (id, a, b) =>
    `<linearGradient id="psa-sky-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;
  const DEFS = `
    ${sky("day", "#7fc2ff", "#dff1ff")}
    ${sky("golden", "#ff9e5e", "#ffe2a6")}
    ${sky("sunset", "#5b3f8f", "#ff9a6b")}
    ${sky("night", "#0a1430", "#24365f")}
    ${sky("winter", "#c9d9ec", "#f3f7fb")}
    <radialGradient id="psa-studio" cx=".5" cy=".42" r=".75"><stop offset="0" stop-color="#e9eef5"/><stop offset="1" stop-color="#9aa8b9"/></radialGradient>
    <radialGradient id="psa-vignette" cx=".5" cy=".5" r=".72"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></radialGradient>
    <radialGradient id="psa-flash" cx=".22" cy=".18" r=".55"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
    <linearGradient id="psa-fog" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".15"/><stop offset=".55" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity=".35"/></linearGradient>
    <linearGradient id="psa-copy" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#0b0d12" stop-opacity=".78"/><stop offset=".55" stop-color="#0b0d12" stop-opacity=".45"/><stop offset="1" stop-color="#0b0d12" stop-opacity="0"/></linearGradient>
    <pattern id="psa-checker" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="#f4f5f7"/><rect width="5" height="5" fill="#d9dde3"/><rect x="5" y="5" width="5" height="5" fill="#d9dde3"/></pattern>
    <pattern id="psa-grain" width="12" height="12" patternUnits="userSpaceOnUse"><g fill="#fff" opacity=".55"><circle cx="1.5" cy="2" r=".55"/><circle cx="7" cy="1" r=".45"/><circle cx="10.5" cy="5.5" r=".55"/><circle cx="4" cy="7" r=".5"/><circle cx="8.5" cy="10" r=".45"/><circle cx="1" cy="10.5" r=".4"/></g><g fill="#000" opacity=".45"><circle cx="5" cy="3.5" r=".5"/><circle cx="11" cy="9" r=".45"/><circle cx="2.5" cy="5" r=".4"/><circle cx="6.5" cy="11.5" r=".45"/></g></pattern>
    <pattern id="psa-rain" width="8" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(18)"><rect x="3.6" y="0" width=".8" height="6" rx=".4" fill="#dfeaff" opacity=".75"/></pattern>
    <pattern id="psa-snow" width="14" height="14" patternUnits="userSpaceOnUse"><g fill="#fff"><circle cx="2" cy="3" r="1.1"/><circle cx="9" cy="1.5" r=".8"/><circle cx="12" cy="8" r="1.2"/><circle cx="5" cy="10" r=".9"/><circle cx="8.5" cy="12.5" r=".7"/></g></pattern>
    <pattern id="psa-scan" width="4" height="3" patternUnits="userSpaceOnUse"><rect width="4" height="1" fill="#000" opacity=".28"/></pattern>
    <pattern id="psa-dots" width="5" height="5" patternUnits="userSpaceOnUse"><circle cx="2.5" cy="2.5" r="1.1" fill="#000" opacity=".22"/></pattern>
    <filter id="psa-blur1" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="1.1"/></filter>
    <filter id="psa-blur2" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="2.2"/></filter>
    <filter id="psa-blur3" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="3.6"/></filter>
    <filter id="psa-mono"><feColorMatrix type="saturate" values="0"/></filter>
    <filter id="psa-sepia"><feColorMatrix type="matrix" values=".39 .77 .19 0 .02  .35 .69 .17 0 .0  .27 .53 .13 0 -.04  0 0 0 1 0"/><feComponentTransfer><feFuncR type="linear" slope=".9" intercept=".06"/><feFuncG type="linear" slope=".88" intercept=".04"/><feFuncB type="linear" slope=".8" intercept=".02"/></feComponentTransfer></filter>
    <filter id="psa-dull"><feColorMatrix type="saturate" values=".35"/><feComponentTransfer><feFuncR type="linear" slope=".72" intercept=".12"/><feFuncG type="linear" slope=".72" intercept=".12"/><feFuncB type="linear" slope=".72" intercept=".14"/></feComponentTransfer></filter>
    <filter id="psa-dark"><feComponentTransfer><feFuncR type="linear" slope=".45"/><feFuncG type="linear" slope=".45"/><feFuncB type="linear" slope=".52"/></feComponentTransfer></filter>
    <filter id="psa-vivid"><feColorMatrix type="saturate" values="1.45"/><feComponentTransfer><feFuncR type="linear" slope="1.08" intercept="-.02"/><feFuncG type="linear" slope="1.08" intercept="-.02"/><feFuncB type="linear" slope="1.08" intercept="-.02"/></feComponentTransfer></filter>
    <filter id="psa-warm"><feColorMatrix type="matrix" values="1.08 0 0 0 .04  0 1.02 0 0 .01  0 0 .86 0 -.02  0 0 0 1 0"/></filter>
    <filter id="psa-hue"><feColorMatrix type="hueRotate" values="150"/><feColorMatrix type="saturate" values="1.2"/></filter>
    <filter id="psa-st-watercolor" x="-4%" y="-4%" width="108%" height="108%"><feTurbulence type="fractalNoise" baseFrequency=".045" numOctaves="2" seed="4" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="5" xChannelSelector="R" yChannelSelector="G"/><feGaussianBlur stdDeviation=".7"/><feColorMatrix type="saturate" values="1.15"/><feComponentTransfer><feFuncR type="linear" slope=".85" intercept=".15"/><feFuncG type="linear" slope=".85" intercept=".15"/><feFuncB type="linear" slope=".85" intercept=".15"/></feComponentTransfer></filter>
    <filter id="psa-st-oil" x="-4%" y="-4%" width="108%" height="108%"><feTurbulence type="turbulence" baseFrequency=".12" numOctaves="2" seed="2" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="3.5" xChannelSelector="R" yChannelSelector="B"/><feColorMatrix type="saturate" values="1.35"/><feComponentTransfer><feFuncR type="discrete" tableValues=".05 .25 .45 .65 .85 1"/><feFuncG type="discrete" tableValues=".05 .25 .45 .65 .85 1"/><feFuncB type="discrete" tableValues=".05 .25 .45 .65 .85 1"/></feComponentTransfer></filter>
    <filter id="psa-st-sketch" color-interpolation-filters="sRGB"><feColorMatrix type="saturate" values="0" result="g"/><feConvolveMatrix in="g" order="3" kernelMatrix="-1 -1 -1 -1 8 -1 -1 -1 -1" preserveAlpha="true" result="e"/><feComponentTransfer in="e"><feFuncR type="linear" slope="-4" intercept="1"/><feFuncG type="linear" slope="-4" intercept="1"/><feFuncB type="linear" slope="-4" intercept=".98"/></feComponentTransfer></filter>
    <filter id="psa-st-lineart" color-interpolation-filters="sRGB"><feColorMatrix type="saturate" values="0" result="g"/><feConvolveMatrix in="g" order="3" kernelMatrix="-1 -1 -1 -1 8 -1 -1 -1 -1" preserveAlpha="true" result="e"/><feComponentTransfer in="e"><feFuncR type="discrete" tableValues="1 0 0 0 0 0 0"/><feFuncG type="discrete" tableValues="1 0 0 0 0 0 0"/><feFuncB type="discrete" tableValues="1 0 0 0 0 0 0"/></feComponentTransfer></filter>
    <filter id="psa-st-anime" color-interpolation-filters="sRGB"><feColorMatrix type="saturate" values="1.5"/><feComponentTransfer><feFuncR type="discrete" tableValues=".1 .45 .8 1"/><feFuncG type="discrete" tableValues=".1 .45 .8 1"/><feFuncB type="discrete" tableValues=".15 .5 .85 1"/></feComponentTransfer></filter>
    <filter id="psa-st-pop" color-interpolation-filters="sRGB"><feColorMatrix type="hueRotate" values="40"/><feColorMatrix type="saturate" values="2.4"/><feComponentTransfer><feFuncR type="discrete" tableValues="0 .6 1"/><feFuncG type="discrete" tableValues="0 .5 1"/><feFuncB type="discrete" tableValues=".1 .6 1"/></feComponentTransfer></filter>
    <filter id="psa-st-clay" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation=".9"/><feColorMatrix type="saturate" values="1.25"/><feComponentTransfer><feFuncR type="discrete" tableValues=".18 .42 .62 .8 .95"/><feFuncG type="discrete" tableValues=".18 .42 .62 .8 .95"/><feFuncB type="discrete" tableValues=".2 .44 .64 .82 .97"/></feComponentTransfer></filter>
    <filter id="psa-st-vintage" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values=".6 .35 .1 0 .06  .3 .62 .1 0 .04  .2 .3 .45 0 .03  0 0 0 1 0"/><feGaussianBlur stdDeviation=".35"/></filter>
    <filter id="psa-st-pixel" x="0" y="0" width="100%" height="100%"><feFlood x="3" y="3" width="1" height="1"/><feComposite width="7" height="7"/><feTile result="t"/><feComposite in="SourceGraphic" in2="t" operator="in"/><feMorphology operator="dilate" radius="3.5"/></filter>
    <filter id="psa-pixel" x="0" y="0" width="100%" height="100%"><feFlood x="2" y="2" width="1" height="1"/><feComposite width="5" height="5"/><feTile result="t"/><feComposite in="SourceGraphic" in2="t" operator="in"/><feMorphology operator="dilate" radius="2.5"/></filter>
  `;
  function ensureDefs(doc) {
    doc = doc || document;
    if (doc.getElementById("psa-defs")) return;
    const s = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.id = "psa-defs";
    s.setAttribute("aria-hidden", "true");
    s.setAttribute("focusable", "false");
    s.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";
    s.innerHTML = "<defs>" + DEFS + "</defs>";
    (doc.body || doc.documentElement).appendChild(s);
  }

  /* ------------------------------------------------------------------
     Small drawing helpers shared by scenes and effects.
     ------------------------------------------------------------------ */
  const H_ = {
    W, H,
    skyFill: (P) => `url(#psa-sky-${P.id})`,
    sky: (P) => `<rect width="${W}" height="${H}" fill="url(#psa-sky-${P.id})"/>`,
    sunOrMoon: (P, x, y, r) => P.night
      ? `<circle cx="${x}" cy="${y}" r="${r}" fill="${P.sun}"/><circle cx="${x + r * .45}" cy="${y - r * .3}" r="${r * .9}" fill="#16234a"/>`
      : `<circle cx="${x}" cy="${y}" r="${r + 4}" fill="${P.sun}" opacity=".25"/><circle cx="${x}" cy="${y}" r="${r}" fill="${P.sun}"/>`,
    stars: (P) => P.night
      ? `<g fill="#fff" opacity=".85"><circle cx="18" cy="12" r=".8"/><circle cx="44" cy="22" r=".6"/><circle cx="70" cy="9" r=".7"/><circle cx="96" cy="18" r=".6"/><circle cx="138" cy="11" r=".8"/><circle cx="150" cy="27" r=".5"/><circle cx="30" cy="31" r=".5"/></g>` : "",
    cloud: (P, x, y, s = 1) => `<g fill="${P.cloud}" opacity="${P.night ? .35 : .9}" transform="translate(${x} ${y}) scale(${s})"><ellipse cx="0" cy="0" rx="11" ry="5"/><ellipse cx="8" cy="-3" rx="8" ry="6"/><ellipse cx="-7" cy="-2" rx="6" ry="4.5"/></g>`,
    shadow: (x, y, rx, ry, o = .22) => `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="#000" opacity="${o}"/>`
  };

  /* ------------------------------------------------------------------
     Replacement backgrounds (for remove/change background, studio…).
     ------------------------------------------------------------------ */
  const BG = {
    checker: () => `<rect width="${W}" height="${H}" fill="url(#psa-checker)"/>`,
    studio: () => `<rect width="${W}" height="${H}" fill="url(#psa-studio)"/>`,
    white: () => `<rect width="${W}" height="${H}" fill="#fbfcfd"/><rect y="74" width="${W}" height="26" fill="#eef1f4"/>`,
    plain: () => `<rect width="${W}" height="${H}" fill="#eef2f6"/>`,
    brand: () => `<rect width="${W}" height="${H}" fill="#5b3fd6"/><circle cx="130" cy="20" r="40" fill="#7b5cff" opacity=".6"/><circle cx="20" cy="95" r="34" fill="#ff7a9e" opacity=".45"/>`,
    beach: (P) => `${H_.sky(PAL.day)}${H_.sunOrMoon(PAL.day, 128, 22, 8)}${H_.cloud(PAL.day, 40, 20, .9)}<rect y="56" width="${W}" height="18" fill="#3fa9e6"/><rect y="60" width="${W}" height="2" fill="#fff" opacity=".5"/><path d="M0 70 Q80 64 160 70 V100 H0Z" fill="#f2d7a1"/><path d="M0 76 Q80 71 160 77" stroke="#fff" stroke-width="1.5" fill="none" opacity=".6"/>`,
    city: () => `${H_.sky(PAL.golden)}<g fill="#7d6a78"><rect x="4" y="38" width="20" height="62"/><rect x="26" y="24" width="16" height="76"/><rect x="45" y="44" width="24" height="56"/><rect x="72" y="30" width="14" height="70"/><rect x="90" y="48" width="22" height="52"/><rect x="115" y="20" width="18" height="80"/><rect x="136" y="40" width="22" height="60"/></g><g fill="#ffd9a0" opacity=".75"><rect x="30" y="30" width="3" height="3"/><rect x="36" y="38" width="3" height="3"/><rect x="119" y="28" width="3" height="3"/><rect x="125" y="40" width="3" height="3"/><rect x="50" y="52" width="3" height="3"/><rect x="58" y="60" width="3" height="3"/></g>`,
    sunset: () => `${H_.sky(PAL.sunset)}${H_.sunOrMoon(PAL.sunset, 80, 62, 13)}<path d="M0 70 Q40 60 80 68 T160 64 V100 H0Z" fill="#4b3f5e"/>`,
    room: (P) => `<rect width="${W}" height="${H}" fill="${P.wall}"/><rect x="104" y="14" width="40" height="34" rx="2" fill="${P.glass}" opacity=".8"/><path d="M124 14 V48 M104 31 H144" stroke="${P.light}" stroke-width="2"/><rect y="78" width="${W}" height="22" fill="${P.floor}"/><rect x="14" y="56" width="26" height="24" rx="3" fill="${P.cloth4}" opacity=".55"/>`,
    kitchen: (P) => `<rect width="${W}" height="${H}" fill="#f3eee6"/><g stroke="#e1d8ca" stroke-width="1"><path d="M0 20 H160 M0 40 H160 M20 0 V60 M60 0 V60 M100 0 V60 M140 0 V60"/></g><rect y="60" width="${W}" height="40" fill="#c9a67c"/><rect y="60" width="${W}" height="4" fill="#e2c49c"/><g transform="translate(20 44)"><rect width="10" height="16" rx="2" fill="#7fb38a"/><path d="M5 0 C2 -6 8 -10 5 -16" stroke="#4f8a5c" stroke-width="2" fill="none"/></g>`,
    forest: () => `${H_.sky(PAL.day)}<g fill="#3f7d4f"><path d="M10 80 L22 40 L34 80Z"/><path d="M30 80 L44 30 L58 80Z"/><path d="M110 80 L124 34 L138 80Z"/><path d="M130 80 L144 44 L158 80Z"/></g><rect y="78" width="${W}" height="22" fill="#5e9f5f"/>`
  };

  /* ------------------------------------------------------------------
     Overlays drawn on top of a finished side.
     ------------------------------------------------------------------ */
  const OVER = {
    sparkle: () => `<g fill="#fff"><path d="M138 16 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" opacity=".95"/><path d="M150 34 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2z" opacity=".8"/><path d="M18 78 l1.4 3.5 3.5 1.4 -3.5 1.4 -1.4 3.5 -1.4 -3.5 -3.5 -1.4 3.5 -1.4z" opacity=".75"/></g>`,
    grain: () => `<rect width="${W}" height="${H}" fill="url(#psa-grain)"/><rect width="${W}" height="${H}" fill="url(#psa-grain)" transform="translate(5 6)" opacity=".7"/>`,
    watermark: () => `<g opacity=".72"><g transform="rotate(-18 80 50)" fill="#fff" opacity=".7"><rect x="18" y="40" width="124" height="7" rx="3.5"/><rect x="44" y="52" width="72" height="5" rx="2.5"/></g><rect x="0" y="80" width="${W}" height="20" fill="#0b0d12" opacity=".7"/><rect x="8" y="85" width="64" height="4" rx="2" fill="#fff"/><rect x="8" y="92" width="40" height="3" rx="1.5" fill="#fff" opacity=".7"/><circle cx="146" cy="12" r="7" fill="none" stroke="#fff" stroke-width="1.6"/><path d="M148.5 9.5 a3.2 3.2 0 1 0 0 5" stroke="#fff" stroke-width="1.4" fill="none"/></g>`,
    scratches: () => `<g fill="none" stroke="#fffdf4" stroke-linecap="round" opacity=".8"><path d="M20 10 C40 30 34 60 52 92" stroke-width=".8"/><path d="M112 4 C104 30 118 58 108 98" stroke-width=".6"/><path d="M0 46 C30 44 60 52 96 46" stroke-width=".5"/></g><g fill="#fffdf4" opacity=".75"><circle cx="70" cy="22" r=".9"/><circle cx="132" cy="64" r="1.2"/><circle cx="40" cy="70" r=".7"/><circle cx="94" cy="80" r="1"/></g><path d="M160 0 V22 L136 0Z" fill="#e9dcc2"/><path d="M136 0 L160 22" stroke="#cbb994" stroke-width=".8"/><path d="M0 62 H${W}" stroke="#d8c8a8" stroke-width=".8" opacity=".5"/>`,
    cctv: () => `<rect width="${W}" height="${H}" fill="url(#psa-scan)"/><g fill="none" stroke="#fff" stroke-width="1.4" opacity=".85"><path d="M6 14 V6 H14 M146 6 H154 V14 M154 86 V94 H146 M14 94 H6 V86"/></g><circle cx="14" cy="17" r="2.2" fill="#ff3b3b"/><rect x="19" y="15.5" width="12" height="3" rx="1.5" fill="#fff" opacity=".85"/><rect x="104" y="86" width="46" height="3.5" rx="1.75" fill="#fff" opacity=".85"/>`,
    flash: () => `<rect width="${W}" height="${H}" fill="url(#psa-flash)"/>`,
    vignette: () => `<rect width="${W}" height="${H}" fill="url(#psa-vignette)"/>`,
    halftone: () => `<rect width="${W}" height="${H}" fill="url(#psa-dots)"/>`,
    paper: () => `<rect width="${W}" height="${H}" fill="#f7f1e3" opacity=".25"/>`,
    // on the right, so it shows on the "after" half of a split
    copyspace: () => `<rect width="${W}" height="${H}" fill="url(#psa-copy)" transform="translate(${W} 0) scale(-1 1)"/><g fill="#fff"><rect x="102" y="34" width="46" height="7" rx="3.5" opacity=".95"/><rect x="114" y="46" width="34" height="5" rx="2.5" opacity=".6"/><rect x="124" y="62" width="24" height="9" rx="4.5" fill="#14c294"/></g>`,
    swatches: () => `<g stroke="#fff" stroke-width="1.5"><circle cx="112" cy="86" r="6" fill="#ff7a59"/><circle cx="125" cy="86" r="6" fill="#ffd45a"/><circle cx="138" cy="86" r="6" fill="#14c294"/><circle cx="151" cy="86" r="6" fill="#5b3fd6"/></g>`,
    fog: () => `<rect width="${W}" height="${H}" fill="url(#psa-fog)"/>`,
    rain: () => `<rect width="${W}" height="${H}" fill="#24344f" opacity=".25"/><rect width="${W}" height="${H}" fill="url(#psa-rain)"/>`,
    snow: () => `<rect width="${W}" height="${H}" fill="#fff" opacity=".12"/><rect width="${W}" height="${H}" fill="url(#psa-snow)"/>`,
    bokeh: () => `<g fill="#fff"><circle cx="22" cy="20" r="7" opacity=".28"/><circle cx="44" cy="36" r="4" opacity=".22"/><circle cx="128" cy="18" r="9" opacity=".22"/><circle cx="146" cy="40" r="5" opacity=".3"/><circle cx="112" cy="34" r="3.5" opacity=".25"/><circle cx="14" cy="52" r="5" opacity=".2"/></g><g fill="#ffd77a"><circle cx="34" cy="14" r="5" opacity=".25"/><circle cx="138" cy="56" r="6" opacity=".22"/></g>`,
    thumb: () => `<rect width="${W}" height="${H}" fill="url(#psa-vignette)"/><rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="6" fill="none" stroke="#fff" stroke-width="2.5" opacity=".9"/>`,
    raw: () => `<rect width="${W}" height="${H}" fill="url(#psa-flash)"/>`,
    shadowFloor: () => H_.shadow(80, 86, 34, 4, .25)
  };

  /* A text card: the "story" or the prompt you start from. */
  function docCard(kind) {
    if (kind === "prompt") {
      return `<rect width="${W}" height="${H}" fill="#e9eef5"/><rect x="18" y="26" width="124" height="48" rx="10" fill="#fff" stroke="#cfd7e2"/>
        <g fill="#c3cbd6"><rect x="30" y="38" width="74" height="5" rx="2.5"/><rect x="30" y="49" width="96" height="5" rx="2.5"/><rect x="30" y="60" width="52" height="5" rx="2.5"/></g>
        <rect x="85" y="58.5" width="1.6" height="8" fill="#14c294"/><circle cx="130" cy="62" r="6" fill="#14c294"/><path d="M127 62 h6 M130 59 v6" stroke="#fff" stroke-width="1.6"/>`;
    }
    return `<rect width="${W}" height="${H}" fill="#e7ebf0"/>
      <g transform="rotate(-4 80 50)"><rect x="34" y="12" width="92" height="78" rx="6" fill="#fff" stroke="#d3d9e1"/>
      <rect x="44" y="22" width="52" height="7" rx="3" fill="#1f2633"/>
      <g fill="#c6cdd7"><rect x="44" y="35" width="72" height="3.4" rx="1.7"/><rect x="44" y="42" width="66" height="3.4" rx="1.7"/><rect x="44" y="49" width="70" height="3.4" rx="1.7"/><rect x="44" y="56" width="48" height="3.4" rx="1.7"/></g>
      <path d="M46 66 q-3 0 -3 4 v4 h6 v-4 h-3 q0 -2 2 -2z M56 66 q-3 0 -3 4 v4 h6 v-4 h-3 q0 -2 2 -2z" fill="#14c294"/>
      <g fill="#c6cdd7"><rect x="64" y="68" width="44" height="3.4" rx="1.7"/><rect x="64" y="75" width="30" height="3.4" rx="1.7"/></g></g>`;
  }

  /* ------------------------------------------------------------------
     Effects: each is a before/after pair of side options.
     ------------------------------------------------------------------ */
  const FX = {
    "enhance":       [{ blur: 1, tone: "dull" },          { tone: "vivid", over: ["sparkle"] }],
    "upscale":       [{ pixel: true },                     { over: ["sparkle"] }],
    "sharpen":       [{ blur: 2 },                         { over: ["sparkle"] }],
    "remove-text":   [{ over: ["watermark"] },             {}],
    "outpaint":      [{ crop: true },                      {}],
    "restore":       [{ tone: "sepia", over: ["scratches"] }, { tone: "vivid" }],
    "colorize":      [{ tone: "mono" },                    { tone: "vivid" }],
    "remove-bg":     [{},                                  { bg: "checker" }],
    "change-bg":     [{},                                  { bg: "beach" }],
    "studio-bg":     [{},                                  { bg: "studio" }],
    "white-bg":      [{ bg: "room" },                      { bg: "white", over: ["shadowFloor"] }],
    "relight":       [{ tone: "dull" },                    { palette: "golden", tone: "warm" }],
    "low-light":     [{ tone: "dark" },                    { tone: "vivid" }],
    "face-sharpen":  [{ faceBlur: true },                  { over: ["sparkle"] }],
    "denoise":       [{ over: ["grain"], tone: "dull" },   {}],
    "perspective":   [{ skew: true },                      {}],
    "recolor":       [{},                                  { tone: "hue" }],
    "day-night":     [{},                                  { palette: "night" }],
    "golden-hour":   [{},                                  { palette: "golden" }],
    "sunset-sky":    [{},                                  { palette: "sunset" }],
    "winter":        [{},                                  { palette: "winter", over: ["snow"] }],
    "rain":          [{},                                  { over: ["rain"] }],
    "fog":           [{},                                  { over: ["fog"] }],
    "remove-object": [{ extra: true },                     { extra: false }],
    // extras sit on the left (the "before" half); mirrored, an added one lands on the right
    "add-object":    [{ extra: false, mirror: true },      { extra: true, mirror: true }],
    "bokeh":         [{},                                  { bokeh: true }],
    "watercolor":    [{},                                  { style: "watercolor", over: ["paper"] }],
    "oil":           [{},                                  { style: "oil" }],
    "sketch":        [{},                                  { style: "sketch" }],
    "lineart":       [{},                                  { style: "lineart" }],
    "anime":         [{},                                  { style: "anime" }],
    "pop-art":       [{},                                  { style: "pop", over: ["halftone"] }],
    "clay":          [{},                                  { style: "clay" }],
    "pixel-art":     [{},                                  { style: "pixel" }],
    "vintage":       [{},                                  { style: "vintage", over: ["grain", "vignette"] }],
    "comic":         [{},                                  { style: "anime", over: ["halftone"], frame: "comic" }],
    "variations":    [{},                                  { grid: true }],
    "angle":         [{},                                  { mirror: true }],
    "avatar":        [{},                                  { circle: true }],
    "thumbnail":     [{ tone: "dull" },                    { tone: "vivid", over: ["thumb"] }],
    "carousel":      [{},                                  { frames: true }],
    "palette":       [{},                                  { tone: "hue", over: ["swatches"] }],
    "copy-space":    [{},                                  { over: ["copyspace"] }],
    "mockup":        [{},                                  { device: true }],
    "passport":      [{ bg: "room" },                      { bg: "plain", passport: true }],
    "story":         [{ doc: "story" },                    {}],
    "story-raw":     [{ doc: "story" },                    { tilt: true, over: ["raw", "grain"] }],
    "story-cctv":    [{ doc: "story" },                    { tone: "mono", over: ["cctv"] }],
    "story-split":   [{ doc: "story" },                    { split: true }],
    "story-vintage": [{ doc: "story" },                    { style: "vintage", over: ["grain", "vignette"] }],
    "prompt":        [{ doc: "prompt" },                   { over: ["sparkle"] }],
    "detail":        [{},                                  { zoom: true }],
    "duplicate":     [{ extra: false },                    { twin: true }],
    "staging":       [{ empty: true },                     { over: ["sparkle"] }]
  };

  /* ------------------------------------------------------------------
     Composing one side.
     ------------------------------------------------------------------ */
  const nest = (inner, vb = `0 0 ${W} ${H}`, x = 0, y = 0, w = W, h = H, extra = "") =>
    `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${vb}" preserveAspectRatio="xMidYMid slice"${extra}>${inner}</svg>`;

  function draw(sceneName, o) {
    const P = PAL[o.palette] || PAL.day;
    const scene = scenes[sceneName] || scenes.portrait;
    if (!scene) return `<rect width="${W}" height="${H}" fill="#2a2d33"/>`;
    let s;
    try { s = scene(P, o, H_) || {}; } catch (_) { s = {}; }
    let bg = s.bg || H_.sky(P);
    if (o.bg && BG[o.bg]) bg = BG[o.bg](P, s);
    if (o.bokeh) bg = `<g filter="url(#psa-blur3)">${bg}</g>${OVER.bokeh()}`;
    // removable extras (a second person, a prop) only appear when an effect asks for them
    const extra = o.extra === true ? (s.extra || "") : "";
    // a second one (duplicate, "two in frame") stands further back, on the right
    const twin = o.twin && s.subject ? `<g transform="translate(76 9) scale(.52)" opacity=".94">${s.subject}</g>` : "";
    let body = bg + extra + twin + (s.subject || "");
    if (o.faceBlur && s.face) {
      const id = "psa-f" + (++uid);
      body += `<clipPath id="${id}"><circle cx="${s.face.x}" cy="${s.face.y}" r="${s.face.r}"/></clipPath>` +
              `<g clip-path="url(#${id})" filter="url(#psa-blur2)">${bg}${s.subject || ""}</g>`;
    }
    return { body, s, P };
  }

  function side(sceneName, o) {
    if (o.doc) return docCard(o.doc);

    // multi-image layouts render the scene several times
    if (o.grid) {
      // the original, with four takes on it laid out over the right half
      // (the half a split shows as "after")
      const pals = ["golden", "sunset", "night", "winter"];
      const base = side(sceneName, Object.assign({}, o, { grid: false }));
      return base + `<rect x="80" width="80" height="${H}" fill="#111317" opacity=".92"/>` + pals.map((p, i) =>
        nest(side(sceneName, Object.assign({}, o, { grid: false, palette: p })), `30 0 100 ${H}`,
             83 + (i % 2) * 38.5, 3 + Math.floor(i / 2) * 48, 36, 46)).join("") +
        `<g fill="none" stroke="#fff" stroke-opacity=".5" stroke-width=".8"><rect x="83" y="3" width="36" height="46" rx="2"/><rect x="121.5" y="3" width="36" height="46" rx="2"/><rect x="83" y="51" width="36" height="46" rx="2"/><rect x="121.5" y="51" width="36" height="46" rx="2"/></g>`;
    }
    if (o.frames) {
      const pals = ["day", "golden", "night"];
      return `<rect width="${W}" height="${H}" fill="#111317"/>` + pals.map((p, i) =>
        nest(side(sceneName, Object.assign({}, o, { frames: false, palette: p })), `${20 + i * 20} 0 ${W - 40} ${H}`,
             4 + i * 52, 10, 48, 80)).join("") +
        `<g fill="#fff"><circle cx="72" cy="95" r="1.4"/><circle cx="80" cy="95" r="1.4" opacity=".45"/><circle cx="88" cy="95" r="1.4" opacity=".45"/></g>`;
    }
    if (o.split) {
      const left = side(sceneName, Object.assign({}, o, { split: false, tone: "dull", over: ["scratches"] }));
      const right = side(sceneName, Object.assign({}, o, { split: false }));
      return `${nest(left, `0 0 ${W / 2} ${H}`, 0, 0, W / 2, H)}${nest(right, `${W / 2} 0 ${W / 2} ${H}`, W / 2, 0, W / 2, H)}` +
             `<rect x="79" y="0" width="2" height="${H}" fill="#fff"/>`;
    }

    const { body, s } = draw(sceneName, o);
    let out = body;

    // whole-image filters, innermost first
    const filters = [];
    if (o.blur) filters.push("psa-blur" + o.blur);
    if (o.pixel) filters.push("psa-pixel");
    if (o.style) filters.push("psa-st-" + o.style);
    if (o.tone) filters.push("psa-" + o.tone);
    for (const f of filters) out = `<g filter="url(#${f})">${out}</g>`;

    // geometry
    if (o.skew) out = `<rect width="${W}" height="${H}" fill="#2a2d33"/><g transform="rotate(-8 80 50) scale(1.22) translate(-14 -9)">${out}</g>`;
    if (o.tilt) out = `<g transform="rotate(2.5 80 50) scale(1.08) translate(-6 -4)">${out}</g>`;
    if (o.mirror) out = `<g transform="translate(${W} 0) scale(-1 1)">${out}</g>`;
    if (o.zoom && s.face) {
      const z = 1.9, fx = s.face.x, fy = s.face.y;
      out = `<g transform="translate(${80 - fx * z} ${50 - fy * z}) scale(${z})">${out}</g>`;
    } else if (o.zoom) {
      out = `<g transform="translate(-48 -30) scale(1.6)">${out}</g>`;
    }

    // overlays
    for (const k of (o.over || [])) if (OVER[k]) out += OVER[k]();

    // framing layouts
    if (o.crop) {
      const id = "psa-c" + (++uid);
      out = `<rect width="${W}" height="${H}" fill="#2a2d33"/>` +
            `<clipPath id="${id}"><rect x="36" y="18" width="88" height="64" rx="3"/></clipPath>` +
            `<g clip-path="url(#${id})">${out}</g>` +
            `<rect x="16" y="6" width="128" height="88" rx="4" fill="none" stroke="#fff" stroke-width="1.3" stroke-dasharray="4 3" opacity=".7"/>` +
            `<g fill="#fff" opacity=".8"><path d="M24 50 l5 -4 v8z"/><path d="M136 50 l-5 -4 v8z"/><path d="M80 12 l-4 5 h8z"/><path d="M80 88 l-4 -5 h8z"/></g>`;
    }
    if (o.circle) {
      const id = "psa-o" + (++uid);
      const cx = s.face ? s.face.x : 80, cy = s.face ? s.face.y + 8 : 50;
      out = `<rect width="${W}" height="${H}" fill="#15171b"/><clipPath id="${id}"><circle cx="80" cy="50" r="40"/></clipPath>` +
            `<g clip-path="url(#${id})"><g transform="translate(${80 - cx} ${50 - cy})">${out}</g></g>` +
            `<circle cx="80" cy="50" r="40" fill="none" stroke="#14c294" stroke-width="2.5"/>`;
    }
    if (o.passport) {
      out += `<ellipse cx="${s.face ? s.face.x : 80}" cy="${s.face ? s.face.y : 42}" rx="${s.face ? s.face.r * 1.5 : 18}" ry="${s.face ? s.face.r * 1.95 : 24}" fill="none" stroke="#14c294" stroke-width="1.2" stroke-dasharray="3 2"/>` +
             `<g fill="none" stroke="#1f2633" stroke-width="1.4" opacity=".6"><path d="M40 8 H32 V16 M120 8 H128 V16 M40 92 H32 V84 M120 92 H128 V84"/></g>`;
    }
    if (o.device) {
      const id = "psa-d" + (++uid);
      out = `<rect width="${W}" height="${H}" fill="#e9e4dc"/><rect y="70" width="${W}" height="30" fill="#d6cbbb"/>${H_.shadow(84, 90, 34, 4, .2)}` +
            `<rect x="56" y="6" width="48" height="86" rx="8" fill="#1b1d22"/>` +
            `<clipPath id="${id}"><rect x="59" y="12" width="42" height="74" rx="5"/></clipPath>` +
            `<g clip-path="url(#${id})">${nest(out, `40 0 80 ${H}`, 59, 12, 42, 74)}</g>` +
            `<rect x="72" y="8" width="16" height="2.4" rx="1.2" fill="#3a3d44"/>`;
    }
    if (o.frame === "comic") {
      out += `<rect x="1.5" y="1.5" width="${W - 3}" height="${H - 3}" fill="none" stroke="#111" stroke-width="3"/>` +
             `<path d="M104 10 h44 a6 6 0 0 1 6 6 v14 a6 6 0 0 1 -6 6 h-30 l-8 8 v-8 h-6 a6 6 0 0 1 -6 -6 v-14 a6 6 0 0 1 6 -6z" fill="#fff" stroke="#111" stroke-width="1.4"/>` +
             `<g fill="#111"><rect x="108" y="17" width="34" height="3" rx="1.5"/><rect x="108" y="24" width="24" height="3" rx="1.5"/></g>`;
    }
    return out;
  }

  /* ------------------------------------------------------------------
     Public API.
     ------------------------------------------------------------------ */
  const svg = (inner, cls) =>
    `<svg class="${cls}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">${inner}</svg>`;

  /** Before/after option objects for a spec. */
  function sides(spec) {
    spec = spec || {};
    const pair = FX[spec.fx] || [{}, { over: ["sparkle"] }];
    const before = Object.assign({}, pair[0], spec.before || {});
    const after = Object.assign({}, pair[1], spec.after || {});
    return { before, after };
  }

  /** Full markup for a preview: both sides stacked, divider on top. */
  function html(spec, opts) {
    spec = spec || {};
    opts = opts || {};
    const scene = spec.scene || "portrait";
    const { before, after } = sides(spec);
    const cls = "psa" + (opts.cls ? " " + opts.cls : "");
    return `<span class="${cls}" data-fx="${spec.fx || ""}">` +
           svg(side(scene, before), "psa-b") +
           // the after side sits in a wrapper so a split can be moved with
           // two opposite translations (compositor work) instead of a clip
           `<span class="psa-aw">${svg(side(scene, after), "psa-a")}</span>` +
           `<i class="psa-div" aria-hidden="true"></i></span>`;
  }

  /** Only the "after" side — for small thumbnails where a split is too busy. */
  function after(spec, opts) {
    spec = spec || {};
    const { after: a } = sides(spec);
    return `<span class="psa psa-solo${opts && opts.cls ? " " + opts.cls : ""}">${svg(side(spec.scene || "portrait", a), "psa-a")}</span>`;
  }

  /* Pictures. In a big gallery, hundreds of inline SVG drawings would
     be thousands of live elements for the page to style and repaint. As
     images, each side is one <img>: drawn once, cached, and moved by the
     compositor. Each image is a standalone SVG carrying its own defs. */
  // only the shared definitions a picture actually uses travel with it
  const DEF_BY_ID = {};
  DEFS.replace(/<(linearGradient|radialGradient|pattern|filter) id="([\w-]+)"[\s\S]*?<\/\1>/g,
               (m, _, id) => { DEF_BY_ID[id] = m; return m; });
  const docOf = (inner) => {
    const used = new Set();
    inner.replace(/url\(#(psa-[\w-]+)\)/g, (_, id) => { used.add(id); return _; });
    const defs = [...used].map(id => DEF_BY_ID[id] || "").join("");
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W * 2}" height="${H * 2}" preserveAspectRatio="xMidYMid slice">` +
           (defs ? `<defs>${defs}</defs>` : "") + inner + `</svg>`;
  };
  const urls = new Map();
  function sideUrl(scene, o) {
    const key = scene + "|" + JSON.stringify(o);
    let u = urls.get(key);
    if (!u) {
      const markup = docOf(side(scene, o));
      try { u = URL.createObjectURL(new Blob([markup], { type: "image/svg+xml" })); }
      catch (_) { u = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(markup); }
      urls.set(key, u);
    }
    return u;
  }

  /* Bitmaps. The browser treats an SVG image as a small page of its
     own: parsed, laid out and painted on the main thread, kept in memory
     for as long as it is shown, and painted again whenever it moves or
     scales. With a hundred previews that was most of what made the
     library feel heavy. So each side is drawn ONCE into a small bitmap,
     in a quiet moment, and from then on the browser just moves a
     finished image about. Until a side's bitmap exists, its <img> waits
     with no src; hydrate() fills it in. */
  const DPR = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  const RW = Math.round(288 * DPR), RH = Math.round(RW * H / W);    // the largest place a preview shows (the editor) is 284 css px wide
  const bitmaps = new Map();       // key → { url, scene, o, waiting: [cb] }
  const queue = [];                // keys still to draw, front first
  const rush = new Set();          // keys something on screen is waiting for
  let drawing = false, canvas = null, ctx = null, bitmapsOK = true;
  const idle = (fn) => (window.requestIdleCallback ? window.requestIdleCallback(fn, { timeout: 400 }) : setTimeout(fn, 32));

  function bitmap(scene, o, cb, urgent) {
    const key = scene + "|" + JSON.stringify(o);
    let b = bitmaps.get(key);
    if (b && b.url) return b.url;
    if (!bitmapsOK) return sideUrl(scene, o);
    if (!b) { b = { url: null, scene, o, waiting: [] }; bitmaps.set(key, b); }
    if (cb) b.waiting.push(cb);
    const at = queue.indexOf(key);
    if (urgent) { rush.add(key); if (at > 0) queue.splice(at, 1); if (at !== 0) queue.unshift(key); }
    else if (at < 0) queue.push(key);
    pump();
    return null;
  }
  function pump() {
    if (drawing || !queue.length) return;
    const key = queue.shift();
    rush.delete(key);
    const b = bitmaps.get(key);
    if (!b || b.url) { pump(); return; }
    drawing = true;
    const settle = (url) => {
      drawing = false;
      b.url = url;
      const cbs = b.waiting; b.waiting = [];
      for (const cb of cbs) { try { cb(url); } catch (_) {} }
      if (!queue.length) return;
      // something on screen is waiting: go on at once; otherwise wait for a quiet moment
      if (rush.has(queue[0])) Promise.resolve().then(pump); else idle(pump);
    };
    const giveUp = (svgUrl) => {
      if (svgUrl) try { URL.revokeObjectURL(svgUrl); } catch (_) {}
      bitmapsOK = false;                    // from now on the SVG images are used directly
      settle(sideUrl(b.scene, b.o));
      for (const k of queue.splice(0)) { const q = bitmaps.get(k); if (q && !q.url) { q.url = sideUrl(q.scene, q.o); const w = q.waiting; q.waiting = []; w.forEach(cb => { try { cb(q.url); } catch (_) {} }); } }
    };
    let svgUrl;
    try { svgUrl = URL.createObjectURL(new Blob([docOf(side(b.scene, b.o))], { type: "image/svg+xml" })); }
    catch (_) { giveUp(); return; }
    const im = new Image();
    im.onload = () => {
      try {
        if (!canvas) {
          canvas = document.createElement("canvas");
          canvas.width = RW; canvas.height = RH;
          ctx = canvas.getContext("2d", { alpha: false });
        }
        ctx.drawImage(im, 0, 0, RW, RH);
        canvas.toBlob((blob) => {
          try { URL.revokeObjectURL(svgUrl); } catch (_) {}
          if (!blob) { giveUp(); return; }
          settle(URL.createObjectURL(blob));
        }, "image/webp", .9);
      } catch (_) { giveUp(svgUrl); }
    };
    im.onerror = () => giveUp(svgUrl);
    im.src = svgUrl;
  }
  /** Draw the sides of these specs ahead of time, in idle moments. */
  function prewarm(specs) {
    for (const spec of specs || []) {
      if (!spec) continue;
      const scene = spec.scene || "portrait";
      const { before, after } = sides(spec);
      bitmap(scene, before); bitmap(scene, after);
    }
  }
  /** Give every waiting <img> under `root` its bitmap when it is ready. */
  function hydrate(root) {
    if (!root || !root.querySelectorAll) return;
    for (const el of root.querySelectorAll("img[data-psa]:not([src])")) {
      const b = bitmaps.get(el.dataset.psa);
      if (!b) continue;
      const url = bitmap(b.scene, b.o, (u) => { if (el.isConnected && !el.src) el.src = u; }, true);
      if (url) el.src = url;
    }
  }
  const img = (scene, o, cls) => {
    const key = scene + "|" + JSON.stringify(o);
    const url = bitmap(scene, o);
    return `<img class="${cls}" data-psa="${key.replace(/&/g, "&amp;").replace(/"/g, "&quot;")}"${url ? ` src="${url}"` : ""} alt="" draggable="false" decoding="async">`;
  };

  /** Like html(), with each side as an image (call hydrate() after inserting). */
  function picture(spec, opts) {
    spec = spec || {};
    opts = opts || {};
    const scene = spec.scene || "portrait";
    const { before, after } = sides(spec);
    return `<span class="psa psa-img${opts.cls ? " " + opts.cls : ""}" data-fx="${spec.fx || ""}">` +
           img(scene, before, "psa-b") +
           `<span class="psa-aw">${img(scene, after, "psa-a")}</span>` +
           `<i class="psa-div" aria-hidden="true"></i></span>`;
  }
  /** Like after(), as an image. */
  function pictureAfter(spec, opts) {
    spec = spec || {};
    const { after: a } = sides(spec);
    return `<span class="psa psa-img psa-solo${opts && opts.cls ? " " + opts.cls : ""}">${img(spec.scene || "portrait", a, "psa-a")}</span>`;
  }

  /** A sensible preview for presets that don't carry one (content updates). */
  function guess(p) {
    const t = ((p && (p.name + " " + (p.g || ""))) || "").toLowerCase();
    const has = (re) => re.test(t);
    if (has(/aircraft|airline|plane|aviation|runway|cockpit/)) return { scene: "aircraft", fx: "enhance" };
    if (has(/airport|terminal|gate/)) return { scene: "airport", fx: "enhance" };
    if (has(/cabin/)) return { scene: "cabin", fx: "enhance" };
    if (has(/background/)) return { scene: "portrait", fx: "change-bg" };
    if (has(/night/)) return { scene: "city", fx: "day-night" };
    if (has(/story|news|scene|photo from/)) return { scene: "city", fx: "story" };
    if (has(/product|packshot/)) return { scene: "product", fx: "white-bg" };
    if (has(/style|paint|sketch|art/)) return { scene: "portrait", fx: "watercolor" };
    if (has(/free/)) return { scene: "landscape", fx: "prompt" };
    return { scene: "portrait", fx: "enhance" };
  }

  window.PSNAP_ART = {
    W, H, PAL, FX, BG, OVER,
    scene: (name, fn) => { scenes[name] = fn; },
    has: (name) => !!scenes[name],
    scenes: () => Object.keys(scenes),
    effects: () => Object.keys(FX),
    ensureDefs, html, after, picture, pictureAfter, hydrate, prewarm, sides, side, guess, helpers: H_,
    bitmapsPending: () => queue.length
  };

  /* ------------------------------------------------------------------
     Reference scene: a head-and-shoulders portrait.
     Other scenes live in art-scenes.js and follow the same rules:
       • draw in a 160×100 box; fill the whole box with bg
       • colours only from P (so palettes work)
       • keep the subject separate from bg; put removable things in extra
     ------------------------------------------------------------------ */
  window.PSNAP_ART.scene("portrait", (P, o, h) => {
    const bg = `${h.sky(P)}${h.stars(P)}${h.sunOrMoon(P, 132, 20, 7)}${h.cloud(P, 30, 22, .8)}` +
               `<path d="M0 74 Q40 62 80 70 T160 66 V100 H0Z" fill="${P.far}"/>` +
               `<path d="M0 84 Q50 76 100 82 T160 80 V100 H0Z" fill="${P.mid}"/>`;
    const subject =
      `<g>` +
      // shoulders and shirt
      `<path d="M46 100 C48 78 62 70 80 70 C98 70 112 78 114 100Z" fill="${P.cloth}"/>` +
      `<path d="M72 70 L80 82 L88 70" fill="${P.light}" opacity=".9"/>` +
      `<path d="M80 82 L80 100" stroke="${P.cloth2}" stroke-width="1.2"/>` +
      // neck
      `<rect x="74" y="58" width="12" height="14" rx="4" fill="${P.skin2}"/>` +
      // hair back
      `<path d="M61 44 C60 22 100 18 100 44 C102 56 98 64 96 66 L64 66 C62 62 59 54 61 44Z" fill="${P.hair}"/>` +
      // face
      `<ellipse cx="80" cy="45" rx="15" ry="18" fill="${P.skin}"/>` +
      // hair front
      `<path d="M64 42 C64 26 96 24 97 40 C90 34 78 33 70 36 C67 38 65 40 64 42Z" fill="${P.hair}"/>` +
      // features
      `<g fill="${P.ink}"><ellipse cx="74" cy="46" rx="1.6" ry="2"/><ellipse cx="86" cy="46" rx="1.6" ry="2"/></g>` +
      `<path d="M75 54 Q80 57.5 85 54" stroke="${P.lip}" stroke-width="1.6" fill="none" stroke-linecap="round"/>` +
      `<g fill="${P.accent}" opacity=".22"><circle cx="70" cy="51" r="3"/><circle cx="90" cy="51" r="3"/></g>` +
      `</g>`;
    const extra =
      `<g>` +
      `<path d="M34 100 C33 86 26 81 19 81 C12 81 5 86 4 100Z" fill="${P.cloth3}"/>` +
      `<circle cx="19" cy="71" r="8" fill="${P.skin2}"/>` +
      `<path d="M27 69 C27 60 11 60 11 69 C14 66 22 65 27 69Z" fill="${P.hair}"/>` +
      `</g>`;
    return { bg, subject, extra, face: { x: 80, y: 45, r: 17 } };
  });
})();
