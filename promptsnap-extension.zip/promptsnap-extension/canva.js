/* PromptSnap — Canva bridge
 * Runs inside canva.com/design/*. Receives an image from the ChatGPT tab
 * and gets it into the open design.
 *
 * Canva is a closed editor, so we try three routes in order:
 *   1. a synthetic drop onto the editor canvas
 *   2. a synthetic paste event carrying the file
 *   3. the real clipboard, and tell the user to press Ctrl+V
 * Whichever lands first wins. Route 3 always works as a floor.
 */

(() => {
  // Injected on demand as well as by the manifest, so a second run must
  // be harmless — but it still has to answer the ping.
  // After the extension is reloaded, the old copy of this script is still
  // in the page but its connection is dead. A plain "already loaded" flag
  // made the new copy bow out, leaving nothing listening — so the live
  // preview froze until the Canva tab was reloaded. Only bow out if the
  // copy already here is actually alive.
  const prevAlive = window.__psnapCanvaAlive;
  if (typeof prevAlive === "function") {
    let alive = false;
    try { alive = prevAlive(); } catch (_) {}
    if (alive) return;
  }
  window.__psnapCanvaAlive = () => { try { return !!chrome.runtime.id; } catch (_) { return false; } };

  const b64ToFile = (b64, mime, name) => {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new File([arr], name, { type: mime });
  };

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  /** The actual page surface, not the app shell.
   * Dropping on the shell hands the file to Canva's uploader, which is
   * why the image landed in Uploads but never on the page. We want the
   * element that represents the page you are looking at. */
  function findPageSurface() {
    const cands = [
      '[data-testid="page"]',
      '[class*="page_"]:not([class*="thumbnail"])',
      '[data-testid="design-canvas"] [class*="page"]',
      '[data-testid="design-canvas"]',
      '[class*="page-container"]'
    ];
    for (const sel of cands) {
      for (const el of document.querySelectorAll(sel)) {
        const r = el.getBoundingClientRect();
        // the live page is large and on screen; thumbnails are small
        if (r.width > 220 && r.height > 220 && r.top < window.innerHeight && r.bottom > 0) {
          return el;
        }
      }
    }
    // largest visible canvas as a last resort
    let best = null, area = 0;
    for (const c of document.querySelectorAll("canvas")) {
      const r = c.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area && r.width > 220) { area = a; best = c; }
    }
    return best || document.querySelector('[role="main"]') || document.body;
  }

  /** How many images are currently placed on the visible page. Used to
      tell whether a drop actually landed. */
  function pageImageCount() {
    const surface = findPageSurface();
    if (!surface) return 0;
    return surface.querySelectorAll("img, image, [data-testid*='image']").length;
  }

  /* ---- Uploads-panel route -------------------------------------------
   * Canva always accepts a file into Uploads. Clicking the newest item
   * there places it on the current page. That's the reliable path when a
   * direct drop doesn't stick. */

  function findUploadsButton() {
    const bySel = document.querySelector('[data-testid*="uploads" i], [aria-label*="Uploads" i]');
    if (bySel) return bySel;
    for (const b of document.querySelectorAll('button, [role="tab"], [role="button"]')) {
      if (/^\s*uploads\s*$/i.test(b.textContent || "")) return b;
    }
    return null;
  }

  /** Thumbnails in the left-hand panel. Rather than trusting one
      container selector (Canva renames these constantly), take every
      image living in the left column at thumbnail size. */
  function uploadThumbs() {
    const out = [];
    for (const i of document.querySelectorAll("img")) {
      const r = i.getBoundingClientRect();
      if (r.width < 40 || r.height < 40) continue;
      if (r.width > 260) continue;                 // too big to be a thumb
      if (r.left > 620) continue;                  // must be the side panel
      if (r.top > window.innerHeight - 60) continue; // not the page strip
      out.push(i);
    }
    return out;
  }

  /** Every file picker is backed by an <input type="file">. Assigning
      .files and firing change is what the browser itself does, so it
      goes through Canva's genuine upload path. */
  function findFileInput() {
    const inputs = [...document.querySelectorAll('input[type="file"]')];
    // prefer one that accepts images
    return inputs.find(i => /image|\*/.test(i.accept || "")) || inputs[0] || null;
  }

  function pushToFileInput(file) {
    const input = findFileInput();
    if (!input) return false;
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      // confirm the assignment actually took before claiming success —
      // some inputs are locked down and silently ignore it
      if (!input.files || input.files.length === 0) return false;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (_) { return false; }
  }

  /** Signature of every upload thumbnail currently on screen. */
  function thumbKeys() {
    return new Set(uploadThumbs().map(i => i.currentSrc || i.src || ""));
  }

  /** Click an Uploads thumbnail the way a person would. Canva places the
      item on the current page in response. */
  function clickThumb(el) {
    try {
      const r = el.getBoundingClientRect();
      const base = { bubbles: true, cancelable: true, composed: true, view: window,
                     clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
      const target = el.closest('[role="button"], button, [draggable="true"], li, [data-testid]') || el;
      target.dispatchEvent(new PointerEvent("pointerover", base));
      target.dispatchEvent(new MouseEvent("mouseover", base));
      target.dispatchEvent(new PointerEvent("pointerdown", Object.assign({ button:0, buttons:1 }, base)));
      target.dispatchEvent(new MouseEvent("mousedown", Object.assign({ button:0, buttons:1 }, base)));
      target.dispatchEvent(new PointerEvent("pointerup", Object.assign({ button:0, buttons:0 }, base)));
      target.dispatchEvent(new MouseEvent("mouseup", Object.assign({ button:0, buttons:0 }, base)));
      target.dispatchEvent(new MouseEvent("click", Object.assign({ button:0, buttons:0 }, base)));
      return true;
    } catch (_) { return false; }
  }

  /** Last resort: hand the page a paste event carrying the file. Only
      used when nothing else placed the image, so it can't double up. */
  function forcePaste(file) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const surface = findPageSurface();
      surface.focus?.();
      const ev = new ClipboardEvent("paste", { bubbles: true, cancelable: true, composed: true });
      Object.defineProperty(ev, "clipboardData", { value: dt });
      surface.dispatchEvent(ev);
      document.dispatchEvent(ev);
      return true;
    } catch (_) { return false; }
  }

  function tryDrop(file, target) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const r = target.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      const opts = { bubbles: true, cancelable: true, composed: true,
                     clientX: x, clientY: y, dataTransfer: dt };
      target.dispatchEvent(new DragEvent("dragenter", opts));
      target.dispatchEvent(new DragEvent("dragover", opts));
      target.dispatchEvent(new DragEvent("drop", opts));
      return true;
    } catch (_) { return false; }
  }

  let lastInsert = { stamp: "", at: 0 };

  /** Kept for reference. NOT used — firing this alongside tryDrop is what
      caused two images to land at once. */
  function tryPasteEvent(file, target) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const ev = new ClipboardEvent("paste", {
        bubbles: true, cancelable: true, composed: true, clipboardData: dt
      });
      // ClipboardEvent ignores clipboardData in some builds — force it
      try { Object.defineProperty(ev, "clipboardData", { value: dt }); } catch (_) {}
      target.dispatchEvent(ev);
      document.dispatchEvent(ev);
      return true;
    } catch (_) { return false; }
  }

  async function tryClipboard(blob) {
    try {
      if (!navigator.clipboard || !window.ClipboardItem) return false;
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      return true;
    } catch (_) { return false; }
  }

  /* ---------------------------------------------------------- toast */

  function toast(title, sub, kind) {
    document.getElementById("psnap-canva-toast")?.remove();
    const el = document.createElement("div");
    el.id = "psnap-canva-toast";
    el.setAttribute("data-kind", kind || "ok");
    el.innerHTML = `
      <div class="pct-ico">${kind === "err" ? "!" : "&#10003;"}</div>
      <div class="pct-txt"><strong></strong><span></span></div>
    `;
    el.querySelector("strong").textContent = title;
    el.querySelector("span").textContent = sub || "";
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("pct-in"));
    setTimeout(() => {
      el.classList.remove("pct-in");
      setTimeout(() => el.remove(), 350);
    }, kind === "err" ? 6000 : 7000);
    return el;
  }

  const style = document.createElement("style");
  style.textContent = `
    #psnap-canva-toast {
      position: fixed; right: 22px; bottom: 22px; z-index: 2147483600;
      display: flex; align-items: center; gap: 13px;
      padding: 13px 18px 13px 14px;
      background: #14201d; border: 1px solid #14c294; border-radius: 13px;
      color: #eafaf7; font-family: "Segoe UI", system-ui, sans-serif;
      box-shadow: 0 12px 38px rgba(0,0,0,.45);
      opacity: 0; transform: translateY(18px) scale(.94);
      transition: opacity .3s ease, transform .4s cubic-bezier(.34,1.4,.64,1);
      max-width: 340px;
    }
    #psnap-canva-toast.pct-in { opacity: 1; transform: translateY(0) scale(1); }
    #psnap-canva-toast[data-kind="err"] { border-color: #e8888f; background: #241417; }
    #psnap-canva-toast .pct-ico {
      width: 32px; height: 32px; border-radius: 50%; flex: none;
      background: #14c294; color: #fff; font-weight: 700; font-size: 17px;
      display: flex; align-items: center; justify-content: center;
    }
    #psnap-canva-toast[data-kind="err"] .pct-ico { background: #e8586a; }
    #psnap-canva-toast .pct-txt { display: flex; flex-direction: column; line-height: 1.4; }
    #psnap-canva-toast .pct-txt strong { font-size: 13.5px; }
    #psnap-canva-toast .pct-txt span { font-size: 11.5px; color: #86d8bf; }
    #psnap-canva-toast[data-kind="err"] .pct-txt span { color: #f0a6ad; }
  `;
  document.documentElement.appendChild(style);

  /* --------------------------------------------------------- receive */

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg) return;

    if (msg.type === "psnap-canva-ping") {
      reply(Object.assign({ ok: true }, readMeta(!!msg.sigOnly)));
      return true;
    }

    if (msg.type === "psnap-insert-image") {
      (async () => {
        const stamp = (msg.b64 || "").slice(0, 64) + "|" + (msg.b64 || "").length;
        if (stamp === lastInsert.stamp && Date.now() - lastInsert.at < 6000) {
          reply({ ok: true, duplicate: true });
          return;
        }
        lastInsert = { stamp, at: Date.now() };

        const file = b64ToFile(msg.b64, msg.mime || "image/png", msg.name || "promptsnap.png");
        const blob = file.slice(0, file.size, file.type);
        window.focus();

        // Open Uploads first — the file input and the thumbnail list both
        // live there, and it has to be mounted before we can use either.
        const panelBtn = findUploadsButton();
        if (panelBtn) { panelBtn.click(); await sleep(650); }

        const before = thumbKeys();

        // ROUTE 1 — Canva's own file input. This is the real upload path.
        let started = pushToFileInput(file);

        // ROUTE 2 — synthetic drop, in case the input wasn't mounted
        let viaInput = started;
        if (!started) {
          const shell = document.querySelector('[role="main"]') ||
                        document.querySelector("#root") || document.body;
          tryDrop(file, shell);
        }

        // Wait for the new thumbnail. Give the real upload path a long
        // window, but don't sit around when we already know the drop is
        // a long shot.
        const cycles = viaInput ? 30 : 12;                 // ~12s vs ~5s
        let newest = null;
        for (let i = 0; i < cycles && !newest; i++) {
          for (const img of uploadThumbs()) {
            const k = img.currentSrc || img.src || "";
            if (k && !before.has(k)) { newest = img; break; }
          }
          if (!newest) await sleep(400);
        }

        // Click it in. Canva needs the image fully processed first, so
        // retry the click a few times rather than assuming one lands.
        let placed = false;
        if (newest) {
          for (let attempt = 0; attempt < 3 && !placed; attempt++) {
            await sleep(attempt === 0 ? 600 : 900);
            clickThumb(newest);
            await sleep(700);
            placed = true;      // Canva gives no signal; one good click is enough
          }
        }

        // ROUTE 3 — nothing uploaded at all: paste the file straight in
        if (!newest) {
          placed = forcePaste(file);
          await sleep(500);
        }

        // Clipboard last, purely as a manual escape hatch
        const copied = await tryClipboard(blob);

        if (placed) {
          toast("Image placed on your page", "Reposition it however you like", "ok");
        } else if (newest) {
          toast("Image is in Uploads", "Click it to drop it on your page", "ok");
        } else if (copied) {
          toast("Image copied", "Click the page and press Ctrl+V", "ok");
        } else {
          toast("Couldn't send the image", "Try downloading and dragging it in", "err");
        }

        reply({
          ok: placed || !!newest || copied,
          placed,
          uploaded: !!newest,
          copied,
          route: newest ? "uploads" : (placed ? "paste" : "clipboard"),
          reason: placed ? "" : (newest ? "in Uploads" : (copied ? "press Ctrl+V" : "Canva refused it"))
        });
      })();
      return true;
    }

    if (msg.type === "psnap-canva-goto") {
      const cur = readPages().page || 0;
      const target = msg.page ? Number(msg.page) : cur + (Number(msg.dir) || 0);
      gotoPage(target).then(async (r) => {
        await sleep(350);                     // let the strip thumbnail settle
        reply(Object.assign({}, r, readMeta(false)));
      });
      return true;
    }

    if (msg.type === "psnap-canva-meta") {
      reply(readMeta(!!msg.sigOnly));
      return true;
    }
  });

  /** Page position, e.g. "82 / 82" in the bottom bar. */
  function readPages() {
    // innerText reflects what is visible, but fall back to textContent so
    // this never silently returns nothing
    // Best: the small "203 / 204" counter element on its own.
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(t) {
        const v = t.nodeValue || "";
        return v.length < 16 && /^\s*\d{1,4}\s*\/\s*\d{1,4}\s*$/.test(v)
          ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let n;
    while ((n = w.nextNode())) {
      const mm = /(\d{1,4})\s*\/\s*(\d{1,4})/.exec(n.nodeValue);
      const cur = Number(mm[1]), tot = Number(mm[2]);
      if (tot > 0 && cur > 0 && cur <= tot) return { page: cur, pages: tot };
    }
    const txt = (document.body.innerText || document.body.textContent || "");
    const m = /\b(\d{1,4})\s*\/\s*(\d{1,4})\b/.exec(txt);
    if (m) {
      const cur = Number(m[1]), tot = Number(m[2]);
      if (tot > 0 && cur > 0 && cur <= tot) return { page: cur, pages: tot };
    }
    // fall back to counting thumbnails in the page strip
    const thumbs = document.querySelectorAll('[data-testid*="page-thumb" i], [class*="pageThumb" i]');
    if (thumbs.length) return { page: 0, pages: thumbs.length };
    return { page: 0, pages: 0 };
  }

  /** Is a captured canvas actually blank? A WebGL canvas without a
      preserved drawing buffer exports as solid black, which is why the
      preview showed a black rectangle. */
  /** A reusable scratch canvas for pixel inspection. Flagged
      willReadFrequently so Chrome keeps it on the CPU — without that it
      warns about repeated getImageData readbacks, which is what showed up
      in the extension error list. */
  let _probe = null;
  function probeCtx() {
    if (!_probe) {
      _probe = document.createElement("canvas");
      _probe.width = 12;
      _probe.height = 12;
      _probe._ctx = _probe.getContext("2d", { willReadFrequently: true });
    }
    return _probe._ctx ? _probe : null;
  }

  /** Is a captured canvas actually blank? A WebGL canvas without a
      preserved drawing buffer exports as solid black, which is why the
      preview showed a black rectangle.
      Shrinks the image into a 12x12 probe and reads it back ONCE, rather
      than sampling individual pixels with five separate readbacks. */
  function looksBlank(cv) {
    try {
      if (!cv || !cv.width || !cv.height) return true;
      const probe = probeCtx();
      if (!probe) return true;
      const g = probe._ctx;

      g.clearRect(0, 0, probe.width, probe.height);
      g.drawImage(cv, 0, 0, probe.width, probe.height);

      const data = g.getImageData(0, 0, probe.width, probe.height).data;
      const r0 = data[0], g0 = data[1], b0 = data[2], a0 = data[3];
      for (let i = 4; i < data.length; i += 4) {
        // any pixel differing by more than a rounding wobble means content
        if (Math.abs(data[i]     - r0) > 4 ||
            Math.abs(data[i + 1] - g0) > 4 ||
            Math.abs(data[i + 2] - b0) > 4 ||
            Math.abs(data[i + 3] - a0) > 4) {
          return false;
        }
      }
      return true;                                  // uniform: nothing drawn
    } catch (_) {
      return true;                                  // tainted: treat as blank
    }
  }

  /** Export any canvas element, rejecting blank results. */
  function exportCanvas(src, maxW) {
    try {
      if (!src || !src.width || src.width < 40) return "";
      const out = document.createElement("canvas");
      const scale = Math.min(1, (maxW || 260) / src.width);
      out.width = Math.max(1, Math.round(src.width * scale));
      out.height = Math.max(1, Math.round(src.height * scale));
      out.getContext("2d").drawImage(src, 0, 0, out.width, out.height);
      if (looksBlank(out)) return "";
      const url = out.toDataURL("image/jpeg", 0.72);
      return (url && url.length > 400) ? url : "";
    } catch (_) { return ""; }
  }

  /** Everything sitting in the bottom page strip, image or canvas. */
  function stripNodes() {
    const out = [];
    for (const el of document.querySelectorAll("img, canvas")) {
      const r = el.getBoundingClientRect();
      if (r.width < 24 || r.width > 240) continue;
      if (r.top < window.innerHeight * 0.55) continue;   // bottom area only
      if (r.height < 20) continue;
      out.push(el);
    }
    return out;
  }

  /** The strip item for page n. Each thumbnail in Canva's bottom strip
      carries its page number as a small label ("203"). Find that label,
      then climb to the box that also holds the thumbnail picture.
      The old version grabbed the LAST thumbnail in the strip when it
      couldn't tell which one was selected — that's why the panel showed
      page 204 while you were on 203. */
  function stripItemForPage(n) {
    if (!n) return null;
    const want = String(n);
    const minTop = window.innerHeight * 0.55;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(t) {
        return (t.nodeValue || "").trim() === want ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let t;
    while ((t = walker.nextNode())) {
      const label = t.parentElement;
      if (!label) continue;
      const lr = label.getBoundingClientRect();
      if (lr.top < minTop || lr.width === 0) continue;       // bottom strip only
      let box = label;
      for (let i = 0; i < 6 && box; i++) {
        box = box.parentElement;
        if (!box) break;
        const br = box.getBoundingClientRect();
        if (br.width > 320) break;                           // left the thumbnail
        const media = [...box.querySelectorAll("img, canvas")].find(m => {
          const r = m.getBoundingClientRect();
          return r.width >= 24 && r.width <= 260 && r.height >= 20;
        });
        if (media) return { item: box, media };
      }
    }
    return null;
  }

  function selectedStripNode() {
    const p = readPages();
    const hit = stripItemForPage(p.page);
    if (hit) return hit.media;
    const nodes = stripNodes();
    if (!nodes.length) return null;
    const sel = nodes.find(el =>
      el.closest('[aria-selected="true"], [aria-current="true"], [class*="selected" i], [class*="active" i]'));
    return sel || null;                    // never guess the last page
  }

  /** Go to another page, as if you clicked its thumbnail in the strip. */
  async function gotoPage(target) {
    const p = readPages();
    if (!p.pages) return { ok: false, reason: "no pages" };
    target = Math.max(1, Math.min(p.pages, target));
    if (target === p.page) return { ok: true, page: target };

    for (let attempt = 0; attempt < 6; attempt++) {
      const hit = stripItemForPage(target);
      if (hit) {
        const el = hit.item.closest('[role="button"], [role="option"], [role="tab"], button, li, [draggable="true"]') || hit.item;
        clickThumb(el);
        for (let i = 0; i < 12; i++) {
          await sleep(100);
          if (readPages().page === target) return { ok: true, page: target };
        }
      }
      // thumbnail not rendered yet — scroll the strip toward it and retry
      const any = stripNodes()[0];
      let sc = any && any.parentElement;
      while (sc && sc !== document.body && !(sc.scrollWidth > sc.clientWidth + 4)) sc = sc.parentElement;
      if (sc && sc !== document.body) {
        sc.scrollLeft += (target > readPages().page ? 1 : -1) * Math.max(160, sc.clientWidth * 0.5);
      }
      await sleep(250);
    }
    return { ok: readPages().page === target, page: readPages().page };
  }

  /** URL or data URL for the current page thumbnail. Canva keeps these
      up to date as you edit, so this is what tracks your changes. */
  function stripThumb() {
    const node = selectedStripNode();
    if (!node) return "";
    if (node.tagName === "IMG") {
      const src = node.currentSrc || node.src || "";
      return /^https?:|^data:/.test(src) ? src : "";
    }
    return exportCanvas(node, 200);        // the strip is often a canvas
  }

  /** Export the live page canvas, but only if it isn't blank. */
  function canvasThumb() {
    try {
      const surface = findPageSurface();
      if (!surface) return "";
      const canvases = surface.tagName === "CANVAS"
        ? [surface]
        : [...surface.querySelectorAll("canvas")];
      let best = null, area = 0;
      for (const c of canvases) {
        const a = c.width * c.height;
        if (a > area) { area = a; best = c; }
      }
      return exportCanvas(best, 260);
    } catch (_) { return ""; }
  }

  /** Strip thumbnail first — it tracks edits. Canvas as a backup.
      Returns "" rather than a black rectangle when neither works. */
  function readThumb() {
    return stripThumb() || canvasThumb() || "";
  }

  /** A cheap value that changes whenever the design does, so the panel
      can tell "nothing moved" from "this needs repainting". */
  function readSignature() {
    const p = readPages();
    const node = selectedStripNode();
    // For an <img> the src changes when Canva re-renders the page. For a
    // canvas there is no src, so fall back to its size plus the page
    // position, which still catches page switches and edits that resize.
    // For a canvas there is no src and its size rarely changes, which is
    // why edits used to go unnoticed until Refresh. Hash a tiny 12x12
    // copy of its pixels instead — that moves with every visible edit.
    let key = "";
    if (node) {
      key = node.tagName === "IMG"
        ? hashStr(node.currentSrc || node.src || "")
        : "cv" + node.width + "x" + node.height + ":" + pixelHash(node);
    }
    const surf = findPageSurface();
    const cv = surf && (surf.tagName === "CANVAS" ? surf : surf.querySelector("canvas"));
    const surfKey = cv ? pixelHash(cv) : "";
    return [p.page, p.pages, key, surfKey, document.title].join("|");
  }

  function hashStr(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  function pixelHash(cv) {
    try {
      if (!cv || !cv.width || !cv.height) return "";
      const probe = probeCtx();
      if (!probe) return "";
      const g = probe._ctx;
      g.clearRect(0, 0, probe.width, probe.height);
      g.drawImage(cv, 0, 0, probe.width, probe.height);
      const d = g.getImageData(0, 0, probe.width, probe.height).data;
      let h = 5381;
      // drop the lowest bits so GPU rounding noise doesn't count as an edit
      for (let i = 0; i < d.length; i++) h = ((h << 5) + h + (d[i] >> 3)) | 0;
      return (h >>> 0).toString(36);
    } catch (_) { return ""; }
  }

  /** Where the design page sits on screen, for cropping a screenshot. */
  function pageRect() {
    const el = findPageSurface();
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const x = Math.max(0, r.left), y = Math.max(0, r.top);
    const w = Math.min(window.innerWidth, r.right) - x;
    const h = Math.min(window.innerHeight, r.bottom) - y;
    if (w < 40 || h < 40) return null;
    return { x, y, w, h, vw: window.innerWidth };
  }

  function readMeta(sigOnly) {
    const p = readPages();
    const sig = readSignature();
    if (sigOnly) return { sig, page: p.page, pages: p.pages, title: designName() };
    return { title: designName(), page: p.page, pages: p.pages, thumb: readThumb(), sig, rect: pageRect() };
  }

  /* ---------------------------------------------------- live push
     Tell the extension when the design changes, so the panel on ChatGPT
     updates by itself while you work here. Checked on edits (DOM
     changes), on a slow timer as a backup, and when you leave the tab. */
  let _lastSig = "", _lastTitle = "", _pushT = null;
  function pushIfChanged(now) {
    if (!window.__psnapCanvaAlive || !window.__psnapCanvaAlive()) return stopPush();
    const sig = readSignature();
    if (sig === _lastSig && !now) return;
    const title = designName();
    const titleChanged = title !== _lastTitle;
    _lastSig = sig; _lastTitle = title;
    try { chrome.runtime.sendMessage({ type: "psnap-canva-changed", sig, titleChanged }).catch?.(() => {}); }
    catch (_) { stopPush(); }
  }
  const schedulePush = () => {
    clearTimeout(_pushT);
    _pushT = setTimeout(() => pushIfChanged(false), 700);
  };
  const mo = new MutationObserver(schedulePush);
  mo.observe(document.body, { childList: true, subtree: true, attributes: true,
    attributeFilter: ["src", "aria-selected", "aria-current", "class", "value"] });
  const backup = setInterval(() => { if (!document.hidden) pushIfChanged(false); }, 2000);
  const onHide = () => { if (document.hidden) pushIfChanged(true); };
  document.addEventListener("visibilitychange", onHide);
  window.addEventListener("blur", () => pushIfChanged(true));
  function stopPush() {
    mo.disconnect(); clearInterval(backup); clearTimeout(_pushT);
    document.removeEventListener("visibilitychange", onHide);
  }

  /** The design name shown in Canva's title bar. */
  function designName() {
    const el =
      document.querySelector('[data-testid="title-input"]') ||
      document.querySelector('input[aria-label*="title" i]') ||
      document.querySelector('[class*="title"] input');
    if (el && (el.value || el.textContent)) return (el.value || el.textContent).trim();
    return document.title.replace(/\s*[-–|]\s*Canva\s*$/i, "").trim();
  }

  // let the background worker know our real name when it asks
  try { chrome.runtime.sendMessage({ type: "psnap-canva-hello", title: designName() }); } catch (_) {}
})();
