/* PromptSnap — Canva bridge
 * Runs inside canva.com/design/*. Receives an image from the ChatGPT tab
 * and gets it into the open design.
 *
 * Canva is a closed editor, so we try three routes in order:
 *   1. a synthetic drop onto the editor canvas
 *   2. a synthetic paste event carrying the file
 *   3. the real clipboard, and tell the user to press Ctrl+V
 * Whichever lands first wins. Route 3 always works as a floor.
 */

(() => {
  if (window.__psnapCanvaLoaded) return;
  window.__psnapCanvaLoaded = true;

  const b64ToFile = (b64, mime, name) => {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new File([arr], name, { type: mime });
  };

  /** Best guess at the editor surface. */
  function findCanvas() {
    return (
      document.querySelector('[data-testid="design-canvas"]') ||
      document.querySelector('[class*="page-container"]') ||
      document.querySelector("canvas")?.parentElement ||
      document.querySelector('[role="main"]') ||
      document.body
    );
  }

  function tryDrop(file, target) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const r = target.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      const opts = { bubbles: true, cancelable: true, composed: true,
                     clientX: x, clientY: y, dataTransfer: dt };
      target.dispatchEvent(new DragEvent("dragenter", opts));
      target.dispatchEvent(new DragEvent("dragover", opts));
      target.dispatchEvent(new DragEvent("drop", opts));
      return true;
    } catch (_) { return false; }
  }

  function tryPasteEvent(file, target) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const ev = new ClipboardEvent("paste", {
        bubbles: true, cancelable: true, composed: true, clipboardData: dt
      });
      // ClipboardEvent ignores clipboardData in some builds — force it
      try { Object.defineProperty(ev, "clipboardData", { value: dt }); } catch (_) {}
      target.dispatchEvent(ev);
      document.dispatchEvent(ev);
      return true;
    } catch (_) { return false; }
  }

  async function tryClipboard(blob) {
    try {
      if (!navigator.clipboard || !window.ClipboardItem) return false;
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      return true;
    } catch (_) { return false; }
  }

  /* ---------------------------------------------------------- toast */

  function toast(title, sub, kind) {
    document.getElementById("psnap-canva-toast")?.remove();
    const el = document.createElement("div");
    el.id = "psnap-canva-toast";
    el.setAttribute("data-kind", kind || "ok");
    el.innerHTML = `
      <div class="pct-ico">${kind === "err" ? "!" : "&#10003;"}</div>
      <div class="pct-txt"><strong></strong><span></span></div>
    `;
    el.querySelector("strong").textContent = title;
    el.querySelector("span").textContent = sub || "";
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("pct-in"));
    setTimeout(() => {
      el.classList.remove("pct-in");
      setTimeout(() => el.remove(), 350);
    }, kind === "err" ? 6000 : 7000);
    return el;
  }

  const style = document.createElement("style");
  style.textContent = `
    #psnap-canva-toast {
      position: fixed; right: 22px; bottom: 22px; z-index: 2147483600;
      display: flex; align-items: center; gap: 13px;
      padding: 13px 18px 13px 14px;
      background: #14201d; border: 1px solid #14c294; border-radius: 13px;
      color: #eafaf7; font-family: "Segoe UI", system-ui, sans-serif;
      box-shadow: 0 12px 38px rgba(0,0,0,.45);
      opacity: 0; transform: translateY(18px) scale(.94);
      transition: opacity .3s ease, transform .4s cubic-bezier(.34,1.4,.64,1);
      max-width: 340px;
    }
    #psnap-canva-toast.pct-in { opacity: 1; transform: translateY(0) scale(1); }
    #psnap-canva-toast[data-kind="err"] { border-color: #e8888f; background: #241417; }
    #psnap-canva-toast .pct-ico {
      width: 32px; height: 32px; border-radius: 50%; flex: none;
      background: #14c294; color: #fff; font-weight: 700; font-size: 17px;
      display: flex; align-items: center; justify-content: center;
    }
    #psnap-canva-toast[data-kind="err"] .pct-ico { background: #e8586a; }
    #psnap-canva-toast .pct-txt { display: flex; flex-direction: column; line-height: 1.4; }
    #psnap-canva-toast .pct-txt strong { font-size: 13.5px; }
    #psnap-canva-toast .pct-txt span { font-size: 11.5px; color: #86d8bf; }
    #psnap-canva-toast[data-kind="err"] .pct-txt span { color: #f0a6ad; }
  `;
  document.documentElement.appendChild(style);

  /* --------------------------------------------------------- receive */

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg) return;

    if (msg.type === "psnap-canva-ping") {
      reply({ ok: true, title: designName() });
      return true;
    }

    if (msg.type === "psnap-insert-image") {
      (async () => {
        const file = b64ToFile(msg.b64, msg.mime || "image/png", msg.name || "promptsnap.png");
        const blob = file.slice(0, file.size, file.type);
        const target = findCanvas();

        window.focus();
        target.scrollIntoView?.({ block: "center" });

        const dropped = tryDrop(file, target);
        tryPasteEvent(file, target);
        const copied = await tryClipboard(blob);

        if (copied) {
          toast("Image ready in Canva", "If it didn't drop in, click the page and press Ctrl+V", "ok");
        } else if (dropped) {
          toast("Image sent to Canva", "Check your page — it should be on the canvas", "ok");
        } else {
          toast("Couldn't place the image", "Try downloading it and dragging it in", "err");
        }
        reply({ ok: copied || dropped, copied, dropped });
      })();
      return true;
    }
  });

  /** The design name shown in Canva's title bar. */
  function designName() {
    const el =
      document.querySelector('[data-testid="title-input"]') ||
      document.querySelector('input[aria-label*="title" i]') ||
      document.querySelector('[class*="title"] input');
    if (el && (el.value || el.textContent)) return (el.value || el.textContent).trim();
    return document.title.replace(/\s*[-–|]\s*Canva\s*$/i, "").trim();
  }

  // let the background worker know our real name when it asks
  try { chrome.runtime.sendMessage({ type: "psnap-canva-hello", title: designName() }); } catch (_) {}
})();
