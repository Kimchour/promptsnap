/* PromptSnap — update checker (service worker)
 *
 * Fetches a small JSON file you host, compares its version against the
 * installed one, and stores the result. The content script watches that
 * storage key and shows the banner.
 *
 * The JSON looks like:
 *   {
 *     "version": "1.7.0",
 *     "download_url": "https://.../promptsnap-extension.zip",
 *     "notes": "What changed in this version",
 *     "required": false
 *   }
 */

const DEFAULT_FEED =
  "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";

const CHECK_ALARM = "psnap-update-check";
const CHECK_EVERY_MIN = 180;          // 3 hours

/* ---------------------------------------------------------------- utils */

function parseVer(v) {
  return String(v || "0")
    .trim()
    .replace(/^v/i, "")
    .split(".")
    .map(n => parseInt(n, 10) || 0);
}

/** > 0 if a is newer than b */
function cmpVer(a, b) {
  const x = parseVer(a), y = parseVer(b);
  const len = Math.max(x.length, y.length);
  for (let i = 0; i < len; i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

const installedVersion = () => chrome.runtime.getManifest().version;

async function getFeedUrl() {
  const { psnapFeed } = await chrome.storage.local.get("psnapFeed");
  return (psnapFeed && /^https:\/\//i.test(psnapFeed)) ? psnapFeed : DEFAULT_FEED;
}

/* --------------------------------------------------------------- check */

async function checkForUpdate(manual = false) {
  const url = await getFeedUrl();
  const now = Date.now();

  try {
    const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + now, {
      cache: "no-store"
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const data = await res.json();
    const latest = String(data.version || "").trim();
    if (!latest) throw new Error("no version field");

    const current = installedVersion();
    const newer = cmpVer(latest, current) > 0;

    const state = {
      checkedAt: now,
      current,
      latest,
      available: newer,
      notes: String(data.notes || "").slice(0, 600),
      downloadUrl: /^https:\/\//i.test(data.download_url || "") ? data.download_url : "",
      required: !!data.required,
      error: "",
      // changelog
      added: Array.isArray(data.added) ? data.added.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      fixed: Array.isArray(data.fixed) ? data.fixed.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      // content payload — presets and suggestion chips. This is DATA, not
      // code, so it can be applied instantly with no reinstall.
      content: (data.content && typeof data.content === "object") ? data.content : null,
      // true when the update changes actual code and needs a reload
      needsReload: data.needs_reload !== false
    };

    // don't re-nag about a version the user already dismissed
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    if (psnapUpdate && psnapUpdate.dismissed === latest && !state.required && !manual) {
      state.dismissed = latest;
    }

    await chrome.storage.local.set({ psnapUpdate: state });

    if (newer && !state.dismissed) {
      try {
        chrome.action?.setBadgeText?.({ text: "NEW" });
        chrome.action?.setBadgeBackgroundColor?.({ color: "#14c294" });
      } catch (_) {}
    }
    return state;

  } catch (err) {
    const state = {
      checkedAt: now,
      current: installedVersion(),
      latest: "",
      available: false,
      error: String(err && err.message || err).slice(0, 200)
    };
    await chrome.storage.local.set({ psnapUpdate: state });
    return state;
  }
}

/* -------------------------------------------------------------- wiring */

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.alarms.onAlarm.addListener(a => {
  if (a.name === CHECK_ALARM) checkForUpdate();
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "psnap-check-update") {
    checkForUpdate(true).then(reply);
    return true;                       // async response
  }
  if (msg && msg.type === "psnap-clear-badge") {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
    reply({ ok: true });
    return true;
  }
  if (msg && msg.type === "psnap-apply-content") {
    applyContentUpdate().then(reply);
    return true;
  }
  if (msg && msg.type === "psnap-open-extensions") {
    chrome.tabs.create({ url: "chrome://extensions" });
    reply({ ok: true });
    return true;
  }
});


/* ------------------------------------------------- content auto-install
 * Presets and suggestion chips are plain data. We can install those
 * straight into storage without touching any code, so that part of an
 * update really is automatic — no download, no reload, no folder.
 */
async function applyContentUpdate() {
  const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
  const payload = psnapUpdate && psnapUpdate.content;
  if (!payload) return { ok: false, reason: "no-content" };

  const patch = {};
  let presets = 0, chips = 0;

  if (Array.isArray(payload.presets) && payload.presets.length) {
    const clean = payload.presets
      .filter(p => p && typeof p.name === "string" && typeof p.text === "string")
      .slice(0, 200)
      .map(p => ({
        g: String(p.g || "Presets").slice(0, 40),
        name: String(p.name).slice(0, 120),
        text: String(p.text).slice(0, 2000)
      }));
    if (clean.length) { patch.psnapPresets = clean; presets = clean.length; }
  }

  if (payload.suggestions && typeof payload.suggestions === "object") {
    const { psnapCustom } = await chrome.storage.local.get("psnapCustom");
    const merged = Object.assign({}, psnapCustom || {});
    for (const [k, list] of Object.entries(payload.suggestions)) {
      if (!Array.isArray(list)) continue;
      const key = String(k).slice(0, 40);
      const existing = new Set(merged[key] || []);
      for (const item of list.slice(0, 80)) {
        const v = String(item).slice(0, 160).trim();
        if (v && !existing.has(v)) { existing.add(v); chips++; }
      }
      merged[key] = [...existing];
    }
    patch.psnapCustom = merged;
  }

  if (!Object.keys(patch).length) return { ok: false, reason: "empty" };

  // record that this version's content is installed
  patch.psnapUpdate = Object.assign({}, psnapUpdate, {
    contentInstalled: psnapUpdate.latest,
    available: psnapUpdate.needsReload ? psnapUpdate.available : false
  });

  await chrome.storage.local.set(patch);
  if (!psnapUpdate.needsReload) {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
  }
  return { ok: true, presets, chips, needsReload: !!psnapUpdate.needsReload };
}


/* =====================================================================
 * Canva bridge
 * ===================================================================*/

const CANVA_MATCH = ["https://www.canva.com/design/*", "https://canva.com/design/*"];

function cleanDesignTitle(t) {
  return String(t || "")
    .replace(/\s*[-–|]\s*Canva\s*$/i, "")
    .replace(/^\(\d+\)\s*/, "")
    .trim() || "Untitled design";
}

async function listCanvaTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: CANVA_MATCH });
    return tabs.map(t => ({
      id: t.id,
      title: cleanDesignTitle(t.title),
      url: t.url,
      active: t.active,
      windowId: t.windowId
    }));
  } catch (_) {
    return [];
  }
}

async function sendImageToCanva(tabId, imageUrl) {
  try {
    const res = await fetch(imageUrl);
    if (!res.ok) throw new Error("fetch " + res.status);
    const blob = await res.blob();
    if (blob.size > 20 * 1024 * 1024) throw new Error("too large");

    const b64 = await new Promise((ok, bad) => {
      const fr = new FileReader();
      fr.onload = () => ok(String(fr.result).split(",")[1]);
      fr.onerror = () => bad(new Error("read failed"));
      fr.readAsDataURL(blob);
    });

    // bring the Canva tab forward first — clipboard writes need focus
    try {
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await chrome.tabs.update(tabId, { active: true });
    } catch (_) {}

    await new Promise(r => setTimeout(r, 250));

    const reply = await chrome.tabs.sendMessage(tabId, {
      type: "psnap-insert-image",
      b64,
      mime: blob.type || "image/png",
      name: "promptsnap-" + Date.now() + ".png"
    });
    return reply || { ok: false, reason: "no-reply" };

  } catch (err) {
    return { ok: false, reason: String(err && err.message || err) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;

  if (msg.type === "psnap-canva-tabs") {
    listCanvaTabs().then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-send") {
    sendImageToCanva(msg.tabId, msg.imageUrl).then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-focus") {
    (async () => {
      try {
        const tab = await chrome.tabs.get(msg.tabId);
        await chrome.windows.update(tab.windowId, { focused: true });
        await chrome.tabs.update(msg.tabId, { active: true });
        reply({ ok: true });
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }
});
