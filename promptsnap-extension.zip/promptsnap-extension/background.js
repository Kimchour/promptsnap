/* PromptSnap — update checker (service worker)
 *
 * Fetches a small JSON file you host, compares its version against the
 * installed one, and stores the result. The content script watches that
 * storage key and shows the banner.
 *
 * The JSON looks like:
 *   {
 *     "version": "1.7.0",
 *     "download_url": "https://.../promptsnap-extension.zip",
 *     "notes": "What changed in this version",
 *     "required": false
 *   }
 */

const DEFAULT_FEED =
  "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";

const CHECK_ALARM = "psnap-update-check";
const CHECK_EVERY_MIN = 180;          // 3 hours

/* ---------------------------------------------------------------- utils */

function parseVer(v) {
  return String(v || "0")
    .trim()
    .replace(/^v/i, "")
    .split(".")
    .map(n => parseInt(n, 10) || 0);
}

/** > 0 if a is newer than b */
function cmpVer(a, b) {
  const x = parseVer(a), y = parseVer(b);
  const len = Math.max(x.length, y.length);
  for (let i = 0; i < len; i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

const installedVersion = () => chrome.runtime.getManifest().version;

async function getFeedUrl() {
  const { psnapFeed } = await chrome.storage.local.get("psnapFeed");
  return (psnapFeed && /^https:\/\//i.test(psnapFeed)) ? psnapFeed : DEFAULT_FEED;
}

/* --------------------------------------------------------------- check */

async function checkForUpdate(manual = false) {
  const url = await getFeedUrl();
  const now = Date.now();

  try {
    const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + now, {
      cache: "no-store"
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const data = await res.json();
    const latest = String(data.version || "").trim();
    if (!latest) throw new Error("no version field");

    const current = installedVersion();
    const newer = cmpVer(latest, current) > 0;

    const state = {
      checkedAt: now,
      current,
      latest,
      available: newer,
      notes: String(data.notes || "").slice(0, 600),
      downloadUrl: /^https:\/\//i.test(data.download_url || "") ? data.download_url : "",
      required: !!data.required,
      error: "",
      // changelog for the version the feed is advertising
      added: Array.isArray(data.added) ? data.added.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      fixed: Array.isArray(data.fixed) ? data.fixed.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      // optional past releases, newest first
      history: Array.isArray(data.history) ? data.history.slice(0, 10).map(h => ({
        version: String((h && h.version) || "").slice(0, 20),
        added: Array.isArray(h && h.added) ? h.added.slice(0, 10).map(x => String(x).slice(0,160)) : [],
        fixed: Array.isArray(h && h.fixed) ? h.fixed.slice(0, 10).map(x => String(x).slice(0,160)) : []
      })).filter(h => h.version) : [],
      // content payload — presets and suggestion chips. This is DATA, not
      // code, so it can be applied instantly with no reinstall.
      content: (data.content && typeof data.content === "object") ? data.content : null,
      // true when the update changes actual code and needs a reload
      needsReload: data.needs_reload !== false
    };

    // don't re-nag about a version the user already dismissed
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    if (psnapUpdate && psnapUpdate.dismissed === latest && !state.required && !manual) {
      state.dismissed = latest;
    }

    await chrome.storage.local.set({ psnapUpdate: state });

    if (newer && !state.dismissed) {
      try {
        chrome.action?.setBadgeText?.({ text: "NEW" });
        chrome.action?.setBadgeBackgroundColor?.({ color: "#14c294" });
      } catch (_) {}
    }
    return state;

  } catch (err) {
    const state = {
      checkedAt: now,
      current: installedVersion(),
      latest: "",
      available: false,
      error: String(err && err.message || err).slice(0, 200)
    };
    await chrome.storage.local.set({ psnapUpdate: state });
    return state;
  }
}

/* -------------------------------------------------------------- wiring */

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.alarms.onAlarm.addListener(a => {
  if (a.name === CHECK_ALARM) checkForUpdate();
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "psnap-check-update") {
    checkForUpdate(true).then(reply);
    return true;                       // async response
  }
  if (msg && msg.type === "psnap-clear-badge") {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
    reply({ ok: true });
    return true;
  }
  if (msg && msg.type === "psnap-apply-content") {
    applyContentUpdate().then(reply);
    return true;
  }
  if (msg && msg.type === "psnap-open-extensions") {
    chrome.tabs.create({ url: "chrome://extensions" });
    reply({ ok: true });
    return true;
  }
});


/* ------------------------------------------------- content auto-install
 * Presets and suggestion chips are plain data. We can install those
 * straight into storage without touching any code, so that part of an
 * update really is automatic — no download, no reload, no folder.
 */
async function applyContentUpdate() {
  const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
  const payload = psnapUpdate && psnapUpdate.content;
  if (!payload) return { ok: false, reason: "no-content" };

  const patch = {};
  let presets = 0, chips = 0;

  if (Array.isArray(payload.presets) && payload.presets.length) {
    const clean = payload.presets
      .filter(p => p && typeof p.name === "string" && typeof p.text === "string")
      .slice(0, 200)
      .map(p => ({
        g: String(p.g || "Presets").slice(0, 40),
        name: String(p.name).slice(0, 120),
        text: String(p.text).slice(0, 2000)
      }));
    if (clean.length) { patch.psnapPresets = clean; presets = clean.length; }
  }

  if (payload.suggestions && typeof payload.suggestions === "object") {
    const { psnapCustom } = await chrome.storage.local.get("psnapCustom");
    const merged = Object.assign({}, psnapCustom || {});
    for (const [k, list] of Object.entries(payload.suggestions)) {
      if (!Array.isArray(list)) continue;
      const key = String(k).slice(0, 40);
      const existing = new Set(merged[key] || []);
      for (const item of list.slice(0, 80)) {
        const v = String(item).slice(0, 160).trim();
        if (v && !existing.has(v)) { existing.add(v); chips++; }
      }
      merged[key] = [...existing];
    }
    patch.psnapCustom = merged;
  }

  if (!Object.keys(patch).length) return { ok: false, reason: "empty" };

  // record that this version's content is installed
  patch.psnapUpdate = Object.assign({}, psnapUpdate, {
    contentInstalled: psnapUpdate.latest,
    available: psnapUpdate.needsReload ? psnapUpdate.available : false
  });

  await chrome.storage.local.set(patch);
  if (!psnapUpdate.needsReload) {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
  }
  return { ok: true, presets, chips, needsReload: !!psnapUpdate.needsReload };
}


/* =====================================================================
 * Canva bridge
 * ===================================================================*/

const CANVA_MATCH = ["https://www.canva.com/design/*", "https://canva.com/design/*"];

function cleanDesignTitle(t) {
  return String(t || "")
    .replace(/\s*[-–|]\s*Canva\s*$/i, "")
    .replace(/^\(\d+\)\s*/, "")
    .trim() || "Untitled design";
}

async function listCanvaTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: CANVA_MATCH });
    return tabs.map(t => ({
      id: t.id,
      title: cleanDesignTitle(t.title),
      url: t.url,
      active: t.active,
      windowId: t.windowId
    }));
  } catch (_) {
    return [];
  }
}

/** Make sure canva.js is actually running in that tab.
 * A Canva tab that was already open when the extension was installed or
 * reloaded has NO content script in it — Chrome only injects on
 * navigation. Messaging such a tab fails with "could not establish
 * connection", which is what "Couldn't send" was really reporting.
 */
async function ensureCanvaScript(tabId) {
  // already there?
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "psnap-canva-ping" });
    if (pong && pong.ok) return true;
  } catch (_) { /* not injected yet */ }

  // inject on demand
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ["canva.js"]
    });
  } catch (err) {
    return false;
  }

  // give it a moment to register its listener
  for (let i = 0; i < 10; i++) {
    await new Promise(r => setTimeout(r, 120));
    try {
      const pong = await chrome.tabs.sendMessage(tabId, { type: "psnap-canva-ping" });
      if (pong && pong.ok) return true;
    } catch (_) {}
  }
  return false;
}

async function sendImageToCanva(tabId, imageUrl, b64In, mimeIn) {
  try {
    let b64 = b64In || null;
    let mime = mimeIn || "image/png";

    // The page normally reads the image and hands us the bytes, because
    // ChatGPT often uses blob: URLs that only exist inside that tab.
    // If it couldn't, try the URL from here as a fallback.
    if (!b64) {
      if (/^blob:/i.test(imageUrl || "")) {
        return { ok: false, reason: "image not readable" };
      }
      const res = await fetch(imageUrl);
      if (!res.ok) return { ok: false, reason: "download " + res.status };
      const blob = await res.blob();
      if (blob.size > 20 * 1024 * 1024) return { ok: false, reason: "too large" };
      mime = blob.type || "image/png";
      b64 = await new Promise((ok, bad) => {
        const fr = new FileReader();
        fr.onload = () => ok(String(fr.result).split(",")[1]);
        fr.onerror = () => bad(new Error("read failed"));
        fr.readAsDataURL(blob);
      });
    }

    const ready = await ensureCanvaScript(tabId);
    if (!ready) return { ok: false, reason: "reload the Canva tab" };

    // focus first — the clipboard fallback needs the tab in front
    try {
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await chrome.tabs.update(tabId, { active: true });
    } catch (_) {}

    await new Promise(r => setTimeout(r, 300));

    const reply = await chrome.tabs.sendMessage(tabId, {
      type: "psnap-insert-image",
      b64,
      mime,
      name: "promptsnap-" + Date.now() + ".png"
    });
    return reply || { ok: false, reason: "no reply from Canva tab" };

  } catch (err) {
    return { ok: false, reason: String(err && err.message || err).slice(0, 60) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;

  if (msg.type === "psnap-canva-tabs") {
    listCanvaTabs().then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-send") {
    sendImageToCanva(msg.tabId, msg.imageUrl, msg.b64, msg.mime).then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-meta") {
    (async () => {
      try {
        const ready = await ensureCanvaScript(msg.tabId);
        if (!ready) return reply({ ok: false });
        const meta = await chrome.tabs.sendMessage(msg.tabId, {
          type: "psnap-canva-meta",
          sigOnly: !!msg.sigOnly
        });
        reply(Object.assign({ ok: true }, meta || {}));
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }

  if (msg.type === "psnap-canva-focus") {
    (async () => {
      try {
        const tab = await chrome.tabs.get(msg.tabId);
        await chrome.windows.update(tab.windowId, { focused: true });
        await chrome.tabs.update(msg.tabId, { active: true });
        reply({ ok: true });
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }
});


/* =====================================================================
 * Update download
 * Chrome will not let an unpacked extension replace its own files, so
 * the best we can do here is take the download off the user's hands and
 * drop them straight at the folder.
 * ===================================================================*/

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "psnap-download-update") return;

  (async () => {
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    const url = (psnapUpdate && psnapUpdate.downloadUrl) || "";
    if (!url) { reply({ ok: false, reason: "no download url" }); return; }

    try {
      const id = await chrome.downloads.download({
        url,
        filename: "promptsnap-" + (psnapUpdate.latest || "update") + ".zip",
        saveAs: false
      });

      // tell the panel when it lands, and offer to reveal it
      const onChanged = (delta) => {
        if (delta.id !== id) return;
        if (delta.state && delta.state.current === "complete") {
          chrome.downloads.onChanged.removeListener(onChanged);
          chrome.storage.local.set({ psnapDownloadId: id });
        }
      };
      chrome.downloads.onChanged.addListener(onChanged);

      reply({ ok: true, id });
    } catch (err) {
      reply({ ok: false, reason: String(err && err.message || err).slice(0, 60) });
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "psnap-show-download") return;
  (async () => {
    const { psnapDownloadId } = await chrome.storage.local.get("psnapDownloadId");
    try {
      if (typeof psnapDownloadId === "number") chrome.downloads.show(psnapDownloadId);
      else chrome.downloads.showDefaultFolder();
      reply({ ok: true });
    } catch (_) { reply({ ok: false }); }
  })();
  return true;
});
