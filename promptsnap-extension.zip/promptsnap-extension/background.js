/* PromptSnap — update checker (service worker)
 *
 * Fetches a small JSON file you host, compares its version against the
 * installed one, and stores the result. The content script watches that
 * storage key and shows the banner.
 *
 * The JSON looks like:
 *   {
 *     "version": "1.7.0",
 *     "download_url": "https://.../promptsnap-extension.zip",
 *     "notes": "What changed in this version",
 *     "required": false
 *   }
 */

const DEFAULT_FEED =
  "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";

const CHECK_ALARM = "psnap-update-check";
const CHECK_EVERY_MIN = 180;          // 3 hours

/* ---------------------------------------------------------------- utils */

function parseVer(v) {
  return String(v || "0")
    .trim()
    .replace(/^v/i, "")
    .split(".")
    .map(n => parseInt(n, 10) || 0);
}

/** > 0 if a is newer than b */
function cmpVer(a, b) {
  const x = parseVer(a), y = parseVer(b);
  const len = Math.max(x.length, y.length);
  for (let i = 0; i < len; i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

const installedVersion = () => chrome.runtime.getManifest().version;

async function getFeedUrl() {
  const { psnapFeed } = await chrome.storage.local.get("psnapFeed");
  return (psnapFeed && /^https:\/\//i.test(psnapFeed)) ? psnapFeed : DEFAULT_FEED;
}

/* --------------------------------------------------------------- check */

async function checkForUpdate(manual = false) {
  const url = await getFeedUrl();
  const now = Date.now();

  try {
    const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + now, {
      cache: "no-store"
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const data = await res.json();
    const latest = String(data.version || "").trim();
    if (!latest) throw new Error("no version field");

    const current = installedVersion();
    const newer = cmpVer(latest, current) > 0;

    const state = {
      checkedAt: now,
      current,
      latest,
      available: newer,
      notes: String(data.notes || "").slice(0, 600),
      downloadUrl: /^https:\/\//i.test(data.download_url || "") ? data.download_url : "",
      required: !!data.required,
      error: ""
    };

    // don't re-nag about a version the user already dismissed
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    if (psnapUpdate && psnapUpdate.dismissed === latest && !state.required && !manual) {
      state.dismissed = latest;
    }

    await chrome.storage.local.set({ psnapUpdate: state });

    if (newer && !state.dismissed) {
      try {
        chrome.action?.setBadgeText?.({ text: "NEW" });
        chrome.action?.setBadgeBackgroundColor?.({ color: "#14c294" });
      } catch (_) {}
    }
    return state;

  } catch (err) {
    const state = {
      checkedAt: now,
      current: installedVersion(),
      latest: "",
      available: false,
      error: String(err && err.message || err).slice(0, 200)
    };
    await chrome.storage.local.set({ psnapUpdate: state });
    return state;
  }
}

/* -------------------------------------------------------------- wiring */

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.alarms.onAlarm.addListener(a => {
  if (a.name === CHECK_ALARM) checkForUpdate();
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "psnap-check-update") {
    checkForUpdate(true).then(reply);
    return true;                       // async response
  }
  if (msg && msg.type === "psnap-clear-badge") {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
    reply({ ok: true });
    return true;
  }
  if (msg && msg.type === "psnap-open-extensions") {
    chrome.tabs.create({ url: "chrome://extensions" });
    reply({ ok: true });
    return true;
  }
});
