/* PromptSnap — update checker (service worker)
 *
 * Fetches a small JSON file you host, compares its version against the
 * installed one, and stores the result. The content script watches that
 * storage key and shows the banner.
 *
 * The JSON looks like:
 *   {
 *     "version": "1.7.0",
 *     "download_url": "https://.../promptsnap-extension.zip",
 *     "notes": "What changed in this version",
 *     "required": false
 *   }
 */

const DEFAULT_FEED =
  "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";

const CHECK_ALARM = "psnap-update-check";
const CHECK_EVERY_MIN = 180;          // 3 hours

/* ---------------------------------------------------------------- utils */

function parseVer(v) {
  return String(v || "0")
    .trim()
    .replace(/^v/i, "")
    .split(".")
    .map(n => parseInt(n, 10) || 0);
}

/** > 0 if a is newer than b */
function cmpVer(a, b) {
  const x = parseVer(a), y = parseVer(b);
  const len = Math.max(x.length, y.length);
  for (let i = 0; i < len; i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

const installedVersion = () => chrome.runtime.getManifest().version;

async function getFeedUrl() {
  const { psnapFeed } = await chrome.storage.local.get("psnapFeed");
  return (psnapFeed && /^https:\/\//i.test(psnapFeed)) ? psnapFeed : DEFAULT_FEED;
}

/* --------------------------------------------------------------- check */

async function checkForUpdate(manual = false) {
  const url = await getFeedUrl();
  const now = Date.now();

  try {
    const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + now, {
      cache: "no-store"
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const data = await res.json();
    const latest = String(data.version || "").trim();
    if (!latest) throw new Error("no version field");

    const current = installedVersion();
    const newer = cmpVer(latest, current) > 0;

    const state = {
      checkedAt: now,
      current,
      latest,
      available: newer,
      notes: String(data.notes || "").slice(0, 600),
      downloadUrl: /^https:\/\//i.test(data.download_url || "") ? data.download_url : "",
      required: !!data.required,
      error: "",
      // changelog for the version the feed is advertising
      added: Array.isArray(data.added) ? data.added.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      fixed: Array.isArray(data.fixed) ? data.fixed.slice(0, 12).map(x => String(x).slice(0,160)) : [],
      // optional past releases, newest first
      history: Array.isArray(data.history) ? data.history.slice(0, 10).map(h => ({
        version: String((h && h.version) || "").slice(0, 20),
        added: Array.isArray(h && h.added) ? h.added.slice(0, 10).map(x => String(x).slice(0,160)) : [],
        fixed: Array.isArray(h && h.fixed) ? h.fixed.slice(0, 10).map(x => String(x).slice(0,160)) : []
      })).filter(h => h.version) : [],
      // content payload — presets and suggestion chips. This is DATA, not
      // code, so it can be applied instantly with no reinstall.
      content: (data.content && typeof data.content === "object") ? data.content : null,
      // true when the update changes actual code and needs a reload
      needsReload: data.needs_reload !== false
    };

    // don't re-nag about a version the user already dismissed
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    if (psnapUpdate && psnapUpdate.dismissed === latest && !state.required && !manual) {
      state.dismissed = latest;
    }

    await chrome.storage.local.set({ psnapUpdate: state });

    if (newer && !state.dismissed) {
      try {
        chrome.action?.setBadgeText?.({ text: "NEW" });
        chrome.action?.setBadgeBackgroundColor?.({ color: "#14c294" });
      } catch (_) {}
    }
    return state;

  } catch (err) {
    const state = {
      checkedAt: now,
      current: installedVersion(),
      latest: "",
      available: false,
      error: String(err && err.message || err).slice(0, 200)
    };
    await chrome.storage.local.set({ psnapUpdate: state });
    return state;
  }
}

/* -------------------------------------------------------------- wiring */

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_EVERY_MIN, delayInMinutes: 1 });
  checkForUpdate();
});

chrome.alarms.onAlarm.addListener(a => {
  if (a.name === CHECK_ALARM) checkForUpdate();
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "psnap-check-update") {
    checkForUpdate(true).then(reply);
    return true;                       // async response
  }
  if (msg && msg.type === "psnap-clear-badge") {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
    reply({ ok: true });
    return true;
  }
  if (msg && msg.type === "psnap-apply-content") {
    applyContentUpdate().then(reply);
    return true;
  }
  if (msg && msg.type === "psnap-open-extensions") {
    chrome.tabs.create({ url: "chrome://extensions" });
    reply({ ok: true });
    return true;
  }
});


/* ------------------------------------------------- content auto-install
 * Presets and suggestion chips are plain data. We can install those
 * straight into storage without touching any code, so that part of an
 * update really is automatic — no download, no reload, no folder.
 */
/** A preset's preview spec is plain data: keep only short strings,
    numbers, booleans and short lists of strings. */
function cleanArt(a) {
  if (!a || typeof a !== "object") return null;
  // values end up inside SVG markup, so only plain words and hex colours
  const word = (v) => typeof v === "string" && /^[#a-zA-Z0-9-]{1,24}$/.test(v);
  const side = (o) => {
    if (!o || typeof o !== "object") return undefined;
    const out = {};
    for (const [k, v] of Object.entries(o).slice(0, 16)) {
      if (!/^[a-zA-Z]{1,16}$/.test(k)) continue;
      if (word(v)) out[k] = v;
      else if ((typeof v === "number" && isFinite(v)) || typeof v === "boolean") out[k] = v;
      else if (Array.isArray(v)) out[k] = v.filter(word).slice(0, 6);
    }
    return out;
  };
  if (!word(a.scene) || !word(a.fx)) return null;
  const out = { scene: a.scene, fx: a.fx };
  const b = side(a.before), f = side(a.after);
  if (b) out.before = b;
  if (f) out.after = f;
  return out;
}

async function applyContentUpdate() {
  const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
  const payload = psnapUpdate && psnapUpdate.content;
  if (!payload) return { ok: false, reason: "no-content" };

  const patch = {};
  let presets = 0, chips = 0;

  if (Array.isArray(payload.presets) && payload.presets.length) {
    const clean = payload.presets
      .filter(p => p && typeof p.name === "string" && typeof p.text === "string")
      .slice(0, 200)
      .map(p => {
        const out = {
          g: String(p.g || "Utility").slice(0, 40),
          name: String(p.name).slice(0, 120),
          text: String(p.text).slice(0, 2000)
        };
        if (typeof p.id === "string") out.id = p.id.slice(0, 80);
        if (typeof p.desc === "string") out.desc = p.desc.slice(0, 160);
        if (Array.isArray(p.tags)) out.tags = p.tags.filter(t => typeof t === "string").slice(0, 12).map(t => t.slice(0, 40));
        const art = cleanArt(p.art);
        if (art) out.art = art;
        return out;
      });
    if (clean.length) { patch.psnapPresets = clean; presets = clean.length; }
  }

  if (payload.suggestions && typeof payload.suggestions === "object") {
    const { psnapCustom } = await chrome.storage.local.get("psnapCustom");
    const merged = Object.assign({}, psnapCustom || {});
    for (const [k, list] of Object.entries(payload.suggestions)) {
      if (!Array.isArray(list)) continue;
      const key = String(k).slice(0, 40);
      const existing = new Set(merged[key] || []);
      for (const item of list.slice(0, 80)) {
        const v = String(item).slice(0, 160).trim();
        if (v && !existing.has(v)) { existing.add(v); chips++; }
      }
      merged[key] = [...existing];
    }
    patch.psnapCustom = merged;
  }

  if (!Object.keys(patch).length) return { ok: false, reason: "empty" };

  // record that this version's content is installed
  patch.psnapUpdate = Object.assign({}, psnapUpdate, {
    contentInstalled: psnapUpdate.latest,
    available: psnapUpdate.needsReload ? psnapUpdate.available : false
  });

  await chrome.storage.local.set(patch);
  if (!psnapUpdate.needsReload) {
    try { chrome.action?.setBadgeText?.({ text: "" }); } catch (_) {}
  }
  return { ok: true, presets, chips, needsReload: !!psnapUpdate.needsReload };
}


/* =====================================================================
 * Canva bridge
 * ===================================================================*/

const CANVA_MATCH = ["https://www.canva.com/design/*", "https://canva.com/design/*"];

function cleanDesignTitle(t) {
  return String(t || "")
    .replace(/\s*[-–|]\s*Canva\s*$/i, "")
    .replace(/^\(\d+\)\s*/, "")
    .trim() || "Untitled design";
}

async function listCanvaTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: CANVA_MATCH });
    return tabs.map(t => ({
      id: t.id,
      title: cleanDesignTitle(t.title),
      url: t.url,
      active: t.active,
      windowId: t.windowId
    }));
  } catch (_) {
    return [];
  }
}

/** Make sure canva.js is actually running in that tab.
 * A Canva tab that was already open when the extension was installed or
 * reloaded has NO content script in it — Chrome only injects on
 * navigation. Messaging such a tab fails with "could not establish
 * connection", which is what "Couldn't send" was really reporting.
 */
/** tabs.sendMessage with a time limit. A Canva tab that Chrome has
 * frozen in the background never answers, and a promise that never
 * settles is what used to leave the live preview stuck. */
function tabMsg(tabId, msg, ms = 4000) {
  return Promise.race([
    chrome.tabs.sendMessage(tabId, msg),
    new Promise((_, bad) => setTimeout(() => bad(new Error("timeout")), ms))
  ]);
}

async function ensureCanvaScript(tabId) {
  // already there?
  try {
    const pong = await tabMsg(tabId, { type: "psnap-canva-ping", sigOnly: true }, 2500);
    if (pong && pong.ok) return true;
  } catch (_) { /* not injected yet */ }

  // inject on demand
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ["canva.js"]
    });
  } catch (err) {
    return false;
  }

  // give it a moment to register its listener
  for (let i = 0; i < 10; i++) {
    await new Promise(r => setTimeout(r, 120));
    try {
      const pong = await tabMsg(tabId, { type: "psnap-canva-ping", sigOnly: true }, 1500);
      if (pong && pong.ok) return true;
    } catch (_) {}
  }
  return false;
}

async function sendImageToCanva(tabId, imageUrl, b64In, mimeIn) {
  try {
    let b64 = b64In || null;
    let mime = mimeIn || "image/png";

    // The page normally reads the image and hands us the bytes, because
    // ChatGPT often uses blob: URLs that only exist inside that tab.
    // If it couldn't, try the URL from here as a fallback.
    if (!b64) {
      if (/^blob:/i.test(imageUrl || "")) {
        return { ok: false, reason: "image not readable" };
      }
      const res = await fetch(imageUrl);
      if (!res.ok) return { ok: false, reason: "download " + res.status };
      const blob = await res.blob();
      if (blob.size > 20 * 1024 * 1024) return { ok: false, reason: "too large" };
      mime = blob.type || "image/png";
      b64 = await new Promise((ok, bad) => {
        const fr = new FileReader();
        fr.onload = () => ok(String(fr.result).split(",")[1]);
        fr.onerror = () => bad(new Error("read failed"));
        fr.readAsDataURL(blob);
      });
    }

    const ready = await ensureCanvaScript(tabId);
    if (!ready) return { ok: false, reason: "reload the Canva tab" };

    // focus first — the clipboard fallback needs the tab in front
    try {
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await chrome.tabs.update(tabId, { active: true });
    } catch (_) {}

    await new Promise(r => setTimeout(r, 300));

    const reply = await chrome.tabs.sendMessage(tabId, {
      type: "psnap-insert-image",
      b64,
      mime,
      name: "promptsnap-" + Date.now() + ".png"
    });
    return reply || { ok: false, reason: "no reply from Canva tab" };

  } catch (err) {
    return { ok: false, reason: String(err && err.message || err).slice(0, 60) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;

  if (msg.type === "psnap-canva-tabs") {
    listCanvaTabs().then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-send") {
    sendImageToCanva(msg.tabId, msg.imageUrl, msg.b64, msg.mime).then(reply);
    return true;
  }

  if (msg.type === "psnap-canva-meta") {
    (async () => {
      try {
        const ready = await ensureCanvaScript(msg.tabId);
        if (!ready) return reply({ ok: false });
        const meta = await tabMsg(msg.tabId, {
          type: "psnap-canva-meta",
          sigOnly: !!msg.sigOnly
        }) || {};
        // Sharpest picture available: if that design is the visible tab
        // in its window (e.g. Canva on a second screen), take a real
        // screenshot of the page area. Otherwise use what the Canva tab
        // could draw itself.
        if (!msg.sigOnly) {
          let shot = await screenshotPage(msg.tabId, meta.rect);
          // Canva tab is in the background: it can't draw anything for us,
          // so take a real picture of the page through the debugger.
          // Cached per page + signature, so this only happens when
          // something actually changed.
          if (!shot) shot = await backgroundShot(msg.tabId, meta);
          if (shot) meta.thumb = shot;
        }
        delete meta.rect;
        reply(Object.assign({ ok: true }, meta));
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }

  if (msg.type === "psnap-canva-goto") {
    (async () => {
      try {
        const ready = await ensureCanvaScript(msg.tabId);
        if (!ready) return reply({ ok: false });
        // Real input first (works on a background tab). If the debugger
        // can't attach for any reason, fall back to the in-page attempt.
        let res = await remoteGoto(msg.tabId, msg.dir, msg.page);
        if (!res) {
          res = await tabMsg(msg.tabId, { type: "psnap-canva-goto", dir: msg.dir, page: msg.page }, 8000) || {};
          delete res.rect;
        }
        reply(Object.assign({ ok: false }, res));
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }

  if (msg.type === "psnap-canva-focus") {
    (async () => {
      try {
        const tab = await chrome.tabs.get(msg.tabId);
        await chrome.windows.update(tab.windowId, { focused: true });
        await chrome.tabs.update(msg.tabId, { active: true });
        reply({ ok: true });
      } catch (e) { reply({ ok: false }); }
    })();
    return true;
  }
});


/* =====================================================================
 * Update download
 * Chrome will not let an unpacked extension replace its own files, so
 * the best we can do here is take the download off the user's hands and
 * drop them straight at the folder.
 * ===================================================================*/

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "psnap-download-update") return;

  (async () => {
    const { psnapUpdate } = await chrome.storage.local.get("psnapUpdate");
    const url = (psnapUpdate && psnapUpdate.downloadUrl) || "";
    if (!url) { reply({ ok: false, reason: "no download url" }); return; }

    try {
      const id = await chrome.downloads.download({
        url,
        filename: "promptsnap-" + (psnapUpdate.latest || "update") + ".zip",
        saveAs: false
      });

      // tell the panel when it lands, and offer to reveal it
      const onChanged = (delta) => {
        if (delta.id !== id) return;
        if (delta.state && delta.state.current === "complete") {
          chrome.downloads.onChanged.removeListener(onChanged);
          chrome.storage.local.set({ psnapDownloadId: id });
        }
      };
      chrome.downloads.onChanged.addListener(onChanged);

      reply({ ok: true, id });
    } catch (err) {
      reply({ ok: false, reason: String(err && err.message || err).slice(0, 60) });
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "psnap-show-download") return;
  (async () => {
    const { psnapDownloadId } = await chrome.storage.local.get("psnapDownloadId");
    try {
      if (typeof psnapDownloadId === "number") chrome.downloads.show(psnapDownloadId);
      else chrome.downloads.showDefaultFolder();
      reply({ ok: true });
    } catch (_) { reply({ ok: false }); }
  })();
  return true;
});


/* =====================================================================
 * Canva live view
 * Pushes changes to every open ChatGPT tab, so the panel updates by
 * itself — no Refresh button, no trip through Canva.
 * ===================================================================*/

const CHAT_MATCH = ["https://chatgpt.com/*", "https://chat.openai.com/*"];

async function toChatTabs(msg) {
  try {
    const tabs = await chrome.tabs.query({ url: CHAT_MATCH });
    for (const t of tabs) chrome.tabs.sendMessage(t.id, msg).catch(() => {});
  } catch (_) {}
}

let _tabsTimer = null;
let _lastTabsSig = "";
function scheduleTabsBroadcast() {
  clearTimeout(_tabsTimer);
  _tabsTimer = setTimeout(async () => {
    const tabs = await listCanvaTabs();
    const sig = tabs.map(t => t.id + ":" + t.title).join("|");
    if (sig === _lastTabsSig) return;
    _lastTabsSig = sig;
    toChatTabs({ type: "psnap-canva-tabs-changed", tabs });
  }, 250);
}

const isCanvaUrl = (u) => /^https:\/\/(www\.)?canva\.com\/design\//i.test(u || "");

chrome.tabs.onCreated.addListener(t => { if (isCanvaUrl(t.url || t.pendingUrl)) scheduleTabsBroadcast(); });
chrome.tabs.onRemoved.addListener(() => scheduleTabsBroadcast());
chrome.tabs.onReplaced?.addListener(() => scheduleTabsBroadcast());
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (!("title" in info) && !("url" in info) && info.status !== "complete") return;
  if (isCanvaUrl(tab.url) || "url" in info) scheduleTabsBroadcast();
});

/* A Canva tab tells us its design changed; pass it on. */
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== "psnap-canva-changed") return;
  const tabId = sender && sender.tab && sender.tab.id;
  if (!tabId) return;
  toChatTabs({ type: "psnap-canva-changed", tabId, sig: msg.sig || "" });
  if (msg.titleChanged) scheduleTabsBroadcast();
});

/* Real screenshot of the design page — only possible when that Canva tab
   is the one showing in its window. Cropped to the page and shrunk. */
let _lastShotAt = 0;
async function screenshotPage(tabId, rect) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) return "";
    const win = await chrome.windows.get(tab.windowId);
    if (win.state === "minimized") return "";
    // Chrome allows about two captures a second
    const wait = 600 - (Date.now() - _lastShotAt);
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    _lastShotAt = Date.now();

    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 80 });
    if (!dataUrl) return "";
    const blob = await (await fetch(dataUrl)).blob();
    const full = await createImageBitmap(blob);

    let sx = 0, sy = 0, sw = full.width, sh = full.height;
    if (rect && rect.w > 40 && rect.h > 40 && rect.vw > 0) {
      const k = full.width / rect.vw;             // css px -> screenshot px
      sx = Math.max(0, Math.round(rect.x * k));
      sy = Math.max(0, Math.round(rect.y * k));
      sw = Math.min(full.width - sx, Math.round(rect.w * k));
      sh = Math.min(full.height - sy, Math.round(rect.h * k));
      if (sw < 20 || sh < 20) { sx = 0; sy = 0; sw = full.width; sh = full.height; }
    }
    const scale = Math.min(1, 320 / sw);
    const out = new OffscreenCanvas(Math.max(1, Math.round(sw * scale)), Math.max(1, Math.round(sh * scale)));
    out.getContext("2d").drawImage(full, sx, sy, sw, sh, 0, 0, out.width, out.height);
    const small = await out.convertToBlob({ type: "image/jpeg", quality: 0.78 });
    return await new Promise((ok) => {
      const fr = new FileReader();
      fr.onload = () => ok(String(fr.result));
      fr.onerror = () => ok("");
      fr.readAsDataURL(small);
    });
  } catch (_) {
    return "";
  }
}


/* =====================================================================
 * Driving Canva from the panel
 *
 * Canva ignores clicks made by scripts (they are marked "not trusted"),
 * and a Canva tab in the background doesn't redraw, so it can neither
 * switch pages nor produce a preview. Chrome's debugger API solves both:
 * it sends REAL mouse input, and it can take a screenshot of a
 * background tab, which also makes the tab render a fresh frame.
 * Chrome shows a "PromptSnap started debugging this browser" bar while
 * it's attached; we attach only for the few seconds each action takes.
 * ===================================================================*/

const _cdpLocks = {};
async function withDebugger(tabId, fn) {
  // one session per tab at a time
  while (_cdpLocks[tabId]) await _cdpLocks[tabId].catch(() => {});
  let release;
  _cdpLocks[tabId] = new Promise(r => (release = r));
  const target = { tabId };
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    const send = (m, p) => chrome.debugger.sendCommand(target, m, p || {});
    try { await send("Emulation.setFocusEmulationEnabled", { enabled: true }); } catch (_) {}
    return await fn(send);
  } catch (e) {
    return null;
  } finally {
    if (attached) {
      try { await chrome.debugger.sendCommand(target, "Emulation.setFocusEmulationEnabled", { enabled: false }); } catch (_) {}
      try { await chrome.debugger.detach(target); } catch (_) {}
    }
    delete _cdpLocks[tabId];
    release();
  }
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

/** Make a background tab render one frame. */
async function pump(send) {
  try {
    await send("Page.captureScreenshot", {
      format: "jpeg", quality: 5, clip: { x: 0, y: 0, width: 8, height: 8, scale: 1 }
    });
  } catch (_) {}
}

async function realClick(send, x, y) {
  await send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
  await send("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1 });
  await send("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1 });
}

async function realWheel(send, x, y, dy, dx) {
  await send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
  await send("Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX: dx || 0, deltaY: dy || 0 });
}

/** Screenshot just the design page, shrunk for the panel. */
async function shotSurface(send, surface, vw, vh) {
  let clip;
  if (surface && surface.w > 40 && surface.h > 40) {
    const x = Math.max(0, surface.x), y = Math.max(0, surface.y);
    const w = Math.min(vw || 4000, surface.x + surface.w) - x;
    const h = Math.min(vh || 4000, surface.y + surface.h) - y;
    if (w > 40 && h > 40) clip = { x, y, width: w, height: h, scale: Math.min(1, 360 / w) };
  }
  if (!clip) return "";
  const r = await send("Page.captureScreenshot", { format: "jpeg", quality: 78, clip });
  return (r && r.data) ? "data:image/jpeg;base64," + r.data : "";
}

const locateIn = (tabId, page) =>
  tabMsg(tabId, { type: "psnap-canva-locate", page: page || 0 }, 2500).catch(() => null);

/** Switch page with real input. Returns null if the debugger isn't usable. */
async function remoteGoto(tabId, dir, page) {
  const first = await locateIn(tabId, 0);
  if (!first || !first.pages) return null;
  const target = Math.max(1, Math.min(first.pages, page ? Number(page) : (first.page || 1) + (Number(dir) || 0)));

  return await withDebugger(tabId, async (send) => {
    await pump(send);
    let loc = await locateIn(tabId, target);

    for (let attempt = 0; loc && loc.page !== target && attempt < 8; attempt++) {
      const before = loc.page;
      if (loc.thumb) {
        // 1. click its thumbnail in the page strip
        await realClick(send, loc.thumb.x, loc.thumb.y);
      } else if (loc.surface) {
        // 2. no thumbnail on screen: scroll the editor a page at a time
        const step = Math.round(loc.surface.h * 1.04) || Math.round(loc.vh * 0.6);
        const cx = Math.round(loc.surface.x + loc.surface.w / 2);
        const cy = Math.round(Math.min(loc.vh - 40, Math.max(40, loc.surface.y + loc.surface.h / 2)));
        await realWheel(send, cx, cy, (target > before ? 1 : -1) * step * Math.min(3, Math.abs(target - before)));
      } else if (loc.strip) {
        await realWheel(send, loc.strip.x, loc.strip.y, 0, (target > before ? 1 : -1) * 300);
      } else {
        break;
      }
      // let it render and settle
      for (let i = 0; i < 10; i++) {
        await pump(send);
        await sleep(90);
        loc = await locateIn(tabId, target);
        if (!loc || loc.page === target) break;
        if (loc.page !== before && !loc.thumb) break;   // moved; re-aim
      }
    }

    // a couple more frames so the page is fully drawn, then photograph it
    for (let i = 0; i < 3; i++) { await pump(send); await sleep(120); }
    loc = await locateIn(tabId, 0) || loc || {};
    let thumb = "";
    try { thumb = await shotSurface(send, loc.surface, loc.vw, loc.vh); } catch (_) {}
    if (thumb) _shotCache[tabId] = { key: loc.page + "|" + loc.sig, thumb, at: Date.now() };
    return {
      ok: loc.page === target, page: loc.page || 0, pages: loc.pages || 0,
      title: loc.title || "", sig: loc.sig || "", thumb
    };
  });
}

/* Preview of a background Canva tab — cached per page + design state. */
const _shotCache = {};
async function backgroundShot(tabId, meta) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.active) return "";              // it's on screen; nothing to fix
    const key = (meta.page || 0) + "|" + (meta.sig || "");
    const c = _shotCache[tabId];
    if (c && c.key === key) return c.thumb;
    if (c && Date.now() - c.at < 3000) return c.thumb || "";   // don't hammer it
    _shotCache[tabId] = { key: "pending", thumb: c ? c.thumb : "", at: Date.now() };
    const res = await withDebugger(tabId, async (send) => {
      for (let i = 0; i < 2; i++) { await pump(send); await sleep(100); }
      const loc = await locateIn(tabId, 0);
      if (!loc) return null;
      const thumb = await shotSurface(send, loc.surface, loc.vw, loc.vh);
      return { thumb, key: loc.page + "|" + loc.sig };
    });
    if (res && res.thumb) {
      _shotCache[tabId] = { key: res.key, thumb: res.thumb, at: Date.now() };
      return res.thumb;
    }
    return "";
  } catch (_) { return ""; }
}

chrome.tabs.onRemoved.addListener((id) => { delete _shotCache[id]; });
