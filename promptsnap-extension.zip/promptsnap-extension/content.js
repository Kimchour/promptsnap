/* PromptSnap v1.3 — floating image-prompt builder for ChatGPT
 * - English / Khmer interface (prompt output is ALWAYS English)
 * - preset library with dynamic fields + suggestion chips you can extend
 * - Reset button
 * - smooth FAB animation + "Need a Help?" bubble on image insert
 * - generation tracker with taskbar/tab status and done animation
 */

(() => {
  if (window.__promptSnapLoaded) return;
  window.__promptSnapLoaded = true;

  const I18N     = window.PSNAP_I18N || {};
  const KM_VALS  = window.PSNAP_KM_VALUES || {};
  const KM_PRE   = window.PSNAP_KM_PRESETS || {};

  let lang = "en";
  let soundOn = true;
  let celebration = "full";     // full | classic | off
  let theme = "dark";           // dark | light | auto
  let feedUrl = "";
  let anim = "full";   // full | reduced | minimal | off
  const DEFAULT_FEED =
    "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";
  const T = () => I18N[lang] || I18N.en;

  /** Khmer display label for an English value. Falls back to English. */
  const L = (v) => (lang === "km" && KM_VALS[v]) ? KM_VALS[v] : v;

  // ======================================================================
  // Data — all VALUES below are English and go into the prompt verbatim
  // ======================================================================

  const RATIOS  = ["4:5","1:1","3:4","2:3","9:16","5:4","4:3","3:2","16:9","21:9","Keep original"];
  const QUALITY = ["8K","4K","6K","12K","HD","—"];
  const STYLES  = [
    "editorial / stock image style",
    "photojournalism, wire-service style",
    "raw iPhone photo, unprepared angle",
    "aviation spotter photography",
    "cinematic still",
    "documentary realism",
    "security camera footage",
    "drone / aerial photography",
    "golden hour natural light",
    "clean product shot",
    "vintage film photo, grainy",
    "—"
  ];

  const SUGGESTIONS = {
    angle: [
      "on the runway, side-on / broadside",
      "close up on the runway",
      "head-on, nose filling the frame",
      "three-quarter front view on the taxiway",
      "three-quarter rear view, engines visible",
      "low angle from ground level, looking up",
      "high angle from the terminal window",
      "rotating for takeoff, gear still down",
      "on final approach, gear down, flaps extended",
      "touching down, tyre smoke on contact",
      "parked at the gate with jet bridge attached",
      "tail close up, livery filling the frame",
      "cockpit windows close up",
      "engine nacelle close up",
      "wing view from a passenger window",
      "taxiing through rain, wet tarmac reflections",
      "at night, runway lights glowing",
      "silhouetted against sunset",
      "banking overhead, belly visible",
      "seen through heat haze down the runway"
    ],
    lighting: ["harsh midday sun","golden hour, warm low sun","overcast, flat soft light",
               "blue hour, just after sunset","night, artificial floodlights",
               "backlit, subject in silhouette","stormy grey sky"],
    weather:  ["clear blue sky","heavy rain","light snow","thick fog","windy with low cloud","dust haze"],
    emotion:  ["tense and urgent","quiet and sombre","joyful and chaotic","shocked bystanders","calm aftermath"],
    location: ["busy international airport","small regional airstrip","city street","suburban neighbourhood",
               "hospital corridor","courtroom","police cordon","rural roadside"],
    subject:  ["a middle-aged man","a young woman","an elderly couple","a small child",
               "airport ground crew","police officers","a crowd of onlookers"]
  };

  /* The preset library itself is plain data in presets.js (loaded just
     before this file); its new template words bring their own chips. */
  const LIB = window.PSNAP_LIBRARY || {};
  const ART = window.PSNAP_ART || null;
  const LIB_FIELDS = LIB.fields || {};
  for (const [k, f] of Object.entries(LIB_FIELDS))
    if (f && Array.isArray(f.suggestions) && !SUGGESTIONS[k]) SUGGESTIONS[k] = f.suggestions.slice();

  /** Look a key up only on the object itself: words people type, like
      {constructor}, must never hit Object.prototype. */
  const own = (o, k) => (o && Object.prototype.hasOwnProperty.call(o, k)) ? o[k] : undefined;
  const ownList = (o, k) => { const v = own(o, k); return Array.isArray(v) ? v : []; };

  const slugOf = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "preset";
  const DEFAULT_PRESETS = (Array.isArray(LIB.presets) && LIB.presets.length ? LIB.presets : [
    { id:"free-prompt", g:"Utility", name:"Free Prompt", text:"{free}\n\nAspect ratio {ratio}. {quality} quality." }
  ]).map(p => Object.assign({}, p, { id: p.id || slugOf(p.name) }));

  const RESERVED = new Set(["ratio","quality","style"]);
  const DEFAULT_STATE = () => ({ preset:0, pid:"", ratio:"4:5", quality:"8K", style:STYLES[0], vars:{} });

  let presets = DEFAULT_PRESETS;
  let custom  = {};
  let state   = DEFAULT_STATE();

  // ======================================================================
  // UI shell
  // ======================================================================

  const fabWrap = document.createElement("div");
  fabWrap.id = "psnap-fab-wrap";
  fabWrap.className = "psnap-ui";
  fabWrap.innerHTML = `
    <div id="psnap-bubble">
      <span id="psnap-bubble-dot"></span>
      <span id="psnap-bubble-text"></span>
      <span id="psnap-bubble-x" title="Dismiss">&times;</span>
    </div>
    <button id="psnap-fab" title="PromptSnap  (Ctrl+Shift+Space)">
      <span id="psnap-fab-ring"></span>
      <span id="psnap-fab-tip"></span>
      <span id="psnap-fab-icon" aria-hidden="true">
        <svg class="psnap-star psnap-star-lg" viewBox="0 0 24 24"><path fill="currentColor"
             d="M12 3.2l1.7 4.6 4.6 1.7-4.6 1.7L12 15.8l-1.7-4.6L5.7 9.5l4.6-1.7L12 3.2z"/></svg>
        <svg class="psnap-star psnap-star-sm" viewBox="0 0 24 24"><path fill="currentColor"
             d="M18.2 14.4l.85 2.3 2.3.85-2.3.85-.85 2.3-.85-2.3-2.3-.85 2.3-.85.85-2.3z"/></svg>
        <svg class="psnap-star psnap-star-xs" viewBox="0 0 24 24"><path fill="currentColor"
             d="M5.6 15.1l.6 1.6 1.6.6-1.6.6-.6 1.6-.6-1.6L3.4 17.3l1.6-.6.6-1.6z"/></svg>
      </span>
      <span id="psnap-fab-pct"></span>
      <span id="psnap-fab-check">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8"
             stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5.5 12.6l4.1 4.1L18.6 7.8"/></svg>
      </span>
      <span id="psnap-fab-ripple"></span>
      <span id="psnap-fab-orbit"><span class="psnap-orbit-spin"><i></i><i></i></span></span>
    </button>
    <div id="psnap-fab-chip" aria-hidden="true">
      <b id="psnap-chip-pct"></b><span id="psnap-chip-text"></span>
    </div>
  `;

  const panel = document.createElement("div");
  panel.id = "psnap-panel";
  panel.className = "psnap-ui";
  panel.innerHTML = `
    <div class="psnap-head" id="psnap-head">
      <div class="psnap-brand">
        <span class="psnap-logo" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path fill="currentColor"
               d="M12 3.2l1.7 4.6 4.6 1.7-4.6 1.7L12 15.8l-1.7-4.6L5.7 9.5l4.6-1.7L12 3.2z"/><path fill="currentColor"
               opacity=".8" d="M18.2 14.4l.85 2.3 2.3.85-2.3.85-.85 2.3-.85-2.3-2.3-.85 2.3-.85.85-2.3z"/></svg>
        </span>
        <span class="psnap-brand-text">
          <strong>PromptSnap</strong>
          <span class="psnap-mark">Created By Oeng Kimchour</span>
        </span>
      </div>
      <span id="psnap-status"></span>
      <button id="psnap-gear" class="psnap-iconbtn" title="Settings"></button>
      <div class="psnap-langsw" id="psnap-langsw">
        <button data-lang="en" class="psnap-lang psnap-lang-on">EN</button>
        <button data-lang="km" class="psnap-lang">ខ្មែរ</button>
      </div>
      <button id="psnap-close" title="Close" aria-label="Close">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="psnap-job" id="psnap-job" hidden>
      <span class="psnap-job-artbox"><canvas class="psnap-job-art" id="psnap-job-art" aria-hidden="true"></canvas></span>
      <div class="psnap-job-info">
        <div class="psnap-job-row">
          <span class="psnap-job-stage" id="psnap-job-stage"></span>
          <span class="psnap-job-pct" id="psnap-job-pct"></span>
        </div>
        <div class="psnap-job-track" id="psnap-job-track"><i></i></div>
        <div class="psnap-job-row psnap-job-meta">
          <span id="psnap-job-time"></span>
          <span id="psnap-job-eta"></span>
        </div>
      </div>
      <button class="psnap-job-view" id="psnap-job-view" type="button" hidden></button>
    </div>
    <div class="psnap-update" id="psnap-update" hidden>
      <div class="psnap-up-main">
        <span class="psnap-up-dot"></span>
        <div class="psnap-up-text">
          <strong id="psnap-up-title"></strong>
          <span id="psnap-up-sub"></span>
        </div>
      </div>
      <div id="psnap-up-notes" class="psnap-up-notes" hidden></div>
      <div class="psnap-up-actions">
        <button class="psnap-btn psnap-up-later" id="psnap-up-later"></button>
        <button class="psnap-btn psnap-primary" id="psnap-up-go"></button>
      </div>
    </div>
    <div class="psnap-settings" id="psnap-settings" hidden>
      <div class="psnap-set-row">
        <span id="set-lbl-sound"></span>
        <div class="psnap-seg" id="set-sound"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-cel"></span>
        <div class="psnap-seg" id="set-cel"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-theme"></span>
        <div class="psnap-seg" id="set-theme"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-size"></span>
        <div class="psnap-seg" id="set-size"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-anim"></span>
        <div class="psnap-seg" id="set-anim"></div>
      </div>
      <div class="psnap-set-divider"></div>
      <div class="psnap-set-row">
        <span id="set-lbl-updates"></span>
        <button class="psnap-minibtn" id="set-check"></button>
      </div>
      <div class="psnap-set-meta" id="set-upmeta"></div>
    </div>
    <div class="psnap-body">
      <div class="psnap-label psnap-plabel">
        <span id="lbl-preset"></span>
        <button type="button" class="psnap-browse" id="psnap-browse"></button>
      </div>
      <div class="psnap-pick">
        <button type="button" class="psnap-pcard" id="psnap-pcard" aria-haspopup="dialog">
          <span class="psnap-pcard-art" id="psnap-pcard-art"></span>
          <span class="psnap-pcard-info">
            <span class="psnap-pcard-cat" id="psnap-pcard-cat"></span>
            <span class="psnap-pcard-name" id="psnap-pcard-name"></span>
            <span class="psnap-pcard-desc" id="psnap-pcard-desc"></span>
          </span>
          <span class="psnap-pcard-go" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                 stroke-linejoin="round"><rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/></svg>
          </span>
        </button>
        <div class="psnap-favrow" id="psnap-favrow" hidden></div>
      </div>

      <label class="psnap-label"><span id="lbl-ratio"></span></label>
      <div class="psnap-chips" id="psnap-ratios"></div>

      <div class="psnap-row" style="margin-top:10px">
        <div><label class="psnap-label"><span id="lbl-quality"></span></label><select id="psnap-quality"></select></div>
        <div><label class="psnap-label"><span id="lbl-style"></span></label><select id="psnap-style"></select></div>
      </div>

      <div id="psnap-vars"></div>

      <label class="psnap-label">
        <span id="lbl-final"></span>
        <span class="psnap-en-tag">EN</span>
      </label>
      <div id="psnap-preview"></div>
      <div class="psnap-hint" id="psnap-hint"></div>
    </div>
    <div class="psnap-canva" id="psnap-canva" hidden>
      <button class="psnap-canva-head" id="psnap-canva-head">
        <span class="psnap-canva-chev" id="psnap-canva-chev">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"
               stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>
        </span>
        <span class="psnap-canva-label" id="psnap-canva-lbl"></span>
        <span class="psnap-canva-count" id="psnap-canva-count"></span>
        <span class="psnap-canva-current" id="psnap-canva-current"></span>
        <span class="psnap-canva-refresh" id="psnap-canva-refresh" title="Refresh"></span>
      </button>
      <div class="psnap-canva-drawer" id="psnap-canva-drawer">
        <div class="psnap-canva-inner">
          <div class="psnap-canva-tabs" id="psnap-canva-tabs" role="tablist"></div>
          <div class="psnap-canva-preview" id="psnap-canva-preview" hidden>
            <div class="psnap-canva-thumb" id="psnap-canva-thumb"></div>
            <div class="psnap-canva-meta">
              <strong id="psnap-canva-name"></strong>
              <div class="psnap-canva-nav">
                <button type="button" class="psnap-canva-arrow" id="psnap-canva-prev">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"
                       stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>
                </button>
                <span id="psnap-canva-pages"></span>
                <button type="button" class="psnap-canva-arrow" id="psnap-canva-next">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"
                       stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>
                </button>
              </div>
            </div>
            <button class="psnap-canva-go" id="psnap-canva-go" type="button">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
                   stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>
            </button>
          </div>
        </div>
      </div>
      <div class="psnap-canva-actions">
        <button class="psnap-btn psnap-canva-send" id="psnap-canva-send"></button>
        <div class="psnap-canva-note" id="psnap-canva-note"></div>
      </div>
    </div>
    <div class="psnap-foot">
      <button class="psnap-btn psnap-icon-btn psnap-reset" id="psnap-reset">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"
             stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 2.6-6.4"/><path d="M3 4v5h5"/></svg>
      </button>
      <button class="psnap-btn psnap-icon-btn" id="psnap-copy">
        <svg class="psnap-i-copy" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
             stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2.5"/>
             <path d="M5 15H4.5A1.5 1.5 0 0 1 3 13.5v-9A1.5 1.5 0 0 1 4.5 3h9A1.5 1.5 0 0 1 15 4.5V5"/></svg>
        <svg class="psnap-i-done" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"
             stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
      </button>
      <button class="psnap-btn psnap-insert" id="psnap-insert">
        <span class="psnap-btn-label"></span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"
             stroke-linejoin="round"><path d="M12 4v11"/><path d="M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>
      </button>
      <button class="psnap-btn psnap-primary psnap-send" id="psnap-send">
        <span class="psnap-btn-label"></span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"
             stroke-linejoin="round"><path d="M21 3L10 14"/><path d="M21 3l-6.5 18-4.5-7-7-4.5L21 3z"/></svg>
      </button>
    </div>
  `;

  const toast = document.createElement("div");
  toast.id = "psnap-toast";
  toast.className = "psnap-ui";
  toast.innerHTML = `
    <div class="psnap-toast-ring"><div class="psnap-toast-check">&#10003;</div></div>
    <div class="psnap-toast-text"><strong id="psnap-toast-title"></strong><span id="psnap-toast-sub"></span></div>
  `;

  document.body.appendChild(fabWrap);
  document.body.appendChild(panel);
  document.body.appendChild(toast);
  if (ART) ART.ensureDefs(document);      // shared gradients and filters for the previews

  const fab    = fabWrap.querySelector("#psnap-fab");
  const bubble = fabWrap.querySelector("#psnap-bubble");
  const $  = (s) => panel.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

  const qualSel   = $("#psnap-quality");
  const styleSel  = $("#psnap-style");
  const ratioWrap = $("#psnap-ratios");

  // ======================================================================
  // Language
  // ======================================================================

  function presetLabel(p) {
    return (lang === "km" && KM_PRE[p.name]) ? KM_PRE[p.name] : p.name;
  }
  function fieldLabel(n) {
    const f = own(T().fields, n);
    if (typeof f === "string" && f) return f;
    const lf = own(LIB_FIELDS, n);
    if (lf && typeof lf.label === "string") return lf.label;
    return n.replace(/_/g," ").replace(/\b\w/g, c => c.toUpperCase());
  }

  function applyLanguage() {
    const t = T();
    panel.classList.toggle("psnap-km", lang === "km");

    $("#lbl-preset").textContent  = t.preset;
    $("#lbl-ratio").textContent   = t.ratio;
    $("#lbl-quality").textContent = t.quality;
    $("#lbl-style").textContent   = t.style;
    $("#lbl-final").textContent   = t.finalPrompt;

    $("#psnap-reset").title        = t.reset + " — " + t.resetTip;
    $("#psnap-reset").setAttribute("aria-label", t.reset);
    $("#psnap-copy").title         = t.copy;
    $("#psnap-copy").setAttribute("aria-label", t.copy);
    $("#psnap-insert .psnap-btn-label").textContent = t.insert;
    $("#psnap-insert").title        = t.insertTip;
    $("#psnap-send .psnap-btn-label").textContent   = t.send;
    $("#psnap-send").title          = t.sendTip;

    panel.querySelectorAll(".psnap-lang").forEach(b =>
      b.classList.toggle("psnap-lang-on", b.dataset.lang === lang));
    if (!$("#psnap-settings").hidden) paintSettings();
    $("#psnap-gear").title = T().settings;

    libDirty = true;                 // card labels are in the old language
    fillPresets();
    fillRatios();
    fillSelects();
    buildVars();
    render();
    hintDefault();
  }

  function fillSelects() {
    const t = T();
    qualSel.innerHTML = QUALITY.map(q =>
      `<option value="${esc(q)}">${q === "—" ? t.none : esc(q)}</option>`).join("");
    styleSel.innerHTML = STYLES.map(s =>
      `<option value="${esc(s)}">${s === "—" ? t.none : esc(L(s))}</option>`).join("");
    qualSel.value  = state.quality;
    styleSel.value = state.style;
  }

  function fillRatios() {
    ratioWrap.innerHTML = RATIOS.map(r =>
      `<span class="psnap-chip" data-r="${esc(r)}">${r === "Keep original" ? esc(T().keepOriginal) : r}</span>`
    ).join("");
    paintRatios();
  }

  // ======================================================================
  // Preset library
  // The panel shows the chosen preset as a card with its before → after
  // preview; clicking it opens the library window: categories, search
  // (English and Khmer), favourites, recents, your own presets, and a
  // preview for every preset that you can scrub across to compare.
  // ======================================================================

  const GROUP_ORDER = ["Enhance","Edit","Portrait","Product","Style","Social","Aviation","Story","Utility"];
  const GROUP_HUE = {
    Enhance:"#14c294", Edit:"#5b9dff", Portrait:"#ff8fab", Product:"#f5b041", Style:"#b38cff",
    Social:"#ff7a59", Aviation:"#3fc1f3", Story:"#e2ad5b", Utility:"#98a3b0", Mine:"#2fd6a6"
  };
  const hueOf = (g) => GROUP_HUE[g] || "#98a3b0";
  const SVG_ATTR = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
                   'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"';
  const ICON_PATHS = {
    all:      '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/>',
    fav:      '<path d="M12 3.8l2.45 5 5.5.8-3.98 3.88.94 5.47L12 16.36l-4.91 2.59.94-5.47L4.05 9.6l5.5-.8z"/>',
    recent:   '<circle cx="12" cy="12" r="8.2"/><path d="M12 7.8V12l2.8 1.9"/>',
    Mine:     '<path d="M4.5 19.5h3.8L19 8.8a2.2 2.2 0 0 0-3.1-3.1L5.2 16.4z"/><path d="M14.3 7.3l2.9 2.9"/>',
    Enhance:  '<path d="M11 3.8l1.7 4.5 4.5 1.7-4.5 1.7L11 16.2l-1.7-4.5L4.8 10l4.5-1.7z"/><path d="M18 14.6l.75 1.9 1.9.75-1.9.75-.75 1.9-.75-1.9-1.9-.75 1.9-.75z"/>',
    Edit:     '<path d="M4.5 19.5l10-10"/><path d="M13 7l2.5 2.5"/><path d="M17 3.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z"/><path d="M19.5 12.5l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2-1.2-.5 1.2-.5z"/>',
    Portrait: '<circle cx="12" cy="8.6" r="3.7"/><path d="M5 19.8c.8-3.5 3.6-5.5 7-5.5s6.2 2 7 5.5"/>',
    Product:  '<path d="M5.2 8.2h13.6l-1.1 10.6a1.6 1.6 0 0 1-1.6 1.4H7.9a1.6 1.6 0 0 1-1.6-1.4z"/><path d="M9 8.2V7a3 3 0 0 1 6 0v1.2"/>',
    Style:    '<path d="M12 3.6a8.4 8.4 0 1 0 0 16.8c1.2 0 1.8-.7 1.8-1.6 0-1.2-1.1-1.5-1.1-2.7 0-.9.7-1.5 1.6-1.5h2.2a3.9 3.9 0 0 0 3.9-3.9c0-3.9-3.8-7.1-8.4-7.1z"/><circle cx="7.9" cy="11.2" r=".9" fill="currentColor"/><circle cx="10.4" cy="7.6" r=".9" fill="currentColor"/><circle cx="14.8" cy="7.8" r=".9" fill="currentColor"/>',
    Social:   '<rect x="4" y="4" width="16" height="16" rx="4.6"/><circle cx="12" cy="12" r="3.5"/><circle cx="16.6" cy="7.4" r=".7" fill="currentColor"/>',
    Aviation: '<path d="M10.6 4.2c0-.8.6-1.4 1.4-1.4s1.4.6 1.4 1.4v4.9l6.8 4.1v1.9l-6.8-2v4.4l2.1 1.6v1.6L12 20l-3.5.7v-1.6l2.1-1.6v-4.4l-6.8 2v-1.9l6.8-4.1z"/>',
    Story:    '<path d="M5 5.2h10.6v14.3H6.6A1.6 1.6 0 0 1 5 17.9z"/><path d="M15.6 9h3.4v8.9a1.6 1.6 0 0 1-3.2 0"/><path d="M8.2 9h4.4M8.2 12h4.4M8.2 15h2.6"/>',
    Utility:  '<path d="M4 7.5h9M17.5 7.5H20M4 16.5h3.5M11.5 16.5H20"/><circle cx="15.3" cy="7.5" r="2.1"/><circle cx="9.5" cy="16.5" r="2.1"/>',
    plus:     '<path d="M12 5v14M5 12h14"/>',
    search:   '<circle cx="11" cy="11" r="6.4"/><path d="M20 20l-4.2-4.2"/>',
    close:    '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    copy:     '<rect x="8.5" y="8.5" width="11" height="11" rx="2.4"/><path d="M5.5 15.5h-.2A1.3 1.3 0 0 1 4 14.2V5.3A1.3 1.3 0 0 1 5.3 4h8.9a1.3 1.3 0 0 1 1.3 1.3v.2"/>',
    pencil:   '<path d="M4.5 19.5h3.8L19 8.8a2.2 2.2 0 0 0-3.1-3.1L5.2 16.4z"/>',
    back:     '<path d="M15 5.5L8.5 12l6.5 6.5"/>',
    trash:    '<path d="M5 7h14M10 7V5.2h4V7M7 7l.8 11.6a1.6 1.6 0 0 0 1.6 1.4h5.2a1.6 1.6 0 0 0 1.6-1.4L17 7"/>'
  };
  const icon = (k) => `<svg ${SVG_ATTR}>${ICON_PATHS[k] || ICON_PATHS.all}</svg>`;
  const STAR = `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3.8l2.45 5 5.5.8-3.98 3.88.94 5.47L12 16.36l-4.91 2.59.94-5.47L4.05 9.6l5.5-.8z"/></svg>`;

  let fav = [];         // preset ids, in the order you starred them
  let recent = [];      // preset ids, newest first
  let mine = [];        // your own presets
  let storedPresets = null;   // presets a content update installed

  const KM_DESC = window.PSNAP_KM_DESCS || {};
  const KM_TAGS = window.PSNAP_KM_TAGS || {};
  const presetDesc = (p) => (lang === "km" && p.desc && KM_DESC[p.desc]) ? KM_DESC[p.desc] : (p.desc || "");
  const groupLabel = (g) => (T().groups || {})[g] || ((I18N.en && I18N.en.groups) || {})[g] || g;
  const catLabel = (p) => p.mine ? T().libMine : groupLabel(p.g);
  /** First words of the prompt, for presets that have no description. */
  const snippet = (p) => String(p.text || "").replace(/\{(\w+)\}/g, (_, k) => fieldLabel(fieldKey(p, k))).replace(/\s+/g, " ").slice(0, 90);

  // --- preview art -------------------------------------------------------
  const artSpec = (p) => (p && p.art && p.art.scene) ? p.art : (ART ? ART.guess(p) : null);
  /* Previews are images (one cached <img> per side). If this page ever
     refused blob images, they fall back to inline SVG. */
  const artCache = new Map();
  let artInline = false;
  function artFor(p, solo) {
    if (!ART || !p) return "";
    const spec = artSpec(p);
    const key = (artInline ? "i" : "p") + (solo ? "1" : "2") + JSON.stringify(spec);
    let h = artCache.get(key);
    if (h == null) {
      try {
        h = artInline ? (solo ? ART.after(spec) : ART.html(spec))
                      : (solo ? ART.pictureAfter(spec) : ART.picture(spec));
      } catch (_) { h = ""; }
      artCache.set(key, h);
    }
    return h;
  }
  /** Put a preview into `el`; its bitmaps arrive as they are drawn. */
  function putArt(el, html) {
    if (!el) return;
    el.innerHTML = html;
    if (ART && !artInline) ART.hydrate(el);
  }
  /** Draw every preset's preview ahead of time, in idle moments, so the
      library opens with its pictures ready. Starts once the panel has
      been opened: a tab that never uses PromptSnap pays nothing. */
  let panelUsed = false, _prewarmT = 0;
  function prewarmArt() {
    if (!ART || artInline) return;
    clearTimeout(_prewarmT);
    _prewarmT = setTimeout(() => {
      // the card and favourites first, then outwards from the preset in use
      // (that is where the library opens), so what shows first is drawn first
      const specs = [];
      const cur = presets[state.preset];
      if (cur) specs.push(artSpec(cur));
      fav.forEach(id => { const i = indexOfId(id); if (i >= 0) specs.push(artSpec(presets[i])); });
      const c = state.preset;
      for (let d = 0; d < presets.length; d++) {
        if (presets[c + d]) specs.push(artSpec(presets[c + d]));
        if (d && presets[c - d]) specs.push(artSpec(presets[c - d]));
      }
      try { ART.prewarm(specs); } catch (_) {}
      // build the library's cards now too, hidden, so the first open costs
      // no more than any later one
      const idle = window.requestIdleCallback ? (fn) => requestIdleCallback(fn, { timeout: 2000 }) : (fn) => setTimeout(fn, 200);
      idle(() => {
        try {
          if (libOpen) return;
          ensureLib();
          if (libDirty || !rendered) { view.cat = "all"; view.q = ""; renderLib(false); }
        } catch (_) {}
      });
    }, 300);
  }
  document.addEventListener("error", (e) => {
    const el = e.target;
    if (artInline || !el || el.tagName !== "IMG" || !el.closest || !el.closest(".psa-img")) return;
    artInline = true;
    console.warn("[PromptSnap] preview images blocked here; drawing them inline");
    const row = $("#psnap-favrow"); if (row) row._key = "";
    inspected = -1;
    fillPresets();
    if (libOpen) inspect(state.preset, true);
    if (lib) { cardEls.forEach(c => { const s0 = c.firstElementChild; if (s0._done) { s0._done = false; fillArt(s0); } }); inspected = -1; }
  }, true);
  /** Sweep a preview's divider in from the right edge, showing the result. */
  function sweep(psa, from) {
    if (!psa || !smoothOK()) return;
    psa.classList.add("psa-live");
    psa.style.setProperty("--psa-split", (from ?? 100) + "%");
    // the start pose is committed in one frame and released in the next, so
    // the browser never has to lay the page out just to start a wipe
    requestAnimationFrame(() => requestAnimationFrame(() => {
      psa.classList.remove("psa-live");
      psa.style.removeProperty("--psa-split");
    }));
  }

  // --- the library in use --------------------------------------------------
  /** Built-in presets, then anything a content update installed (matched
      by name, so an update can refresh a built-in preset or add new
      ones), then your own presets. */
  function buildLibrary(stored) {
    const list = DEFAULT_PRESETS.map(p => Object.assign({}, p));
    const byName = new Map(list.map(p => [p.name.toLowerCase(), p]));
    const ids = new Set(list.map(p => p.id));
    const uniq = (id) => { let k = id, n = 2; while (ids.has(k)) k = id + "-" + n++; ids.add(k); return k; };
    if (Array.isArray(stored)) for (const s of stored) {
      if (!s || typeof s.name !== "string" || typeof s.text !== "string") continue;
      const hit = byName.get(s.name.toLowerCase());
      if (hit) {
        hit.text = s.text;
        if (s.desc) hit.desc = s.desc;
        if (s.art && s.art.scene) hit.art = s.art;
        if (Array.isArray(s.tags)) hit.tags = s.tags;
        continue;
      }
      // names the library uses itself can't be categories
      const g = typeof s.g === "string" && s.g && !["all", "fav", "recent", "Mine", "|"].includes(s.g) ? s.g : "Utility";
      const p = { id: uniq(slugOf(s.id || s.name)), g, name: s.name, text: s.text,
                  desc: s.desc || "", art: (s.art && s.art.scene) ? s.art : null,
                  tags: Array.isArray(s.tags) ? s.tags : [] };
      list.push(p);
      byName.set(p.name.toLowerCase(), p);
    }
    for (const m of mine) {
      if (!m || typeof m.name !== "string" || typeof m.text !== "string" || !m.id) continue;
      list.push({ id: uniq(m.id), g: "Mine", name: m.name, text: m.text, desc: "",
                  art: (m.art && m.art.scene) ? m.art : null, tags: [], mine: true });
    }
    return list;
  }
  function setPreset(i) {
    state.preset = Math.max(0, Math.min(presets.length - 1, i | 0));
    state.pid = presets[state.preset].id;
  }
  /** Rebuild the library and keep the selection on the same preset. */
  function setLibrary() {
    const pid = state.pid || (presets[state.preset] && presets[state.preset].id);
    presets = buildLibrary(storedPresets);
    const i = presets.findIndex(p => p.id === pid);
    if (i >= 0) setPreset(i);
    else {
      // the preset in use is gone (deleted, or dropped by an update):
      // land where a fresh start would, and remember that
      setPreset(0);
      _shownPrompt = null;
      save();
    }
    libDirty = true;
    inspected = -1;
  }
  const indexOfId = (id) => presets.findIndex(p => p.id === id);

  // --- the card in the panel -------------------------------------------------
  /** Paint the chosen preset into the panel's card ("swap" sweeps the
      preview so you can see what the new preset does). */
  function fillPresets(how) {
    const t = T(), p = presets[state.preset];
    if (!p) return;
    const card = $("#psnap-pcard");
    card.style.setProperty("--g", hueOf(p.mine ? "Mine" : p.g));
    $("#psnap-pcard-cat").innerHTML = `<i></i>${esc(catLabel(p))}`;
    $("#psnap-pcard-name").textContent = presetLabel(p);
    $("#psnap-pcard-desc").textContent = presetDesc(p) || snippet(p);
    card.title = t.libOpen;
    card.setAttribute("aria-label", `${t.preset}: ${presetLabel(p)}. ${t.libOpen}`);
    const box = $("#psnap-pcard-art");
    if (panelUsed) {              // a hidden panel draws nothing
      const html = artFor(p);
      if (box._html !== html) { putArt(box, html); box._html = html; }
    }
    $("#psnap-browse").innerHTML = `${esc(t.libBrowse)}<b>${presets.length}</b>`;
    paintFavRow();
    if (how === "swap") {
      sweep(box.querySelector(".psa"));
      if (smoothOK()) replay(card, "psnap-swap", 500);
    }
    if (libOpen && !libDirty) paintCardStates();
  }

  /** Favourites as one-tap thumbnails under the card. */
  function paintFavRow() {
    const row = $("#psnap-favrow");
    const items = fav.map(indexOfId).filter(i => i >= 0).slice(0, 10);
    if (!items.length || !panelUsed) { row.hidden = true; row.innerHTML = ""; row._key = ""; return; }
    const t = T();
    row.hidden = false;
    const key = items.map(i => presets[i].id + ":" + presetLabel(presets[i]) + ":" + JSON.stringify(artSpec(presets[i]))).join(",") + "|" + lang;
    if (row._key !== key) {        // rebuild only when the set changes (keeps keyboard focus)
      const focusedId = row.contains(document.activeElement) && document.activeElement.dataset.i != null
        ? (presets[+document.activeElement.dataset.i] || {}).id : null;
      row._key = key;
      putArt(row, `<span class="psnap-favrow-lbl" title="${esc(t.libFav)}">${STAR}</span>` + items.map(i => {
        const p = presets[i];
        return `<button type="button" class="psnap-fv" data-i="${i}" ` +
               `title="${esc(presetLabel(p))}" aria-label="${esc(presetLabel(p))}">${artFor(p, true)}</button>`;
      }).join(""));
      if (focusedId) { const b = row.querySelector(`.psnap-fv[data-i="${indexOfId(focusedId)}"]`); if (b) b.focus(); }
    }
    row.querySelectorAll(".psnap-fv").forEach(b => {
      const on = +b.dataset.i === state.preset;
      b.classList.toggle("psnap-fv-on", on);
      b.setAttribute("aria-current", on ? "true" : "false");
    });
  }

  /** Choose a preset. `src` is the element it was picked from: its
      preview flies into the panel's card. */
  function pickPreset(i, src, browsing) {
    if (i < 0 || i >= presets.length) return;
    const changed = i !== state.preset;
    setPreset(i);
    const id = presets[i].id;
    if (!browsing) {          // stepping through with the arrow keys isn't "using" each one
      recent = [id, ...recent.filter(x => x !== id)].slice(0, 12);
      persist({ psnapRecent: recent });
    }
    if (changed) {
      _shownPrompt = null;            // a whole new prompt: fade it in, don't mark every word
      buildVars(); render(); save();
      freshen($("#psnap-preview"));
      const vars = $("#psnap-vars");
      vars.classList.remove("psnap-vars-in"); void vars.offsetWidth; vars.classList.add("psnap-vars-in");
      clearTimeout(vars._t); vars._t = setTimeout(() => vars.classList.remove("psnap-vars-in"), 800);
    }
    fillPresets();
    const flew = src && changed ? flyTo(src, $("#psnap-pcard-art")) : false;
    if (libOpen) closeLib(true);
    if (!flew && changed) {
      sweep($("#psnap-pcard-art .psa"));
      if (smoothOK()) replay($("#psnap-pcard"), "psnap-swap", 500);
    }
  }

  /** Shared-element flight: a copy of the picked preview travels on a
      gentle curve into the panel's card while the library fades away. */
  function flyTo(srcEl, dst) {
    const src = srcEl && (srcEl.matches(".psa") ? srcEl : srcEl.querySelector(".psa"));
    if (!src || !dst || !src.animate || !smoothOK() || !panel.classList.contains("psnap-shown")) return false;
    const body = panel.querySelector(".psnap-body");
    if (body.scrollTop > 0) body.scrollTop = 0;
    const a = src.getBoundingClientRect(), b = dst.getBoundingClientRect();
    if (!a.width || !b.width || b.bottom < 0 || b.top > innerHeight) return false;

    const ghost = document.createElement("div");
    ghost.className = "psnap-ui psnap-fly";
    ghost.innerHTML = `<div class="psnap-fly-x"><div class="psnap-fly-y"></div></div>`;
    const clone = src.cloneNode(true);
    clone.classList.remove("psa-live");
    clone.style.removeProperty("--psa-split");
    ghost.querySelector(".psnap-fly-y").appendChild(clone);
    if (ART && !artInline) ART.hydrate(clone);
    Object.assign(ghost.style, { left: a.left + "px", top: a.top + "px", width: a.width + "px", height: a.height + "px" });
    document.body.appendChild(ghost);
    dst.classList.add("psnap-await");

    const dur = 620;
    const sx = b.width / a.width, sy = b.height / a.height;
    // x and y ease differently, so the path curves instead of going straight
    ghost.firstChild.animate([{ transform: "none" }, { transform: `translateX(${b.left - a.left}px)` }],
      { duration: dur, easing: "cubic-bezier(.45,0,.2,1)", fill: "forwards" });
    ghost.firstChild.firstChild.animate([{ transform: "none" }, { transform: `translateY(${b.top - a.top}px)` }],
      { duration: dur, easing: "cubic-bezier(.3,.65,.1,1)", fill: "forwards" });
    const s = clone.animate([
      { transform: "none", borderRadius: "12px", boxShadow: "0 24px 50px -16px rgba(0,0,0,.55)" },
      { transform: `scale(${(1 + sx) / 2 * 1.04}, ${(1 + sy) / 2 * 1.04})`, offset: .45 },
      { transform: `scale(${sx}, ${sy})`, borderRadius: (10 / Math.min(sx, sy)).toFixed(1) + "px",
        boxShadow: "0 0 0 0 rgba(0,0,0,0)" }
    ], { duration: dur, easing: "cubic-bezier(.35,0,.15,1)", fill: "forwards" });
    let done = false;
    const land = () => {
      if (done) return; done = true;
      dst.classList.remove("psnap-await");
      const card = $("#psnap-pcard");
      replay(card, "psnap-landed", 800);
      replay(card, "psnap-swap", 500);
      ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 140, fill: "forwards" }).onfinish = () => ghost.remove();
    };
    s.onfinish = land;
    s.oncancel = land;
    setTimeout(land, dur + 400);   // never leave the card hidden
    return true;
  }

  // --- the library window ------------------------------------------------------
  let lib = null, libOpen = false, libDirty = true;
  let rendered = null;          // the view the grid currently shows: { cat, q }
  const view = { cat: "all", q: "" };
  let cardEls = new Map();      // preset id → card element
  let lastMatched = [];         // presets matching the current search
  let inspected = -1;
  const $l = (s) => lib.querySelector(s);

  function ensureLib() {
    if (lib) return lib;
    lib = document.createElement("div");
    lib.id = "psnap-lib";
    lib.className = "psnap-ui psnap-lib";
    lib.hidden = true;
    lib.innerHTML = `
      <div class="psnap-lib-box" role="dialog" aria-modal="true" aria-labelledby="psnap-lib-title" tabindex="-1">
        <div class="psnap-lib-head">
          <span class="psnap-lib-logo" aria-hidden="true">${icon("all")}</span>
          <div class="psnap-lib-titles">
            <strong id="psnap-lib-title"></strong>
            <span id="psnap-lib-sub"></span>
          </div>
          <label class="psnap-lib-search">
            ${icon("search")}
            <input type="text" id="psnap-lib-q" role="searchbox" autocomplete="off" spellcheck="false">
            <button type="button" class="psnap-lib-qx" id="psnap-lib-qx" hidden>${icon("close")}</button>
          </label>
          <button type="button" class="psnap-lib-new" id="psnap-lib-new">${icon("plus")}<span></span></button>
          <button type="button" class="psnap-lib-x" id="psnap-lib-x">${icon("close")}</button>
        </div>
        <div class="psnap-lib-wrap">
          <nav class="psnap-lib-cats" id="psnap-lib-cats" role="tablist" aria-orientation="vertical"></nav>
          <div class="psnap-lib-main">
            <div class="psnap-lib-scroll" id="psnap-lib-scroll">
              <div class="psnap-lib-grid" id="psnap-lib-grid" role="listbox"></div>
              <div class="psnap-lib-empty" id="psnap-lib-empty" hidden></div>
            </div>
            <div class="psnap-lib-insp" id="psnap-lib-insp"></div>
          </div>
        </div>
        <div class="psnap-lib-ed" id="psnap-lib-ed" hidden></div>
        <div class="psnap-lib-snack" id="psnap-lib-snack" role="status"></div>
      </div>`;
    document.body.appendChild(lib);
    wireLib();
    return lib;
  }

  /** Words a search can match, cached per preset and language. */
  const fold = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const hayCache = new Map();
  function hay(p) {
    let h = hayCache.get(p.id);
    if (!h) {
      h = { name: fold(p.name), km: fold(KM_PRE[p.name] || ""), desc: fold(p.desc), kmd: fold(KM_DESC[p.desc] || ""),
            tags: [...(p.tags || []), ...(KM_TAGS[p.id] || [])].map(fold),
            g: fold(p.g + " " + catLabel(p) + " " + (((I18N.km && I18N.km.groups) || {})[p.g] || "")), text: fold(p.text) };
      hayCache.set(p.id, h);
    }
    return h;
  }
  /** 0 = no match. Every word must match somewhere; names count most.
      A match found only inside the prompt text is "weak" (score.weak). */
  function score(p, toks) {
    const h = hay(p);
    let total = 0;
    score.weak = false;
    for (const w of toks) {
      let s = 0;
      if (h.name.startsWith(w) || h.name.includes(" " + w)) s = 30;
      else if (h.name.includes(w)) s = 20;
      if (h.km && h.km.includes(w)) s = Math.max(s, 24);
      if (h.tags.includes(w)) s = Math.max(s, 18);
      else if (h.tags.some(x => x.startsWith(w))) s = Math.max(s, 12);
      if (!s && h.g.includes(w)) s = 9;
      if (!s && (h.desc.includes(w) || (h.kmd && h.kmd.includes(w)))) s = 7;
      if (!s && h.text.includes(w)) { s = 2; score.weak = true; }
      if (!s) return 0;
      total += s;
    }
    return total;
  }
  /** Escape a label and mark the searched words in it. */
  function marked(label, toks) {
    if (!toks.length) return esc(label);
    const low = fold(label).length === label.length ? fold(label) : label.toLowerCase();
    const hits = [];
    for (const w of toks) { let k = low.indexOf(w); while (k >= 0) { hits.push([k, k + w.length]); k = low.indexOf(w, k + w.length); } }
    if (!hits.length) return esc(label);
    hits.sort((x, y) => x[0] - y[0]);
    let out = "", at = 0;
    for (const [s0, e0] of hits) {
      if (e0 <= at) continue;
      const s1 = Math.max(s0, at);
      out += esc(label.slice(at, s1)) + "<mark>" + esc(label.slice(s1, e0)) + "</mark>";
      at = e0;
    }
    return out + esc(label.slice(at));
  }

  const catHas = (cat, p) =>
    cat === "all" ? true : cat === "fav" ? fav.includes(p.id) : cat === "recent" ? recent.includes(p.id)
    : cat === "Mine" ? !!p.mine : (!p.mine && p.g === cat);
  function catList() {
    const groups = [...new Set(presets.filter(p => !p.mine).map(p => p.g))]
      .sort((a, b) => ((GROUP_ORDER.indexOf(a) + 1) || 99) - ((GROUP_ORDER.indexOf(b) + 1) || 99));
    return ["all", "fav", "recent", "Mine", "|", ...groups];
  }
  const catName = (c) => {
    const t = T();
    return c === "all" ? t.libAll : c === "fav" ? t.libFav : c === "recent" ? t.libRecent
         : c === "Mine" ? t.libMine : groupLabel(c);
  };

  /** (Re)build the cards and the category rail — after the library or
      the language changes. Previews are drawn lazily as they scroll in. */
  function buildCards() {
    const t = T();
    cardEls = new Map();
    hayCache.clear();
    presets.forEach((p, i) => {
      const c = document.createElement("div");
      c.className = "psnap-lc";
      c.setAttribute("role", "option");
      c.tabIndex = -1;
      c.dataset.i = i;
      c.id = "psnap-lc-" + i;
      c.setAttribute("aria-labelledby", c.id + "-n");
      c.setAttribute("aria-describedby", c.id + "-d");
      c.style.setProperty("--g", hueOf(p.mine ? "Mine" : p.g));
      c.innerHTML =
        `<span class="psnap-lc-art"></span>` +
        `<span class="psnap-lc-badge" aria-hidden="true">${esc(t.libInUse)}</span>` +
        `<span class="psnap-lc-tools">` +
          (p.mine ? `<button type="button" class="psnap-lc-tool psnap-lc-edit" tabindex="-1" title="${esc(t.libEdit)}" aria-label="${esc(t.libEdit)}">${icon("pencil")}</button>` : "") +
          `<button type="button" class="psnap-lc-tool psnap-lc-star" tabindex="-1">${STAR}</button>` +
        `</span>` +
        `<span class="psnap-lc-text"><span class="psnap-lc-name" id="psnap-lc-${i}-n"></span>` +
        `<span class="psnap-lc-desc" id="psnap-lc-${i}-d"><span class="psnap-sr">${esc(catLabel(p))}. </span>${esc(presetDesc(p) || snippet(p))}</span></span>`;
      cardEls.set(p.id, c);
    });
    buildRail();
    libDirty = false;
  }

  function paintCardStates() {
    const t = T();
    presets.forEach((p, i) => {
      const c = cardEls.get(p.id);
      if (!c) return;
      const on = i === state.preset, f = fav.includes(p.id);
      c.classList.toggle("psnap-lc-on", on);
      c.setAttribute("aria-selected", on ? "true" : "false");
      const st = c.querySelector(".psnap-lc-star");
      st.classList.toggle("psnap-faved", f);
      st.setAttribute("aria-pressed", f ? "true" : "false");
      st.title = f ? t.libUnfav : t.libFavAdd;
      st.setAttribute("aria-label", st.title);
    });
  }

  function buildRail() {
    const rail = $l("#psnap-lib-cats");
    rail.innerHTML = `<i class="psnap-lib-catind" aria-hidden="true"></i>` + catList().map(c => c === "|"
      ? `<span class="psnap-lib-catsep" aria-hidden="true"></span>`
      : `<button type="button" class="psnap-lib-cat" role="tab" data-cat="${esc(c)}" style="--g:${c === "all" || c === "recent" ? "currentColor" : c === "fav" ? "#ffc94d" : hueOf(c)}">` +
        `${icon(c)}<span>${esc(catName(c))}</span><em></em></button>`).join("");
    rail._ind = null;
  }
  /** Counts follow the search; the highlight glides to the chosen category. */
  function paintRail(matched) {
    const rail = $l("#psnap-lib-cats");
    let active = null;
    rail.querySelectorAll(".psnap-lib-cat").forEach(b => {
      const c = b.dataset.cat;
      const n = matched.filter(x => catHas(c, x.p)).length;
      b.querySelector("em").textContent = n;
      b.classList.toggle("psnap-lib-cat-zero", n === 0 && c !== view.cat && c !== "Mine");
      const on = c === view.cat;
      b.setAttribute("aria-selected", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
      if (on) active = b;
    });
    const ind = rail.querySelector(".psnap-lib-catind");
    if (!active || !ind) return;
    const box = { x: active.offsetLeft, y: active.offsetTop, w: active.offsetWidth, h: active.offsetHeight };
    const first = !rail._ind;
    if (first || !smoothOK()) ind.classList.add("psnap-noanim");
    Object.assign(ind.style, { width: box.w + "px", height: box.h + "px", transform: `translate(${box.x}px, ${box.y}px)` });
    if (first || !smoothOK()) { void ind.offsetWidth; ind.classList.remove("psnap-noanim"); }
    rail._ind = box;
  }

  /** Lay out the grid for the current category and search. */
  function renderLib(animate) {
    if (!lib) return;
    if (libDirty) buildCards();
    const t = T();
    const toks = fold(view.q).split(/\s+/).filter(Boolean);
    const matched = lastMatched = presets.map((p, i) => {
      const sc = toks.length ? score(p, toks) : 1;
      return { p, i, s: sc, weak: toks.length ? score.weak : false };
    }).filter(x => x.s > 0);
    paintCardStates();

    let rows = matched.filter(x => catHas(view.cat, x.p));
    if (view.cat === "recent") rows.sort((a, b) => recent.indexOf(a.p.id) - recent.indexOf(b.p.id));
    if (view.cat === "fav") rows.sort((a, b) => fav.indexOf(a.p.id) - fav.indexOf(b.p.id));
    if (toks.length) rows.sort((a, b) => b.s - a.s || a.i - b.i);

    let sections;
    if (toks.length) {
      // matches in names, tags and descriptions first; prompt-text-only ones after
      const strong = rows.filter(x => !x.weak), weak = rows.filter(x => x.weak);
      sections = strong.length
        ? [{ key: "q", title: t.libResults(strong.length), items: strong },
           { key: "qw", title: t.libAlsoText, items: weak, quiet: true }]
        : [{ key: "q", title: t.libResults(weak.length), items: weak }];
    }
    else if (view.cat === "all") {
      sections = catList().filter(c => !["all", "fav", "recent", "Mine", "|"].includes(c)).concat("Mine")
        .map(c => ({ key: c, g: c, title: catName(c), items: rows.filter(x => catHas(c, x.p)) }))
        .filter(s => s.items.length);
    } else {
      const descs = t.libCatDesc || {};
      sections = [{ key: view.cat, g: GROUP_HUE[view.cat] ? view.cat : null, title: catName(view.cat),
                    desc: descs[view.cat] || "", items: rows }];
    }

    const mutate = () => {
      const frag = document.createDocumentFragment();
      for (const sec of sections) {
        if (!sec.items.length) continue;
        const el = document.createElement("section");
        el.className = "psnap-lib-sec" + (sec.quiet ? " psnap-lib-sec-quiet" : "");
        el.setAttribute("role", "group");
        el.innerHTML = `<h3 class="psnap-lib-sech"${sec.g ? ` style="--g:${hueOf(sec.g)}"` : ""}>` +
          `${sec.g ? "<i></i>" : ""}<span>${esc(sec.title)}</span>` +
          (sec.key !== "q" ? `<em>${sec.items.length}</em>` : "") +
          (sec.desc ? `<small>${esc(sec.desc)}</small>` : "") + `</h3>`;
        el.setAttribute("aria-label", sec.title);
        const cards = document.createElement("div");
        cards.className = "psnap-lib-cards";
        for (const x of sec.items) {
          const c = cardEls.get(x.p.id);
          const nm = marked(presetLabel(x.p), toks);
          if (c._nm !== nm) { c.querySelector(".psnap-lc-name").innerHTML = nm; c._nm = nm; }
          cards.appendChild(c);
        }
        el.appendChild(cards);
        frag.appendChild(el);
      }
      const grid = $l("#psnap-lib-grid");
      const had = document.activeElement;
      const keep = had && had.classList && had.classList.contains("psnap-lc") ? had : null;
      grid.replaceChildren(frag);
      // moving a focused card drops its focus: put it back (or on the search)
      if (keep) { if (keep.isConnected) keep.focus({ preventScroll: true }); else $l("#psnap-lib-q").focus({ preventScroll: true }); }
      // the grid is one tab stop: the focused card, else the one in use, else the first
      const cards = grid.querySelectorAll(".psnap-lc");
      const stop = (keep && keep.isConnected) ? keep
        : [...cards].find(c => +c.dataset.i === state.preset) || cards[0];
      cards.forEach(c => { c.tabIndex = c === stop ? 0 : -1; });
      paintEmpty(rows.length, toks);
    };
    if (animate && smoothOK()) flipGrid(mutate); else mutate();
    paintRail(matched);            // measured on the grid that is actually there
    rendered = { cat: view.cat, q: view.q };
    $l("#psnap-lib-sub").textContent = t.libCount(presets.length);
    observeArt();
  }

  function paintEmpty(n, toks) {
    const t = T(), el = $l("#psnap-lib-empty");
    if (n) { el.hidden = true; return; }
    let ico = "search", title, sub = "", act = "";
    if (toks.length) {
      title = t.libNoMatch(view.q.trim());
      sub = t.libNoMatchSub;
      act = `<button type="button" class="psnap-btn" data-act="clear">${esc(t.libClear)}</button>` +
            `<button type="button" class="psnap-btn psnap-primary" data-act="new">${icon("plus")}${esc(t.libNew)}</button>`;
    } else if (view.cat === "fav") { ico = "fav"; title = t.libFavEmpty; sub = t.libFavEmptySub; }
    else if (view.cat === "recent") { ico = "recent"; title = t.libRecentEmpty; sub = t.libRecentEmptySub; }
    else if (view.cat === "Mine") {
      ico = "Mine"; title = t.libMineEmpty; sub = t.libMineEmptySub;
      act = `<button type="button" class="psnap-btn psnap-primary" data-act="new">${icon("plus")}${esc(t.libNew)}</button>`;
    } else { title = t.libNoMatch(""); }
    el.innerHTML = `<span class="psnap-lib-empty-ico">${icon(ico)}</span><strong>${esc(title)}</strong>` +
                   (sub ? `<span>${esc(sub)}</span>` : "") + (act ? `<div class="psnap-lib-empty-acts">${act}</div>` : "");
    el.hidden = false;
    if (smoothOK()) playIn(el, "psnap-lib-empty-in");
  }

  /** FLIP: cards that stay glide to their new place, new ones rise in. */
  function flipGrid(mutate) {
    const scroller = $l("#psnap-lib-scroll");
    const view0 = scroller.getBoundingClientRect();
    const seen = (r) => r.bottom > view0.top - 40 && r.top < view0.bottom + 40 && r.width > 0;
    const before = new Map();
    for (const [id, c] of cardEls) if (c.isConnected) { const r = c.getBoundingClientRect(); if (seen(r)) before.set(id, r); }
    mutate();
    const after = [];
    for (const [id, c] of cardEls) if (c.isConnected) { const r = c.getBoundingClientRect(); if (seen(r)) after.push([id, c, r]); }
    let k = 0;
    for (const [id, c, r] of after) {
      const r0 = before.get(id);
      if (r0) {
        const dx = r0.left - r.left, dy = r0.top - r.top;
        if (Math.abs(dx) > 1 || Math.abs(dy) > 1)
          c.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { transform: "none" }],
                    { duration: 420, easing: "cubic-bezier(.22,1,.36,1)" });
      } else {
        c.animate([{ opacity: 0, transform: "translateY(12px) scale(.96)" }, { opacity: 1, transform: "none" }],
                  { duration: 360, delay: Math.min(k++, 12) * 22, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
      }
    }
  }

  // previews are drawn as their cards come into view
  let artIO = null;
  function fillArt(slot) {
    if (!slot || slot._done) return;
    slot._done = true;
    if (artIO) artIO.unobserve(slot);
    const p = presets[+slot.parentNode.dataset.i];
    putArt(slot, artFor(p));
    if (smoothOK() && libOpen) slot.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 280, easing: "ease" });
  }
  function observeArt() {
    if (!("IntersectionObserver" in window)) { for (const c of cardEls.values()) fillArt(c.firstElementChild); return; }
    if (!artIO) artIO = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) fillArt(e.target);
    }, { root: $l("#psnap-lib-scroll"), rootMargin: "280px 0px" });
    for (const c of cardEls.values()) {
      const slot = c.firstElementChild;
      if (!slot._done && c.isConnected && !slot._watched) { slot._watched = true; artIO.observe(slot); }
    }
  }

  /** The strip under the grid: a bigger preview and the prompt itself,
      for whichever preset you hover or move to. */
  let _inspT = 0;
  function inspect(i, now) {
    clearTimeout(_inspT);
    if (!now) { _inspT = setTimeout(() => inspect(i, true), 70); return; }
    if (!lib || i === inspected || !presets[i]) return;
    inspected = i;
    const t = T(), p = presets[i];
    const used = [...new Set(varNames(p.text).map(k => fieldKey(p, k)))];
    const tpl = esc(p.text).replace(/\{(\w+)\}/g, (_, k) => RESERVED.has(k)
      ? `<span class="psnap-tv psnap-tv-auto">${esc(k === "ratio" ? t.ratio : k === "quality" ? t.quality : t.style)}</span>`
      : `<span class="psnap-tv">${esc(fieldLabel(fieldKey(p, k)))}</span>`);
    const box = $l("#psnap-lib-insp");
    box.style.setProperty("--g", hueOf(p.mine ? "Mine" : p.g));
    putArt(box, `
      <div class="psnap-insp-art">${artFor(p)}
        <span class="psnap-insp-tag psnap-insp-b">${esc(t.libBefore)}</span>
        <span class="psnap-insp-tag psnap-insp-a">${esc(t.libAfter)}</span></div>
      <div class="psnap-insp-info">
        <div class="psnap-insp-top"><span class="psnap-insp-cat"><i></i>${esc(catLabel(p))}</span>
          ${used.length ? `<span class="psnap-insp-fields">${esc(t.libFields)}: ${used.map(k => esc(fieldLabel(k))).join(" · ")}</span>` : ""}</div>
        <strong class="psnap-insp-name">${esc(presetLabel(p))}</strong>
        ${presetDesc(p) ? `<span class="psnap-insp-desc">${esc(presetDesc(p))}</span>` : ""}
        <div class="psnap-insp-tpl" title="${esc(p.text)}">${tpl}</div>
      </div>
      <div class="psnap-insp-acts">
        <button type="button" class="psnap-btn psnap-primary" data-use="${i}">${esc(i === state.preset ? t.libInUse : t.libUse)}</button>
        <div class="psnap-insp-row">
          <button type="button" class="psnap-btn" data-dup="${i}" title="${esc(p.mine ? t.libEdit : t.libDuplicate)}" aria-label="${esc(p.mine ? t.libEdit : t.libDuplicate)}">${icon(p.mine ? "pencil" : "copy")}<span>${esc(p.mine ? t.libEdit : t.libDuplicate)}</span></button>
          <button type="button" class="psnap-btn psnap-insp-fav" data-fav="${i}"></button>
        </div>
      </div>`);
    paintInspFav();
    if (smoothOK()) {
      box.querySelector(".psnap-insp-info").animate(
        [{ opacity: 0, transform: "translateY(4px)" }, { opacity: 1, transform: "none" }],
        { duration: 240, easing: "cubic-bezier(.22,1,.36,1)" });
      sweep(box.querySelector(".psa"), 92);
    }
  }

  /** The strip's star: the keyboard way to favourite a preset. */
  function paintInspFav() {
    const b = lib && $l(".psnap-insp-fav");
    if (!b) return;
    const p = presets[+b.dataset.fav], on = !!p && fav.includes(p.id), t = T();
    b.innerHTML = STAR;
    b.classList.toggle("psnap-faved", on);
    b.setAttribute("aria-pressed", on ? "true" : "false");
    b.title = on ? t.libUnfav : t.libFavAdd;
    b.setAttribute("aria-label", b.title);
  }

  function paintLibChrome() {
    const t = T();
    lib.classList.toggle("psnap-km", lang === "km");
    lib.classList.toggle("psnap-lib-light", panel.classList.contains("psnap-light"));
    $l("#psnap-lib-title").textContent = t.libTitle;
    $l("#psnap-lib-grid").setAttribute("aria-label", t.libTitle);
    $l("#psnap-lib-q").placeholder = t.libSearch(presets.length);
    $l("#psnap-lib-q").setAttribute("aria-label", t.libSearch(presets.length));
    $l("#psnap-lib-qx").setAttribute("aria-label", t.libClear);
    $l("#psnap-lib-new span").textContent = t.libNew;
    $l("#psnap-lib-x").setAttribute("aria-label", t.close);
    $l("#psnap-lib-x").title = t.close + " (Esc)";
  }

  function openLib(cat) {
    ensureLib();
    if (libOpen) return;
    libOpen = true;
    _mouseMoved = false;
    fabWrap.classList.add("psnap-lib-up");
    clearTimeout(lib._t);
    // always start from everything, scrolled to the preset in use
    view.cat = cat || "all";
    view.q = "";
    paintLibChrome();
    inspected = -1;
    lib.hidden = false;
    lib.classList.remove("psnap-lib-out");
    // the grid stays laid out while the library is closed (see the CSS), so
    // when it already shows "everything" only the marks need refreshing
    if (rendered && (rendered.cat !== "all" || rendered.q)) $l("#psnap-lib-cats")._ind = null;   // no glide from an old category
    if (!libDirty && rendered && rendered.cat === "all" && rendered.q === "") {
      paintCardStates(); paintRail(lastMatched);
      cardEls.forEach(c => { c.tabIndex = +c.dataset.i === state.preset ? 0 : -1; });    // Tab lands on the one in use
    } else renderLib(false);

    // grow out of the preset card
    const box = lib.firstElementChild;
    try {
      const r = $("#psnap-pcard").getBoundingClientRect(), br = box.getBoundingClientRect();
      const ox = Math.max(0, Math.min(br.width, r.left + r.width / 2 - br.left));
      const oy = Math.max(0, Math.min(br.height, r.top + r.height / 2 - br.top));
      box.style.transformOrigin = `${ox}px ${oy}px`;
    } catch (_) {}

    // land on the preset in use
    const scroller = $l("#psnap-lib-scroll");
    const cur = cardEls.get(presets[state.preset].id);
    scroller.scrollTop = 0;
    if (cur && cur.isConnected) {
      const top = cur.offsetTop - scroller.clientHeight / 2 + cur.offsetHeight / 2;
      if (top > 40) scroller.scrollTop = top;
    }
    // draw what is on screen right away, the rest as it scrolls in
    const sv = scroller.getBoundingClientRect();
    const onScreen = [...cardEls.values()].filter(c => {
      if (!c.isConnected) return false;
      const r = c.getBoundingClientRect();
      return r.bottom > sv.top && r.top < sv.bottom;
    });
    onScreen.forEach(c => fillArt(c.firstElementChild));
    playIn(lib, "psnap-lib-in");
    if (smoothOK()) onScreen.forEach((c, k) => c.animate(
      [{ opacity: 0, transform: "translateY(14px) scale(.97)" }, { opacity: 1, transform: "none" }],
      { duration: 460, delay: 70 + Math.min(k, 14) * 24, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" }));
    inspect(state.preset, true);
    const q = $l("#psnap-lib-q");
    q.value = view.q;
    $l("#psnap-lib-qx").hidden = !view.q;
    setTimeout(() => { if (libOpen) q.focus({ preventScroll: true }); }, 30);
    document.addEventListener("keydown", onDocKey, true);
  }

  function closeLib(picked) {
    if (!libOpen) return;
    libOpen = false;
    fabWrap.classList.remove("psnap-lib-up");
    clearTimeout(_inspT);
    document.removeEventListener("keydown", onDocKey, true);
    closeEditor(true);
    lib.classList.remove("psnap-lib-in");
    lib.classList.add("psnap-lib-out");
    clearTimeout(lib._t);
    lib._t = setTimeout(() => {
      if (libOpen) return;
      lib.hidden = true;
      lib.classList.remove("psnap-lib-out");
    }, motionOK() ? 300 : 0);
    // the second click of a double-click must not land on the panel or ChatGPT
    const eat = (ev) => { if (ev.detail > 1) { ev.stopPropagation(); ev.preventDefault(); } };
    document.addEventListener("click", eat, true);
    setTimeout(() => document.removeEventListener("click", eat, true), 500);
    // give focus back to the card unless it is elsewhere on purpose
    if (!picked || lib.contains(document.activeElement)) try { $("#psnap-pcard").focus({ preventScroll: true }); } catch (_) {}
    clearTimeout(_qT);
  }

  /** Escape from anywhere while the library is open. */
  function onDocKey(e) {
    if (!libOpen || e.key !== "Escape" || lib.contains(e.target)) return;
    e.stopPropagation(); e.preventDefault();
    edOpen ? closeEditor() : closeLib();
  }

  function setCat(cat) {
    if (cat === view.cat) return;
    view.cat = cat;
    renderLib(true);
    $l("#psnap-lib-scroll").scrollTo({ top: 0, behavior: "auto" });
    observeArt();
  }

  let _qT = 0;
  function setQuery(q) {
    // a new search looks through everything; a category can narrow it after
    if (q.trim() && !view.q.trim() && view.cat !== "all") view.cat = "all";
    view.q = q;
    $l("#psnap-lib-qx").hidden = !q;
    clearTimeout(_qT);
    _qT = setTimeout(() => { _qT = 0; renderLib(true); $l("#psnap-lib-scroll").scrollTop = 0; }, 70);
  }

  // stars: a pop and a little burst
  function toggleFav(id, btn) {
    const on = !fav.includes(id);
    fav = on ? [...fav, id] : fav.filter(x => x !== id);
    persist({ psnapFav: fav });
    if (btn && smoothOK()) {
      replay(btn, "psnap-pop", 520);
      if (on) {
        const b = document.createElement("span");
        b.className = "psnap-starburst";
        b.innerHTML = "<i></i><i></i><i></i><i></i><i></i><i></i>";
        btn.appendChild(b);
        setTimeout(() => b.remove(), 650);
      }
    }
    paintFavRow();
    paintInspFav();
    if (view.cat === "fav") renderLib(true);
    else { paintCardStates(); paintRail(lastMatched); }
    snack(on ? T().libFavAdded : T().libFavRemoved);
  }

  let _snackT = 0;
  function snack(msg) {
    if (!lib) return;
    const el = $l("#psnap-lib-snack");
    el.textContent = msg;
    el.classList.remove("psnap-snack-on"); void el.offsetWidth; el.classList.add("psnap-snack-on");
    clearTimeout(_snackT);
    _snackT = setTimeout(() => el.classList.remove("psnap-snack-on"), 1700);
  }

  /** Arrow keys walk the grid by position, so up/down land on the card
      visually above or below, across section breaks too. */
  function moveFocus(from, key) {
    const all = [...$l("#psnap-lib-grid").querySelectorAll(".psnap-lc")];
    if (!all.length) return;
    let to = null;
    const idx = all.indexOf(from);
    if (idx < 0) to = all[0];
    else if (key === "ArrowRight") to = all[idx + 1];
    else if (key === "ArrowLeft") to = all[idx - 1];
    else if (key === "Home") to = all[0];
    else if (key === "End") to = all[all.length - 1];
    else {
      const r = from.getBoundingClientRect(), cx = r.left + r.width / 2;
      const up = key === "ArrowUp";
      const rows = all.map(c => ({ c, r: c.getBoundingClientRect() }))
        .filter(x => up ? x.r.top < r.top - 4 : x.r.top > r.top + 4);
      if (rows.length) {
        const rowTop = up ? Math.max(...rows.map(x => x.r.top)) : Math.min(...rows.map(x => x.r.top));
        const row = rows.filter(x => Math.abs(x.r.top - rowTop) < 6);
        row.sort((a, b) => Math.abs(a.r.left + a.r.width / 2 - cx) - Math.abs(b.r.left + b.r.width / 2 - cx));
        to = row[0].c;
      }
    }
    if (to) focusCard(to);
  }
  function focusCard(c) {
    $l("#psnap-lib-grid").querySelectorAll('.psnap-lc[tabindex="0"]').forEach(x => { x.tabIndex = -1; });
    c.tabIndex = 0;
    c.focus({ preventScroll: true });
    const sc = $l("#psnap-lib-scroll"), r = c.getBoundingClientRect(), v = sc.getBoundingClientRect();
    const head = c.closest(".psnap-lib-sec") && c.closest(".psnap-lib-sec").querySelector(".psnap-lib-sech");
    const pad = (head ? head.offsetHeight : 46) + 6;    // room for the sticky section title
    _kbNavAt = performance.now();
    _mouseMoved = false;
    if (r.top < v.top + pad) sc.scrollBy({ top: r.top - v.top - pad, behavior: smoothOK() ? "smooth" : "auto" });
    else if (r.bottom > v.bottom - 10) sc.scrollBy({ top: r.bottom - v.bottom + 10, behavior: smoothOK() ? "smooth" : "auto" });
    fillArt(c.firstElementChild);
    inspect(+c.dataset.i, true);
  }

  // drag across a preview to compare before and after
  let scrubbing = null, _scrubF = 0, _scrubX = 0, _kbNavAt = 0, _mouseMoved = false;
  function scrubTo(psa, x) {
    if (scrubbing && scrubbing !== psa) releaseScrub();
    scrubbing = psa;
    _scrubX = x;
    if (_scrubF) return;
    _scrubF = requestAnimationFrame(() => {
      _scrubF = 0;
      if (!scrubbing) return;
      const r = scrubbing.getBoundingClientRect();
      if (!r.width) return;
      const pct = Math.max(0, Math.min(100, (_scrubX - r.left) / r.width * 100));
      scrubbing.classList.add("psa-live");
      scrubbing.style.setProperty("--psa-split", pct.toFixed(1) + "%");
    });
  }
  function releaseScrub() {
    if (!scrubbing) return;
    scrubbing.classList.remove("psa-live");
    scrubbing.style.removeProperty("--psa-split");    // eases back to the middle
    scrubbing = null;
  }

  function trapTab(e) {
    const box = lib.firstElementChild;
    const scope = edOpen ? $l("#psnap-lib-ed") : box;
    // real tab stops only: the rail and the grid are single stops (roving tabindex)
    const f = [...scope.querySelectorAll("button, input, textarea, [tabindex]")]
      .filter(el => el.tabIndex >= 0 && !el.disabled && el.offsetParent !== null && !el.closest("[hidden]") &&
                    (edOpen || !el.closest(".psnap-lib-ed")));
    if (!f.length) return;
    const i = f.indexOf(document.activeElement);
    const next = e.shiftKey ? (i <= 0 ? f[f.length - 1] : f[i - 1]) : (i < 0 || i === f.length - 1 ? f[0] : f[i + 1]);
    e.preventDefault();
    next.focus();
  }

  function wireLib() {
    const box = lib.firstElementChild;
    // the category rail turns into a chip row on narrow windows: re-place its highlight
    let _rz = 0;
    window.addEventListener("resize", () => {
      if (!libOpen) return;
      cancelAnimationFrame(_rz);
      _rz = requestAnimationFrame(() => { const r = $l("#psnap-lib-cats"); r._ind = null; paintRail(lastMatched); });
    });
    const q = $l("#psnap-lib-q");
    // a backdrop click only counts when the press started on the backdrop too
    // (a text selection dragged out of the box must not close it)
    lib.addEventListener("pointerdown", (e) => { lib._downOnBackdrop = e.target === lib; });
    lib.addEventListener("mousedown", (e) => { if (e.target === lib) e.preventDefault(); });   // keep focus in the dialog
    lib.addEventListener("click", (e) => {
      if (!libOpen) return;
      if (e.target === lib) { if (lib._downOnBackdrop && !edOpen && e.detail <= 1) closeLib(); return; }
      // the 2nd click of a double-click (also the one that opened the library) never picks
      const stray = e.detail > 1;
      const t = e.target;
      const star = t.closest(".psnap-lc-star");
      if (star) { e.stopPropagation(); if (e.detail > 1) return; const c = star.closest(".psnap-lc"); toggleFav(presets[+c.dataset.i].id, star); return; }
      const ed = t.closest(".psnap-lc-edit");
      if (ed) { if (!stray) openEditor(presets[+ed.closest(".psnap-lc").dataset.i]); return; }
      const card = t.closest(".psnap-lc");
      if (card) { if (!stray) pickPreset(+card.dataset.i, card.querySelector(".psnap-lc-art")); return; }
      const cat = t.closest(".psnap-lib-cat");
      if (cat) { setCat(cat.dataset.cat); return; }
      const use = t.closest("[data-use]");
      if (use) { if (!stray) pickPreset(+use.dataset.use, $l(".psnap-insp-art")); return; }
      const fv = t.closest("[data-fav]");
      if (fv) { if (e.detail <= 1) toggleFav(presets[+fv.dataset.fav].id, fv); return; }
      const dup = t.closest("[data-dup]");
      if (dup) { openEditor(presets[+dup.dataset.dup]); return; }
      const act = t.closest("[data-act]");
      if (act && act.dataset.act === "clear") { q.value = ""; setQuery(""); q.focus(); return; }
      if (act && act.dataset.act === "new") { openEditor(null); return; }
      if (t.closest("#psnap-lib-new")) { openEditor(null); return; }
      if (t.closest("#psnap-lib-x")) { closeLib(); return; }
      if (t.closest("#psnap-lib-qx")) { q.value = ""; setQuery(""); q.focus(); return; }
    });
    q.addEventListener("input", () => setQuery(q.value));

    // hover shows a preset in the strip below; moving across a preview scrubs it
    // only a pointer that really moved inspects: cards sliding under a still
    // mouse (while the arrow keys scroll the grid) must not steal the strip
    let _px = -1, _py = -1;
    box.addEventListener("pointerover", (e) => {
      const card = e.target.closest(".psnap-lc");
      if (!card || e.pointerType !== "mouse" || !_mouseMoved) return;
      if ((e.clientX === _px && e.clientY === _py) || performance.now() - _kbNavAt < 450) return;
      inspect(+card.dataset.i);
    });
    box.addEventListener("pointermove", (e) => {
      if (e.clientX !== _px || e.clientY !== _py) _mouseMoved = true;
      _px = e.clientX; _py = e.clientY;
      if (e.pointerType !== "mouse" && e.pointerType !== "pen") return;
      const psa = e.target.closest(".psnap-lc-art .psa, .psnap-insp-art .psa, .psnap-ed-prev .psa");
      if (psa) scrubTo(psa, e.clientX); else releaseScrub();
    });
    box.addEventListener("pointerleave", releaseScrub);

    lib.addEventListener("keydown", (e) => {
      const k = e.key, a = document.activeElement;
      e.stopPropagation();                 // ChatGPT must not act on keys typed here
      if (e.isComposing || e.keyCode === 229) return;     // an IME is composing (Khmer, CJK…)
      if (e.ctrlKey && e.shiftKey && e.code === "Space") { e.preventDefault(); togglePanel(); return; }
      const mod = e.ctrlKey || e.metaKey || e.altKey;
      const typing = !!(a && /^(INPUT|TEXTAREA)$/.test(a.tagName));
      if (k === "Escape") {
        e.preventDefault();
        if (edOpen) closeEditor();
        else if (view.q) { q.value = ""; setQuery(""); q.focus(); }
        else closeLib();
        return;
      }
      if (k === "Tab") { trapTab(e); return; }
      if (edOpen) {
        if ((e.ctrlKey || e.metaKey) && k === "Enter") { e.preventDefault(); saveEditor(); return; }
        const art = a && a.closest && a.closest(".psnap-ed-art");
        if (art && /^Arrow/.test(k)) {             // the picture choices are one radio group
          e.preventDefault();
          const all = [...$l("#psnap-ed-arts").querySelectorAll(".psnap-ed-art")];
          const n = all.indexOf(art) + (k === "ArrowLeft" || k === "ArrowUp" ? -1 : 1);
          const to = all[(n + all.length) % all.length];
          to.focus(); to.click();
        }
        return;
      }
      if (a === q) {
        if ((k === "ArrowDown" || k === "Enter") && !mod) {
          // act on the results of what was just typed, not the grid from before it
          if (_qT) { clearTimeout(_qT); _qT = 0; renderLib(false); }
          const first = $l("#psnap-lib-grid .psnap-lc");
          if (!first) return;
          e.preventDefault();
          if (k === "Enter" && view.q.trim()) pickPreset(+first.dataset.i, first.querySelector(".psnap-lc-art"));
          else focusCard(first);
        }
        return;
      }
      // buttons (the star and pencil on a card too) keep their own Enter and Space
      if (a && a.closest && a.closest("button") && (k === " " || k === "Enter")) return;
      const card = a && a.closest && a.closest(".psnap-lc");
      if (card && !mod) {
        if (/^Arrow|^Home$|^End$/.test(k)) { e.preventDefault(); moveFocus(card, k); return; }
        if (k === "Enter" || k === " ") { e.preventDefault(); pickPreset(+card.dataset.i, card.querySelector(".psnap-lc-art")); return; }
      }
      const tab = a && a.closest && a.closest(".psnap-lib-cat");
      if (tab && !mod && /^Arrow(Up|Down|Left|Right)$/.test(k)) {
        e.preventDefault();
        const tabs = [...$l("#psnap-lib-cats").querySelectorAll(".psnap-lib-cat")];
        const n = tabs.indexOf(tab) + (k === "ArrowUp" || k === "ArrowLeft" ? -1 : 1);
        const to = tabs[(n + tabs.length) % tabs.length];
        to.focus(); setCat(to.dataset.cat);
        return;
      }
      // type anywhere to search
      if (!typing && !mod && ((k.length === 1 && k !== " ") || k === "Backspace")) q.focus();
    });
  }

  // --- your own presets ---------------------------------------------------
  const MINE_ART = [
    { scene: "portrait", fx: "enhance" }, { scene: "product", fx: "white-bg" }, { scene: "landscape", fx: "golden-hour" },
    { scene: "city", fx: "day-night" }, { scene: "aircraft", fx: "enhance" }, { scene: "aircraft-sky", fx: "sunset-sky" },
    { scene: "pet", fx: "watercolor" }, { scene: "food", fx: "enhance" }, { scene: "interior", fx: "remove-object" },
    { scene: "group", fx: "variations" }, { scene: "object", fx: "sketch" }, { scene: "landscape", fx: "prompt" }
  ];
  let edOpen = false, edDraft = null, _delArm = 0;

  /** New preset (src null), duplicate a preset, or edit one of yours. */
  function openEditor(src) {
    ensureLib();
    const t = T();
    const editing = src && src.mine ? src : null;
    edDraft = {
      id: editing ? editing.id : "",
      name: editing ? editing.name : src ? `${src.name} (${t.edCopy})`.slice(0, 60) : "",
      text: src ? src.text : "",
      art: Object.assign({}, (src && artSpec(src)) || MINE_ART[0])
    };
    if (edDraft.art.scene && !ART?.has?.(edDraft.art.scene)) edDraft.art = MINE_ART[0];
    const ed = $l("#psnap-lib-ed");
    const sameArt = (a) => a.scene === edDraft.art.scene && a.fx === edDraft.art.fx;
    const arts = MINE_ART.some(sameArt) ? MINE_ART : [edDraft.art, ...MINE_ART.slice(0, MINE_ART.length - 1)];
    ed.innerHTML = `
      <div class="psnap-ed-head">
        <button type="button" class="psnap-lib-x psnap-ed-back" id="psnap-ed-back" aria-label="${esc(t.edCancel)}">${icon("back")}</button>
        <div class="psnap-lib-titles"><strong>${esc(editing ? t.edEditTitle : t.edNewTitle)}</strong>
          <span>${esc(t.edSub)}</span></div>
      </div>
      <div class="psnap-ed-body">
        <div class="psnap-ed-form">
          <label class="psnap-ed-lbl" for="psnap-ed-name">${esc(t.edName)}</label>
          <input type="text" id="psnap-ed-name" maxlength="60" autocomplete="off" placeholder="${esc(t.edNamePh)}" value="${esc(edDraft.name)}">
          <label class="psnap-ed-lbl" for="psnap-ed-text">${esc(t.edText)}</label>
          <textarea id="psnap-ed-text" rows="8" spellcheck="true" placeholder="${esc(t.edTextPh)}">${esc(edDraft.text)}</textarea>
          <div class="psnap-ed-help">${esc(t.edHelp)}</div>
          <div class="psnap-ed-found" id="psnap-ed-found"></div>
        </div>
        <div class="psnap-ed-side">
          <span class="psnap-ed-lbl">${esc(t.edPicture)}</span>
          <div class="psnap-ed-prev" id="psnap-ed-prev"></div>
          <div class="psnap-ed-arts" id="psnap-ed-arts" role="radiogroup" aria-label="${esc(t.edPicture)}">
            ${arts.map((a, k) => `<button type="button" class="psnap-ed-art${sameArt(a) ? " psnap-on" : ""}" role="radio" aria-checked="${sameArt(a)}" tabindex="${sameArt(a) ? 0 : -1}" aria-label="${esc(t.edPicture)} ${k + 1}" data-k="${k}">${ART ? artFor({ art: a }, true) : ""}</button>`).join("")}
          </div>
        </div>
      </div>
      <div class="psnap-ed-foot">
        ${editing ? `<button type="button" class="psnap-btn psnap-ed-del" id="psnap-ed-del">${icon("trash")}<span>${esc(t.edDelete)}</span></button>` : ""}
        <span class="psnap-ed-err" id="psnap-ed-err" role="alert"></span>
        <button type="button" class="psnap-btn" id="psnap-ed-cancel">${esc(t.edCancel)}</button>
        <button type="button" class="psnap-btn psnap-primary" id="psnap-ed-save">${esc(t.edSave)}</button>
      </div>`;
    ed._arts = arts;
    if (ART && !artInline) ART.hydrate(ed.querySelector("#psnap-ed-arts"));
    const name = ed.querySelector("#psnap-ed-name"), ta = ed.querySelector("#psnap-ed-text");
    const prev = () => {
      putArt(ed.querySelector("#psnap-ed-prev"), ART ? artFor({ art: edDraft.art }) : "");
      sweep(ed.querySelector("#psnap-ed-prev .psa"));
    };
    const found = () => {
      const tt = T(), names = varNames(ta.value);
      const missing = ["ratio", "quality", "style"].filter(k => !ta.value.includes("{" + k + "}"));
      ed.querySelector("#psnap-ed-found").innerHTML =
        (names.length ? `<span class="psnap-ed-flbl">${esc(tt.libFields)}</span>` +
          names.map(n => `<span class="psnap-tv">${esc(fieldLabel(n))}</span>`).join("") : "") +
        missing.map(k => `<button type="button" class="psnap-ed-ins" data-ins="${k}">+ {${k}}</button>`).join("");
    };
    ed.querySelector("#psnap-ed-found").addEventListener("click", (e) => {
      const b = e.target.closest("[data-ins]");
      if (!b) return;
      const s0 = ta.selectionStart ?? ta.value.length, e0 = ta.selectionEnd ?? s0;
      const before = ta.value.slice(0, s0);
      ta.focus();
      ta.setRangeText((before && !/\s$/.test(before) ? " " : "") + "{" + b.dataset.ins + "}", s0, e0, "end");
      found();
    });
    ta.addEventListener("input", found);
    [name, ta].forEach(el => el.addEventListener("input", () => { ed.querySelector("#psnap-ed-err").textContent = ""; el.classList.remove("psnap-bad"); }));
    ed.querySelector("#psnap-ed-arts").addEventListener("click", (e) => {
      const b = e.target.closest(".psnap-ed-art");
      if (!b) return;
      edDraft.art = Object.assign({}, ed._arts[+b.dataset.k]);
      ed.querySelectorAll(".psnap-ed-art").forEach(x => { const on = x === b; x.classList.toggle("psnap-on", on); x.setAttribute("aria-checked", on); x.tabIndex = on ? 0 : -1; });
      prev();
    });
    ed.querySelector("#psnap-ed-back").onclick = () => closeEditor();
    ed.querySelector("#psnap-ed-cancel").onclick = () => closeEditor();
    ed.querySelector("#psnap-ed-save").onclick = saveEditor;
    const del = ed.querySelector("#psnap-ed-del");
    if (del) del.onclick = () => {
      // a second press only counts after a beat, so a double-click can't delete
      if (!del.classList.contains("psnap-armed") || performance.now() - (del._armedAt || 0) < 450) {
        if (del.classList.contains("psnap-armed")) return;
        del._armedAt = performance.now();
        del.classList.add("psnap-armed");
        del.querySelector("span").textContent = T().edDeleteSure;
        clearTimeout(_delArm);
        _delArm = setTimeout(() => { del.classList.remove("psnap-armed"); del.querySelector("span").textContent = T().edDelete; }, 3000);
        return;
      }
      deleteMine(edDraft.id);
    };
    prev(); found();
    edOpen = true;
    ed.hidden = false;
    lib.firstElementChild.classList.add("psnap-lib-editing");
    playIn(ed, "psnap-ed-in");
    setTimeout(() => { (editing || !src ? name : ta).focus(); }, 60);
  }

  function closeEditor(instant) {
    if (!lib || !edOpen) return;
    edOpen = false;
    const ed = $l("#psnap-lib-ed");
    lib.firstElementChild.classList.remove("psnap-lib-editing");
    ed.classList.remove("psnap-ed-in");
    clearTimeout(ed._t);
    ed._t = setTimeout(() => { if (!edOpen) { ed.hidden = true; ed.innerHTML = ""; } }, instant || !motionOK() ? 0 : 280);
    if (!instant) setTimeout(() => { try { $l("#psnap-lib-q").focus({ preventScroll: true }); } catch (_) {} }, 20);
  }

  function saveEditor() {
    if (!edOpen) return;                     // a second click while it closes
    const t = T(), ed = $l("#psnap-lib-ed");
    const nameEl = ed.querySelector("#psnap-ed-name"), ta = ed.querySelector("#psnap-ed-text");
    const name = nameEl.value.trim(), text = ta.value.trim();
    const err = ed.querySelector("#psnap-ed-err");
    const bad = (el, msg) => { err.textContent = msg; el.classList.add("psnap-bad"); replay(el, "psnap-shake", 450); el.focus(); };
    if (!name) return bad(nameEl, t.edNameReq);
    if (!text) return bad(ta, t.edTextReq);
    let id = edDraft.id;
    if (id) {
      const m = mine.find(x => x.id === id);
      if (m) Object.assign(m, { name, text, art: edDraft.art });
    } else {
      id = "mine-" + Date.now().toString(36);
      mine.push({ id, name, text, art: edDraft.art, created: Date.now() });
    }
    persist({ psnapMine: mine });
    const wasCurrent = state.pid === id;
    setLibrary();
    if (wasCurrent) { buildVars(); render(); }
    fillPresets();
    closeEditor();
    view.cat = "Mine"; view.q = "";
    $l("#psnap-lib-q").value = ""; $l("#psnap-lib-qx").hidden = true;
    renderLib(true);
    const c = cardEls.get(id);
    if (c) { fillArt(c.firstElementChild); setTimeout(() => { focusCard(c); replay(c, "psnap-lc-new", 1300); }, 40); }
    snack(t.edSaved);
  }

  function deleteMine(id) {
    mine = mine.filter(m => m.id !== id);
    fav = fav.filter(x => x !== id);
    recent = recent.filter(x => x !== id);
    persist({ psnapMine: mine, psnapFav: fav, psnapRecent: recent });
    const wasCurrent = state.pid === id;
    if (wasCurrent) state.pid = presets[0].id;
    setLibrary();
    if (wasCurrent) { buildVars(); render(); save(); }
    fillPresets();
    closeEditor();
    renderLib(true);
    inspect(state.preset, true);
    snack(T().edDeleted);
  }

  // --- panel wiring --------------------------------------------------------------
  $("#psnap-pcard").addEventListener("click", () => openLib());
  $("#psnap-browse").addEventListener("click", () => openLib("all"));
  $("#psnap-pcard").addEventListener("keydown", (e) => {
    // ← → step through the library without opening it
    if ((e.key !== "ArrowLeft" && e.key !== "ArrowRight") || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    const n = (state.preset + (e.key === "ArrowRight" ? 1 : -1) + presets.length) % presets.length;
    pickPreset(n, null, true);
  });
  $("#psnap-favrow").addEventListener("click", (e) => {
    const b = e.target.closest(".psnap-fv");
    if (b) pickPreset(+b.dataset.i, b);
  });
  const paintRatios = () => ratioWrap.querySelectorAll(".psnap-chip")
    .forEach(c => c.classList.toggle("psnap-on", c.dataset.r === state.ratio));

  ratioWrap.addEventListener("click", e => {
    const c = e.target.closest(".psnap-chip"); if (!c) return;
    const was = ratioWrap.querySelector(".psnap-chip.psnap-on");
    const from = was && was !== c && smoothOK() ? boxIn(was) : null;
    state.ratio = c.dataset.r; paintRatios(); render(); save();
    if (from) glide(ratioWrap, from, c, "psnap-glide", "psnap-gliding");
  });

  const GEAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
    + 'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/>'
    + '<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 '
    + '1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 '
    + '1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 '
    + '4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 '
    + '1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A'
    + '1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';

  $("#psnap-gear").innerHTML = GEAR;

  function seg(container, options, current, onPick) {
    // remember where the highlight was so it can glide to the new choice
    const was = container.querySelector(".psnap-seg-on");
    const from = (was && was.dataset.val !== current && smoothOK())
      ? { x: was.offsetLeft, y: was.offsetTop, w: was.offsetWidth } : null;
    container.innerHTML = options.map(o =>
      `<button data-val="${esc(o.val)}" class="${o.val === current ? "psnap-seg-on" : ""}">${esc(o.label)}</button>`
    ).join("");
    container.onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      onPick(b.dataset.val);
    };
    if (from) glideSeg(container, from);
  }

  /** Slide a highlight from the old option to the new one. The buttons
      are rebuilt on every pick, so a ghost pill does the travelling and
      the real button takes its colour back when it lands. */
  function glideSeg(container, from) {
    glide(container, from, container.querySelector(".psnap-seg-on"), "psnap-seg-glide", "psnap-seg-gliding");
  }

  /** Move a highlight pill from one spot to the selected element: a
      ghost does the travelling (across rows too) while the real one
      waits transparent, then takes its colour back when it lands. */
  const boxIn = (el) => ({ x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight });
  function glide(container, from, to, ghostCls, busyCls) {
    if (!to || !to.animate || !from) return;
    container.querySelectorAll("." + ghostCls).forEach(g => g.remove());
    const t = boxIn(to);
    const g = document.createElement("i");
    g.className = ghostCls;
    Object.assign(g.style, { left: t.x + "px", top: t.y + "px", width: t.w + "px", height: t.h + "px" });
    container.classList.add(busyCls);
    container.appendChild(g);
    const a = g.animate([
      { transform: `translate(${from.x - t.x}px, ${from.y - t.y}px)`, width: from.w + "px", height: (from.h || t.h) + "px" },
      { transform: "none", width: t.w + "px", height: t.h + "px" }
    ], { duration: 340, easing: "cubic-bezier(.22,1,.36,1)" });
    const end = () => { g.remove(); if (!container.querySelector("." + ghostCls)) container.classList.remove(busyCls); };
    a.onfinish = end;
    a.oncancel = end;
  }


  // ======================================================================
  // Canva bridge
  // ======================================================================

  let canvaTabs = [];
  let lastImageUrl = "";

  /** The newest generated image on the page, found live.
      The Canva section used to depend only on a value captured at the
      moment a job finished. If that capture was ever missed — a finish
      routed through a path that didn't set it, a panel opened in a chat
      that already had images, a reload — the section had no way back and
      the button stayed grey. Looking at the page directly removes that
      whole class of failure. */
  /* Images that belong to YOU — uploads in your messages and the
     composer. Remembered by file id, so the same photo is never mistaken
     for a result even if ChatGPT re-draws it somewhere else later. */
  const userImgKeys = new Set();
  function noteUserImages() {
    for (const img of mainImages()) {
      if (inUserTurn(img)) { const k = imgKey(img); if (k) userImgKeys.add(k); }
    }
    for (const img of document.querySelectorAll("form img")) {
      if (!inComposer(img)) continue;          // a form around the whole thread isn't "yours"
      const k = imgKey(img); if (k) userImgKeys.add(k);
    }
  }

  /** Is this an image ChatGPT generated (not your input photo)? */
  function isResultImage(img) {
    if (!img || !img.isConnected) return false;
    const src = img.currentSrc || img.src || "";
    if (!src || /avatar|profile|icon|favicon|\.svg(\?|$)/i.test(src)) return false;
    if (userImgKeys.has(imgKey(img))) return false;
    if (inUserTurn(img) || !inAssistantTurn(img)) return false;
    if ((img.naturalWidth || 0) < 220 || (img.naturalHeight || 0) < 220) return false;
    // results are shown large; input thumbnails are small
    const r = img.getBoundingClientRect();
    if (r.width < 180) return false;
    return true;
  }

  let lastResultEl = null;        // the image the tracker celebrated

  /** The newest generated image on the page.
      Used to grab the last big image that wasn't inside your message —
      but ChatGPT doesn't always mark where your message ends, so an
      input photo you'd just uploaded could be picked and sent to Canva
      instead of the result. Now it only takes images from ChatGPT's
      replies, never anything you uploaded, and prefers the exact image
      the tracker saw finish. */
  function latestResultImage() {
    noteUserImages();
    let newest = null;
    for (const img of mainImages()) if (isResultImage(img)) newest = img;
    if (lastResultEl && isResultImage(lastResultEl)) {
      // keep the tracked one unless a newer result appeared after it
      if (!newest || newest === lastResultEl ||
          !(lastResultEl.compareDocumentPosition(newest) & Node.DOCUMENT_POSITION_FOLLOWING)) {
        return lastResultEl;
      }
    }
    return newest;
  }

  /** Read an image from the page and return base64.
      Tried in order: fetch (works for blob: and same-site URLs because we
      are inside the tab), then a canvas re-encode for anything fetch
      refuses. */
  async function imageToBase64(img) {
    const src = img ? (img.currentSrc || img.src || "") : "";
    if (!src) throw new Error("no image");

    // 1. straight fetch — inside the page this handles blob:, data: and
    //    the authenticated CDN, none of which a worker can touch
    try {
      const res = await fetch(src);
      if (res.ok) {
        const blob = await res.blob();
        if (blob.size > 0) {
          return await new Promise((ok, bad) => {
            const fr = new FileReader();
            fr.onload = () => ok({
              b64: String(fr.result).split(",")[1],
              mime: blob.type || "image/png"
            });
            fr.onerror = () => bad(new Error("read failed"));
            fr.readAsDataURL(blob);
          });
        }
      }
    } catch (_) { /* fall through */ }

    // 2. canvas re-encode
    return await new Promise((ok, bad) => {
      const el = new Image();
      el.crossOrigin = "anonymous";
      el.onload = () => {
        try {
          const c = document.createElement("canvas");
          c.width = el.naturalWidth || img.naturalWidth || 1024;
          c.height = el.naturalHeight || img.naturalHeight || 1024;
          c.getContext("2d").drawImage(el, 0, 0);
          const url = c.toDataURL("image/png");
          if (!url || url.length < 100) return bad(new Error("canvas empty"));
          ok({ b64: url.split(",")[1], mime: "image/png" });
        } catch (e) { bad(new Error("canvas blocked")); }
      };
      el.onerror = () => bad(new Error("image load failed"));
      el.src = src;
    });
  }

  /** What we would send right now. Prefers the live scan, falls back to
      whatever the tracker captured. */
  function currentImageUrl() {
    const img = latestResultImage();
    const live = img ? (img.currentSrc || img.src || "") : "";
    if (live) { lastImageUrl = live; return live; }
    if (lastImageUrl && userImgKeys.has(imgKey({ src: lastImageUrl }))) lastImageUrl = "";
    return lastImageUrl;
  }
  // Guards against the panel button and the finish-screen button both
  // firing for the same image.
  let canvaSending = false;
  let canvaPick = 0;              // tab id the user chose
  let canvaOpen = false;          // drawer expanded?
  let lastSent = { url: "", tabId: 0, at: 0 };

  function canvaSendGuard(tabId, url) {
    if (canvaSending) return false;
    if (url === lastSent.url && tabId === lastSent.tabId && Date.now() - lastSent.at < 6000) return false;
    canvaSending = true;
    lastSent = { url, tabId, at: Date.now() };
    return true;
  }
  const canvaSendDone = () => { canvaSending = false; };

  const REFRESH_ICON =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" '
    + 'stroke-linecap="round" stroke-linejoin="round">'
    + '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg>';

  function refreshCanvaTabs(then) {
    try {
      chrome.runtime.sendMessage({ type: "psnap-canva-tabs" }, (tabs) => {
        canvaTabs = Array.isArray(tabs) ? tabs : [];
        paintCanva();
        if (then) then();
      });
    } catch(_) { canvaTabs = []; paintCanva(); }
  }

  function paintCanva() {
    const t = T();
    const box = $("#psnap-canva");
    const list = $("#psnap-canva-tabs");
    const btn = $("#psnap-canva-send");
    const note = $("#psnap-canva-note");

    $("#psnap-canva-lbl").textContent = t.canva;
    $("#psnap-canva-refresh").innerHTML = REFRESH_ICON;
    $("#psnap-canva-refresh").title = t.refresh;
    btn.textContent = t.sendToCanva;
    $("#psnap-canva-go").title = t.openInCanva;
    $("#psnap-canva-prev").title = t.prevPage;
    $("#psnap-canva-next").title = t.nextPage;

    box.hidden = false;

    const count = $("#psnap-canva-count");
    count.textContent = canvaTabs.length ? String(canvaTabs.length) : "";
    count.classList.toggle("psnap-canva-count-on", canvaTabs.length > 0);
    // a waiting image is worth flagging while collapsed
    const imgUrl = currentImageUrl();
    box.classList.toggle("psnap-canva-ready", !!(imgUrl && canvaTabs.length));

    if (!canvaTabs.length) {
      list.innerHTML = `<div class="psnap-canva-empty">${esc(t.noCanva)}</div>`;
      btn.disabled = true;
      note.textContent = t.canvaHint;
      note.className = "psnap-canva-note";
      box.classList.remove("psnap-canva-ready");
      canvaPick = 0;
      paintCanvaCurrent();
      paintCanvaPreview();
      return;
    }

    // keep the chosen design if it's still open, otherwise the first one
    if (!canvaTabs.some(tb => tb.id === canvaPick)) canvaPick = canvaTabs[0].id;

    // One button per open design — click to switch, no dropdown, no
    // trip through Canva. Rebuilt only when the set of tabs changed so
    // the row doesn't flicker on every poll.
    const sig = canvaTabs.map(tb => tb.id + ":" + tb.title).join("|");
    if (list.dataset.sig !== sig) {
      list.dataset.sig = sig;
      list.innerHTML = canvaTabs.map(tb => `
        <button type="button" class="psnap-canva-tab" role="tab" data-id="${tb.id}" title="${esc(tb.title)}">
          <span class="psnap-canva-tab-th"></span>
          <span class="psnap-canva-tab-nm">${esc(tb.title)}</span>
        </button>`).join("");
    }
    for (const b of list.querySelectorAll(".psnap-canva-tab")) {
      const id = Number(b.dataset.id);
      const on = id === canvaPick;
      b.classList.toggle("psnap-canva-tab-on", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
      const th = b.firstElementChild;
      const m = canvaMeta[id];
      const bg = (m && m.thumb) ? `url("${m.thumb.replace(/"/g, "&quot;")}")` : "";
      if (th.style.backgroundImage !== bg) th.style.backgroundImage = bg;
      th.classList.toggle("psnap-canva-tab-th-on", !!bg);
    }

    paintCanvaCurrent();
    paintCanvaPreview();
    if (canvaPick && !canvaMeta[canvaPick]) loadCanvaPreview(canvaPick);

    btn.disabled = !imgUrl;
    note.textContent = imgUrl ? "" : t.noImageYet;
    note.className = "psnap-canva-note";
    if (canvaOpen) {
      const d = $("#psnap-canva-drawer");
      if (d.style.height !== "auto") d.style.height = "auto";
    }
  }

  /** Switch the target design from inside the panel. */
  function pickCanva(id) {
    if (!id || id === canvaPick) return;
    canvaPick = id;
    persist({ psnapCanvaPick: canvaPick });
    paintCanva();
    // show what we already have straight away, then pull a fresh one
    loadCanvaPreview(canvaPick, !!canvaMeta[canvaPick], true);
    const el = $("#psnap-canva-current");
    el.classList.remove("psnap-canva-current-flash");
    void el.offsetWidth;                       // restart the animation
    el.classList.add("psnap-canva-current-flash");
  }

  function sendToCanva() {
    const t = T();
    const btn = $("#psnap-canva-send");
    const note = $("#psnap-canva-note");
    const tabId = canvaPick;
    const img = latestResultImage();
    const imgUrl = currentImageUrl();

    if (!tabId || !imgUrl) { paintCanva(); return; }
    if (!canvaSendGuard(tabId, imgUrl)) return;

    btn.disabled = true;
    btn.textContent = t.sending;
    btn.classList.add("psnap-um-busy");
    note.textContent = t.sendingNote;
    note.className = "psnap-canva-note";

    // rolling status so a slow upload doesn't look like a hang
    let phase = 0;
    const phases = [t.sendingNote, t.uploadingNote, t.placingNote];
    const phaseTimer = setInterval(() => {
      phase = Math.min(phase + 1, phases.length - 1);
      if (note.className.indexOf("err") === -1 && note.className.indexOf("ok") === -1) {
        note.textContent = phases[phase];
      }
    }, 3500);

    const done = (okFlag, why, res) => {
      clearInterval(phaseTimer);
      canvaSendDone();
      btn.classList.remove("psnap-um-busy");
      btn.textContent = t.sendToCanva;
      btn.disabled = false;
      if (okFlag) {
        setTimeout(() => checkCanvaChanged(tabId), 1200);
        setTimeout(() => loadCanvaPreview(tabId, true), 3000);
        note.textContent = (res && res.placed) ? t.placedOnPage
                          : (res && res.uploaded) ? t.inUploads : t.sentToCanva;
        note.className = "psnap-canva-note psnap-canva-ok";
        soundSuccess();
      } else {
        note.textContent = why ? (t.canvaFail + " (" + why + ")") : t.canvaFail;
        note.className = "psnap-canva-note psnap-canva-err";
        soundError();
      }
    };

    deliverToCanva(tabId, img, imgUrl).then(
      (res) => done(!!(res && res.ok), res && res.reason, res),
      (err) => done(false, String(err && err.message || err).slice(0, 40))
    );
  }

  /** Read the image here, then ask the worker to place it. */
  async function deliverToCanva(tabId, img, imgUrl) {
    let payload = null;
    try {
      payload = await imageToBase64(img);
    } catch (e) {
      // let the worker try the URL itself as a last resort
      payload = null;
    }

    return await new Promise((resolve) => {
      let settled = false;
      const finish = (r) => { if (!settled) { settled = true; resolve(r); } };
      // Uploading and placing can genuinely take a while on a big design,
      // so give it room. The button shows progress in the meantime.
      setTimeout(() => finish({ ok: false, reason: "timed out — check Uploads" }), 60000);

      try {
        chrome.runtime.sendMessage({
          type: "psnap-canva-send",
          tabId,
          imageUrl: imgUrl,
          b64: payload ? payload.b64 : null,
          mime: payload ? payload.mime : null
        }, (res) => {
          if (chrome.runtime.lastError) {
            finish({ ok: false, reason: "extension reloaded — refresh this tab" });
            return;
          }
          finish(res || { ok: false, reason: "no reply" });
        });
      } catch (e) {
        finish({ ok: false, reason: "messaging failed" });
      }
    });
  }

  /** Open or fold the Canva section. The whole section (preview AND the
      Send row under it) grows and shrinks as one piece; animating only
      the drawer made the Send row pop in and out at full height. While
      folding, the open layout stays in place underneath and is only
      swapped for the closed one when the motion ends. */
  function setCanvaOpen(open, instant) {
    canvaOpen = open;
    const d = $("#psnap-canva-drawer");
    const box = $("#psnap-canva");
    if (!d || !box) return;

    const from = box.getBoundingClientRect().height;   // mid-motion if interrupted
    if (box._psAnim) { box._psAnim.cancel(); box._psAnim = null; }
    box.style.overflow = "";
    box.classList.remove("psnap-canva-closing");
    box.classList.toggle("psnap-canva-open", open);
    d.style.height = open ? "auto" : "0px";

    if (instant || !box.animate || !motionOK() || box.hidden) return;

    const to = box.getBoundingClientRect().height;
    if (!from || Math.abs(to - from) < 1) return;
    if (!open) {
      // keep the open layout on screen while it folds away
      box.classList.add("psnap-canva-closing");
      d.style.height = "auto";
    }
    box.style.overflow = "hidden";
    const a = box._psAnim = box.animate(
      [{ height: from + "px" }, { height: to + "px" }],
      open ? { duration: animLevel() === 1 ? 140 : 380, easing: "cubic-bezier(.22,1,.36,1)" }
           : { duration: animLevel() === 1 ? 110 : 260, easing: "cubic-bezier(.4,0,.2,1)" });
    const settle = () => {
      if (box._psAnim !== a) return;
      box._psAnim = null;
      box.style.overflow = "";
      if (!open) {
        box.classList.remove("psnap-canva-closing");
        d.style.height = "0px";
      }
    };
    a.onfinish = settle;
  }

  let canvaMeta = {};        // tabId -> { title, page, pages, thumb }

  /** Ask a Canva tab what it is showing.
      The busy flag used to be a plain boolean. If Chrome froze the Canva
      tab in the background the reply never came, the flag stayed stuck,
      and nothing updated again until you pressed Refresh. It now expires
      on its own, and is tracked per tab so switching isn't blocked by a
      slow read on another design. */
  const _metaBusy = {};                 // tabId -> started at
  function loadCanvaPreview(tabId, silent, force) {
    if (!tabId) { paintCanvaPreview(); return; }
    const box = $("#psnap-canva-preview");
    if (box && !canvaMeta[tabId] && !silent && tabId === canvaPick) {
      box.hidden = false;
      box.classList.add("psnap-canva-preview-loading");
    }
    const busy = _metaBusy[tabId];
    if (busy && !force && Date.now() - busy < 6000) return;
    const mine = _metaBusy[tabId] = Date.now();
    try {
      chrome.runtime.sendMessage({ type: "psnap-canva-meta", tabId }, (res) => {
        if (_metaBusy[tabId] === mine) delete _metaBusy[tabId];
        if (chrome.runtime.lastError || !res || !res.ok) { paintCanvaPreview(); return; }
        const prev = canvaMeta[tabId];
        canvaMeta[tabId] = {
          title: res.title || "",
          page: res.page || 0,
          pages: res.pages || 0,
          // keep the last good picture if this read came back empty
          // (a hidden Canva tab often can't draw) — but only for the
          // same page, so a page switch never shows the wrong page
          thumb: res.thumb || ((prev && prev.page === (res.page || 0)) ? prev.thumb : "") || "",
          sig: res.sig || "",
          at: Date.now()
        };
        const changed = !!(prev && prev.thumb && res.thumb && prev.thumb !== res.thumb);
        if (tabId === canvaPick) paintCanvaPreview(changed);
        paintCanvaTabThumbs();
      });
    } catch (_) { delete _metaBusy[tabId]; paintCanvaPreview(); }
  }

  function paintCanvaTabThumbs() {
    const list = $("#psnap-canva-tabs");
    if (!list) return;
    for (const b of list.querySelectorAll(".psnap-canva-tab")) {
      const m = canvaMeta[Number(b.dataset.id)];
      const th = b.firstElementChild;
      const bg = (m && m.thumb) ? `url("${m.thumb.replace(/"/g, "&quot;")}")` : "";
      if (th.style.backgroundImage !== bg) th.style.backgroundImage = bg;
      th.classList.toggle("psnap-canva-tab-th-on", !!bg);
    }
  }

  function paintCanvaPreview(changed) {
    const t = T();
    const box = $("#psnap-canva-preview");
    if (!box) return;
    const meta = canvaMeta[canvaPick];
    const tab = canvaTabs.find(tb => tb.id === canvaPick);

    if (!tab) { box.hidden = true; return; }

    box.hidden = false;
    box.classList.remove("psnap-canva-preview-loading");

    const thumb = $("#psnap-canva-thumb");
    if (meta && meta.thumb) {
      const next = `url("${meta.thumb.replace(/"/g, "&quot;")}")`;
      if (thumb.style.backgroundImage !== next) {
        thumb.style.backgroundImage = next;
        if (changed) {
          thumb.classList.remove("psnap-canva-thumb-upd");
          void thumb.offsetWidth;
          thumb.classList.add("psnap-canva-thumb-upd");
        }
      }
      thumb.classList.add("psnap-canva-thumb-on");
      thumb.textContent = "";
    } else {
      thumb.style.backgroundImage = "";
      thumb.classList.remove("psnap-canva-thumb-on");
      // show the page number rather than an empty black box
      thumb.textContent = (meta && meta.page) ? ("P" + meta.page) : "";
    }

    $("#psnap-canva-name").textContent = (meta && meta.title) || tab.title;
    const pg = meta && meta.page, tot = meta && meta.pages;
    $("#psnap-canva-prev").disabled = canvaNavBusy || !pg || pg <= 1;
    $("#psnap-canva-next").disabled = canvaNavBusy || !pg || !tot || pg >= tot;

    const pagesEl = $("#psnap-canva-pages");
    if (meta && meta.page && meta.pages) pagesEl.textContent = t.pageOf(meta.page, meta.pages);
    else if (meta && meta.pages)         pagesEl.textContent = t.pagesCount(meta.pages);
    else                                  pagesEl.textContent = t.loadingPreview;
  }

  /** Write the chosen design's name into the header row, so you can see
      which one is targeted without opening the drawer. */
  function paintCanvaCurrent() {
    const el = $("#psnap-canva-current");
    if (!el) return;
    const tab = canvaTabs.find(tb => tb.id === canvaPick);
    if (!tab) {
      el.textContent = "";
      el.title = "";
      el.classList.remove("psnap-canva-current-on");
      return;
    }
    el.textContent = tab.title;
    el.title = tab.title;
    el.classList.add("psnap-canva-current-on");
  }

  $("#psnap-canva-head").addEventListener("click", (e) => {
    if (e.target.closest("#psnap-canva-refresh")) {
      e.stopPropagation();
      _imgCache.at = 0;              // force a fresh image scan too
      canvaMeta = {};                // and a fresh preview
      const th = $("#psnap-canva-thumb");
      if (th) { th.style.backgroundImage = ""; th.classList.remove("psnap-canva-thumb-on"); }
      refreshCanvaTabs(() => loadCanvaPreview(canvaPick, false, true));
      $("#psnap-canva-refresh").classList.add("psnap-spin1");
      setTimeout(() => $("#psnap-canva-refresh").classList.remove("psnap-spin1"), 600);
      return;
    }
    setCanvaOpen(!canvaOpen);
    if (!canvaOpen) return;
    // opening it is a good moment to re-check everything
    refreshCanvaTabs(() => {
      loadCanvaPreview(canvaPick, !!canvaMeta[canvaPick], true);
      // fill in the small thumbnails for the other designs too
      canvaTabs.forEach(tb => { if (tb.id !== canvaPick && !canvaMeta[tb.id]) loadCanvaPreview(tb.id, true); });
    });
  });

  $("#psnap-canva-tabs").addEventListener("click", (e) => {
    const b = e.target.closest(".psnap-canva-tab");
    if (b) pickCanva(Number(b.dataset.id));
  });
  /* ‹ › — flip pages in the Canva design from here. */
  let canvaNavBusy = false;
  function canvaGo(dir) {
    if (!canvaPick || canvaNavBusy) return;
    const tabId = canvaPick;
    const meta = canvaMeta[tabId];
    canvaNavBusy = true;
    // show the target page number straight away so it feels instant
    if (meta && meta.page) {
      meta.page = Math.max(1, Math.min(meta.pages || 9999, meta.page + dir));
    }
    $("#psnap-canva-preview").classList.add("psnap-canva-preview-loading");
    paintCanvaPreview();
    try {
      chrome.runtime.sendMessage({ type: "psnap-canva-goto", tabId, dir }, (res) => {
        canvaNavBusy = false;
        $("#psnap-canva-preview").classList.remove("psnap-canva-preview-loading");
        if (chrome.runtime.lastError || !res || !res.pages) { loadCanvaPreview(tabId, true, true); return; }
        canvaMeta[tabId] = {
          title: res.title || "", page: res.page || 0, pages: res.pages || 0,
          thumb: res.thumb || "", sig: res.sig || "", at: Date.now()
        };
        paintCanvaPreview(true);
        paintCanvaTabThumbs();
        // the strip picture can lag a moment behind the page switch
        setTimeout(() => loadCanvaPreview(tabId, true, true), 900);
      });
    } catch (_) { canvaNavBusy = false; paintCanvaPreview(); }
  }
  $("#psnap-canva-prev").addEventListener("click", (e) => { e.stopPropagation(); canvaGo(-1); });
  $("#psnap-canva-next").addEventListener("click", (e) => { e.stopPropagation(); canvaGo(1); });

  $("#psnap-canva-go").addEventListener("click", () => {
    if (!canvaPick) return;
    try { chrome.runtime.sendMessage({ type: "psnap-canva-focus", tabId: canvaPick }); } catch (_) {}
  });

  /* Live updates pushed from the background worker:
     - the list of open designs changed (opened, closed, renamed)
     - a design was edited, or its page changed
     No polling needed and no Refresh button. */
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return;
      if (msg.type === "psnap-canva-tabs-changed" && Array.isArray(msg.tabs)) {
        const gone = canvaTabs.filter(a => !msg.tabs.some(b => b.id === a.id));
        gone.forEach(g => { delete canvaMeta[g.id]; });
        canvaTabs = msg.tabs;
        paintCanva();
        // a brand-new design: grab its thumbnail
        msg.tabs.forEach(tb => { if (!canvaMeta[tb.id]) loadCanvaPreview(tb.id, true); });
      }
      if (msg.type === "psnap-canva-changed" && msg.tabId) {
        const known = canvaMeta[msg.tabId];
        if (!known || known.sig !== msg.sig) loadCanvaPreview(msg.tabId, true, true);
      }
    });
  } catch (_) {}
  $("#psnap-canva-send").addEventListener("click", () => sendToCanva(true));

  // A light watch so the button wakes up on its own when an image lands,
  // even if the tracker never reported a finish. Only runs while the
  // panel is actually open, and only repaints when something changed.
  // Keep the design preview current while the drawer is open.
  // Polling asks only for a small signature; the full thumbnail is
  // pulled when that signature actually changed, so editing in Canva
  // shows up here without re-sending an image every few seconds.
  setInterval(() => {
    if (!panel.classList.contains("psnap-open")) return;
    if (!canvaOpen || !canvaPick) return;
    checkCanvaChanged(canvaPick);
  }, 2500);

  function checkCanvaChanged(tabId) {
    if (checkCanvaChanged._busy && Date.now() - checkCanvaChanged._busy < 6000) return;
    checkCanvaChanged._busy = Date.now();
    try {
      chrome.runtime.sendMessage({ type: "psnap-canva-meta", tabId, sigOnly: true }, (res) => {
        checkCanvaChanged._busy = false;
        if (chrome.runtime.lastError || !res || !res.ok) return;
        const known = canvaMeta[tabId];
        // page moved, design renamed, or the page thumbnail changed
        if (!known || known.sig !== res.sig) {
          // the design moved on — drop what we have so the next read is
          // never merged with stale values
          loadCanvaPreview(tabId, true, true);
        }
      });
    } catch (_) { checkCanvaChanged._busy = false; }
  }

  // Coming back to this tab is a good moment to re-check
  // Coming back from Canva: pull a fresh picture straight away instead of
  // waiting for a signature change (a canvas edit doesn't always move it).
  const onBackFromCanva = () => {
    if (document.hidden || !panel.classList.contains("psnap-open")) return;
    refreshCanvaTabs(() => { if (canvaOpen && canvaPick) loadCanvaPreview(canvaPick, true, true); });
  };
  document.addEventListener("visibilitychange", onBackFromCanva);
  window.addEventListener("focus", onBackFromCanva);

  let _lastSeenImg = "";
  setInterval(() => {
    if (!panel.classList.contains("psnap-open")) return;
    const url = currentImageUrl();
    if (url === _lastSeenImg) return;
    _lastSeenImg = url;
    paintCanva();
  }, 1500);

  // ======================================================================
  // Guardrail / refusal detection
  // ======================================================================

  const REFUSAL_PATTERNS = [
    /i can'?t (help with|create|generate|make|produce) th(at|is)/i,
    /i'?m (not able|unable) to (create|generate|make|produce)/i,
    /i wasn'?t able to (create|generate|produce)/i,
    /(violates?|against|doesn'?t follow) (our |the )?(content|usage) polic/i,
    /content polic(y|ies)/i,
    /this request (was|has been) (blocked|flagged)/i,
    /(can'?t|cannot) (create|generate) images? (of|that|depicting)/i,
    /i'?m sorry,? but i (can'?t|cannot)/i,
    /didn'?t pass (our )?(content|safety)/i,
    /flagged by (our )?(content|safety) (system|filter)/i,
    /unable to (comply|continue) with/i
  ];

  /** Read the tail of the last assistant message. */
  function lastAssistantText() {
    const main = chatRoot();
    if (!main) return "";
    const turns = main.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (!last) return "";
    return (last.textContent || "").slice(-1200);
  }

  function looksRefused(text) {
    if (!text || text.length < 12) return false;
    return REFUSAL_PATTERNS.some(re => re.test(text));
  }

  function showBlocked(reason) {
    const t = T();
    document.getElementById("psnap-blocked")?.remove();

    const el = document.createElement("div");
    el.id = "psnap-blocked";
    el.className = "psnap-ui psnap-blocked"
      + (panel.classList.contains("psnap-light") ? " psnap-blocked-light" : "");
    el.innerHTML = `
      <div class="psnap-bl-ico">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
             stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="9"/><path d="M12 7v6"/><path d="M12 16.5v.01"/>
        </svg>
      </div>
      <div class="psnap-bl-txt">
        <strong>${esc(t.blocked)}</strong>
        <span>${esc(reason || t.blockedSub)}</span>
        <em>${esc(t.blockedHint)}</em>
      </div>
      <button class="psnap-bl-x" title="${esc(t.dismiss)}">&times;</button>
    `;
    document.body.appendChild(el);
    playIn(el, "psnap-bl-in");

    const close = () => {
      el.classList.remove("psnap-bl-in");
      el.style.pointerEvents = "none";
      setTimeout(() => el.remove(), 320);
    };
    el.querySelector(".psnap-bl-x").onclick = close;
    el.addEventListener("click", (e) => { if (e.target === el) close(); });
    setTimeout(close, 11000);

    soundError();
    if (document.hidden) {
      try {
        if (Notification.permission === "granted")
          new Notification("PromptSnap", { body: t.blockedSub });
      } catch(_) {}
    }
  }

  // ======================================================================
  // Updates
  // ======================================================================

  let updateState = null;

  const myVersion = () => {
    try { return chrome.runtime.getManifest().version; } catch(_) { return "?"; }
  };

  function renderUpdateBanner() {
    const box = $("#psnap-update");
    const t = T();
    const u = updateState;

    const show = !!(u && u.available && u.latest && u.dismissed !== u.latest);
    if (show !== slideOpen(box)) slide(box, show);
    $("#psnap-gear").classList.toggle("psnap-has-update", show);
    fab.classList.toggle("psnap-has-update", show);
    if (!show) return;

    $("#psnap-up-title").textContent = t.updateAvailable;
    $("#psnap-up-sub").textContent   = `${t.newVersion(u.latest)} · ${t.youHave(u.current)}`;
    $("#psnap-up-later").textContent = t.later;
    $("#psnap-up-go").textContent    = t.updateNow;

    const notes = $("#psnap-up-notes");
    if (u.notes) { notes.textContent = u.notes; notes.hidden = false; }
    else notes.hidden = true;

    box.classList.toggle("psnap-up-required", !!u.required);
    $("#psnap-up-later").style.display = u.required ? "none" : "";
  }

  $("#psnap-up-later").addEventListener("click", () => {
    if (!updateState || !updateState.latest) return;
    const next = Object.assign({}, updateState, { dismissed: updateState.latest });
    updateState = next;
    persist({ psnapUpdate: next });
    try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
    renderUpdateBanner();
  });

  $("#psnap-up-go").addEventListener("click", () => showUpdateModal());


  // ----------------------------------------------------------------------
  // Update modal — version cards, changelog, one-button install
  // ----------------------------------------------------------------------

  function showUpdateModal() {
    const t = T();
    const u = updateState || {};
    document.getElementById("psnap-um")?.remove();

    const isLatest = !u.available;
    const mine = u.current || myVersion();

    // When you are up to date, the notes on file describe the version you
    // are ALREADY RUNNING — so label them that way. Showing "What's new"
    // next to an old-to-new arrow between two identical numbers was just
    // misleading.
    const addedTitle = isLatest ? t.inThisVersion   : t.whatsNew;
    const fixedTitle = isLatest ? t.fixedThisVersion : t.whatsFixed;

    const list = (items, offset) => items.map((x, i) =>
      `<li style="animation-delay:${(offset + i * 0.05).toFixed(2)}s">${esc(x)}</li>`).join("");

    const hasNew   = (u.added || []).length > 0;
    const hasFixed = (u.fixed || []).length > 0;
    const history  = Array.isArray(u.history) ? u.history.filter(h => h.version !== u.latest) : [];

    // version display: a single pill when current, a transition when not
    const versionBlock = isLatest
      ? `<div class="psnap-um-vers psnap-um-vers-one">
           <span class="psnap-um-vlabel">${esc(t.installedVersion)}</span>
           <span class="psnap-um-v psnap-um-newv">v${esc(mine)}</span>
         </div>`
      : `<div class="psnap-um-vers">
           <span class="psnap-um-v psnap-um-old">v${esc(mine)}</span>
           <span class="psnap-um-arrow">
             <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"
                  stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M13 6l6 6-6 6"/></svg>
           </span>
           <span class="psnap-um-v psnap-um-newv">v${esc(u.latest || mine)}</span>
         </div>`;

    // sub-line under the title
    const sub = isLatest
      ? esc(t.upToDateSub)
      : (u.notes ? esc(u.notes) : "");

    const body = (hasNew || hasFixed)
      ? `${hasNew ? `
          <div class="psnap-um-sec psnap-um-sec-new">
            <h4><span class="psnap-um-pill psnap-um-pill-new">+</span>${esc(addedTitle)}</h4>
            <ul>${list(u.added, 0.18)}</ul>
          </div>` : ""}
         ${hasFixed ? `
          <div class="psnap-um-sec psnap-um-sec-fix">
            <h4><span class="psnap-um-pill psnap-um-pill-fix">&#10003;</span>${esc(fixedTitle)}</h4>
            <ul>${list(u.fixed, 0.18 + (u.added || []).length * 0.05)}</ul>
          </div>` : ""}`
      : `<div class="psnap-um-empty">${esc(t.noChangelog)}</div>`;

    const historyBlock = history.length
      ? `<details class="psnap-um-history">
           <summary>${esc(t.earlier)}</summary>
           ${history.map(h => `
             <div class="psnap-um-hitem">
               <strong>v${esc(h.version)}</strong>
               <ul>${[...(h.added || []), ...(h.fixed || [])]
                     .map(x => `<li>${esc(x)}</li>`).join("")}</ul>
             </div>`).join("")}
         </details>`
      : "";

    const el = document.createElement("div");
    el.id = "psnap-um";
    el.className = "psnap-ui psnap-um" + (panel.classList.contains("psnap-light") ? " psnap-um-light" : "")
                 + (isLatest ? " psnap-um-current" : "");
    el.innerHTML = `
      <div class="psnap-um-box" role="dialog">
        <button class="psnap-um-x" id="psnap-um-x">&times;</button>

        <div class="psnap-um-head">
          <div class="psnap-um-icon">
            ${isLatest
              ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"
                      stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 7"/></svg>`
              : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                      stroke-linecap="round" stroke-linejoin="round">
                   <path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></svg>`}
          </div>
          <div class="psnap-um-title">${esc(isLatest ? t.allDone : t.updateAvailable)}</div>
        </div>

        ${versionBlock}
        ${sub ? `<div class="psnap-um-notes">${sub}</div>` : ""}

        <div class="psnap-um-body">
          ${body}
          ${historyBlock}
        </div>

        <div class="psnap-um-foot">
          ${isLatest
            ? `<button class="psnap-btn psnap-primary psnap-um-go" id="psnap-um-close2">${esc(t.close)}</button>`
            : `<button class="psnap-btn psnap-um-later" id="psnap-um-later">${esc(t.later)}</button>
               <button class="psnap-btn psnap-primary psnap-um-go" id="psnap-um-go">
                 <span class="psnap-um-golabel">${esc(t.updateNow)}</span>
               </button>`}
        </div>

        <div class="psnap-um-done" id="psnap-um-done" hidden>
          <div class="psnap-um-check">
            <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 15-16"/></svg>
          </div>
          <div class="psnap-um-donetitle" id="psnap-um-donetitle"></div>
          <div class="psnap-um-donesub" id="psnap-um-donesub"></div>
          <div class="psnap-um-doneact" id="psnap-um-doneact"></div>
        </div>
      </div>
    `;
    document.body.appendChild(el);
    playIn(el, "psnap-um-in");

    // "-in" stays on while closing so the pills and list keep their
    // landed state; "-out" fades the card and backdrop away together
    const close = () => {
      el.classList.add("psnap-um-out");
      setTimeout(() => el.remove(), 320);
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    document.addEventListener("keydown", onKey, true);

    el.querySelector("#psnap-um-x").onclick = close;
    el.querySelector("#psnap-um-close2") && (el.querySelector("#psnap-um-close2").onclick = close);
    el.addEventListener("click", (e) => { if (e.target === el) close(); });

    const later = el.querySelector("#psnap-um-later");
    if (later) later.onclick = () => {
      if (updateState && updateState.latest) {
        updateState = Object.assign({}, updateState, { dismissed: updateState.latest });
        persist({ psnapUpdate: updateState });
        try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
        renderUpdateBanner();
      }
      close();
    };

    const go = el.querySelector("#psnap-um-go");
    if (go) go.onclick = () => runInstall(el, go, close);
  }

  /** The install sequence. Content updates land by themselves; a code
      update starts the download and shows the single remaining step. */
  function runInstall(el, btn, close) {
    const t = T();
    const u = updateState || {};

    btn.disabled = true;
    btn.classList.add("psnap-um-busy");
    btn.querySelector(".psnap-um-golabel").textContent = t.installing;

    const finish = (res) => {
      const lines = [];
      if (res && res.ok) {
        if (res.presets) lines.push(t.contentApplied(res.presets));
        if (res.chips)   lines.push(t.chipsApplied(res.chips));
      }

      const needsReload = !u.content || u.needsReload !== false;

      el.querySelector(".psnap-um-box").classList.add("psnap-um-flip");
      const done = el.querySelector("#psnap-um-done");
      done.hidden = false;
      playIn(done, "psnap-um-done-in");

      el.querySelector("#psnap-um-donetitle").textContent =
        needsReload ? t.reloadNeeded : t.installed;
      if (needsReload) soundUpdate();
      el.querySelector("#psnap-um-donesub").textContent =
        needsReload ? t.reloadSteps : lines.join(" · ");

      const act = el.querySelector("#psnap-um-doneact");
      if (needsReload) {
        // Hand the download to Chrome itself rather than opening a tab —
        // it lands in the Downloads folder with a predictable name.
        let started = false;
        try {
          chrome.runtime.sendMessage({ type: "psnap-download-update" }, (r) => {
            started = !!(r && r.ok);
          });
        } catch(_) {}

        act.innerHTML =
          `<button class="psnap-btn psnap-primary" id="psnap-um-ext">${esc(t.reloadBtn)}</button>
           <button class="psnap-btn" id="psnap-um-folder">${esc(t.showFile)}</button>`;
        act.querySelector("#psnap-um-ext").onclick = () => {
          try { chrome.runtime.sendMessage({ type:"psnap-open-extensions" }); } catch(_) {}
        };
        act.querySelector("#psnap-um-folder").onclick = () => {
          try { chrome.runtime.sendMessage({ type:"psnap-show-download" }); } catch(_) {}
        };
      } else {
        // content-only update — fully installed, reload the panel data
        act.innerHTML = `<button class="psnap-btn psnap-primary" id="psnap-um-ok">${esc(t.close)}</button>`;
        act.querySelector("#psnap-um-ok").onclick = () => { close(); reloadData(); };
        soundSuccess();
        setTimeout(() => { close(); reloadData(); }, 3200);
      }
    };

    try {
      chrome.runtime.sendMessage({ type: "psnap-apply-content" }, (res) => finish(res));
    } catch(_) { finish(null); }
  }

  /** Re-read presets and chips after a content update, without a reload. */
  function reloadData() {
    try {
      chrome.storage.local.get(["psnapPresets","psnapCustom"], (r) => {
        if (Array.isArray(r.psnapPresets) && r.psnapPresets.length) storedPresets = r.psnapPresets;
        if (r.psnapCustom && typeof r.psnapCustom === "object") custom = r.psnapCustom;
        setLibrary();
        fillPresets(); buildVars(); render();
        renderUpdateBanner();
      });
    } catch(_) {}
  }

  function checkForUpdate(openModal) {
    const t = T();
    const before = (updateState && updateState.latest) || "";
    const btn = $("#set-check");
    if (btn) { btn.textContent = t.checking; btn.disabled = true; }
    try {
      chrome.runtime.sendMessage({ type:"psnap-check-update" }, (res) => {
        if (res) { updateState = res; renderUpdateBanner(); }
        paintUpdateMeta();
        if (btn) { btn.textContent = t.checkNow; btn.disabled = false; }
        if (res && res.error) soundError();
        else if (res && res.available && res.latest !== before) soundUpdate();
        if (openModal) showUpdateModal();
      });
    } catch(_) {
      if (btn) { btn.textContent = t.checkNow; btn.disabled = false; }
    }
  }

  function paintUpdateMeta() {
    const el = $("#set-upmeta");
    if (!el) return;
    const t = T();
    const u = updateState;
    if (!u) { el.textContent = `v${myVersion()}`; return; }
    if (u.error) { el.innerHTML = `v${esc(u.current || myVersion())} · <span class="psnap-up-err">${esc(t.checkFailed)}</span>`; return; }
    const when = u.checkedAt ? new Date(u.checkedAt).toLocaleString() : t.never;
    const status = u.available ? `<span class="psnap-up-new">${esc(t.updateAvailable)}</span>`
                               : esc(t.upToDate);
    el.innerHTML = `v${esc(u.current || myVersion())} · ${status}<br><span class="psnap-up-when">${esc(t.lastChecked)}: ${esc(when)}</span>`;
  }

  // react to a check that finished in the background
  try {
    // favourites, recents and My presets changed in another ChatGPT tab:
    // take them over, so saving here never overwrites what was made there
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
      const list = (c) => Array.isArray(c && c.newValue) ? c.newValue : [];
      let changed = false;
      if (changes.psnapFav && !same(list(changes.psnapFav), fav)) { fav = list(changes.psnapFav); changed = true; }
      if (changes.psnapRecent && !same(list(changes.psnapRecent), recent)) { recent = list(changes.psnapRecent); changed = true; }
      if (changes.psnapMine && !same(list(changes.psnapMine), mine)) {
        mine = list(changes.psnapMine).filter(m => m && typeof m.id === "string" && typeof m.name === "string" && typeof m.text === "string");
        const was = state.pid, wasText = (presets[state.preset] || {}).text;
        setLibrary();
        if (state.pid !== was || (presets[state.preset] || {}).text !== wasText) { buildVars(); render(); }
        changed = true;
      }
      if (changed) { fillPresets(); libDirty = true; if (libOpen && !edOpen) renderLib(); }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.psnapUpdate) return;
      const prev = changes.psnapUpdate.oldValue || {};
      updateState = changes.psnapUpdate.newValue;
      renderUpdateBanner();
      paintUpdateMeta();
      // announce a genuinely new version, once
      const u = updateState || {};
      if (u.available && u.latest && u.latest !== prev.latest && u.dismissed !== u.latest) {
        soundUpdate();
      }
    });
  } catch(_) {}

  function paintSettings() {
    const t = T();
    $("#set-lbl-sound").textContent = t.sound;
    $("#set-lbl-cel").textContent   = t.celebration;
    $("#set-lbl-theme").textContent = t.theme;

    seg($("#set-sound"), [{val:"on",label:t.on},{val:"off",label:t.off}],
      soundOn ? "on" : "off", v => {
        soundOn = (v === "on");
        persist({ psnapSound: soundOn });
        paintSettings();
        if (soundOn) previewChime();
      });

    seg($("#set-cel"), [
      {val:"full",    label:t.celFull},
      {val:"classic", label:t.celClassic},
      {val:"off",     label:t.celOff}
    ], celebration, v => {
      celebration = v;
      persist({ psnapCel: celebration });
      paintSettings();
      if (v !== "off") previewCelebration();
    });

    $("#set-lbl-updates").textContent = t.updates;
    const chk = $("#set-check");
    chk.textContent = t.checkNow;
    chk.onclick = () => checkForUpdate(true);
    paintUpdateMeta();

    $("#set-lbl-anim").textContent = t.animation;
    seg($("#set-anim"), [
      {val:"full",    label:t.animFull},
      {val:"reduced", label:t.animReduced},
      {val:"minimal", label:t.animMinimal},
      {val:"off",     label:t.animOff}
    ], anim, v => { anim = v; persist({ psnapAnim: anim }); applyAnim(); paintSettings(); });

    $("#set-lbl-size").textContent = t.panelSize;
    seg($("#set-size"), [
      {val:"s", label:t.sizeS},
      {val:"m", label:t.sizeM},
      {val:"l", label:t.sizeL}
    ], panelSize, v => { panelSize = v; persist({ psnapSize: v }); applySize(true); paintSettings(); });

    seg($("#set-theme"), [
      {val:"dark",  label:t.thDark},
      {val:"light", label:t.thLight},
      {val:"auto",  label:t.thAuto}
    ], theme, v => { theme = v; persist({ psnapTheme: theme }); applyTheme(true); paintSettings(); });
  }

  /** Animation level is a class on <html>, so every element the
      extension owns (panel, button, overlays) reads it from one place. */
  /* Panel size — Small is the default so it doesn't cover the chat. */
  let panelSize = "s";
  function applySize(animate) {
    // FLIP: measure, switch, then ease from the old box to the new one
    const before = (animate && smoothOK() && panel.animate && panel.classList.contains("psnap-shown"))
      ? panel.getBoundingClientRect() : null;
    panel.classList.remove("psnap-size-s", "psnap-size-m", "psnap-size-l");
    panel.classList.add("psnap-size-" + panelSize);
    if (!before) return;
    const after = panel.getBoundingClientRect();
    if (!after.width || !after.height) return;
    // grow from whichever corner the panel is pinned to
    const origin = panel.style.left && panel.style.left !== "auto" ? "0 0" : "100% 100%";
    panel.animate([
      { transformOrigin: origin,
        transform: `scale(${before.width / after.width}, ${before.height / after.height})` },
      { transformOrigin: origin, transform: "none" }
    ], { duration: 320, easing: "cubic-bezier(.22,1,.36,1)" });
  }

  function applyAnim() {
    const root = document.documentElement;
    root.classList.remove("psnap-anim-full","psnap-anim-reduced","psnap-anim-minimal","psnap-anim-off");
    root.classList.add("psnap-anim-" + anim);
  }

  /** Cheap gate used by JS-driven effects (confetti counts etc). */
  const animLevel = () => ({ full:3, reduced:2, minimal:1, off:0 })[anim] ?? 3;

  // ----------------------------------------------------------------------
  // Motion helpers
  // ----------------------------------------------------------------------

  const reducedMotion = () => {
    try { return window.matchMedia("(prefers-reduced-motion: reduce)").matches; }
    catch (_) { return false; }
  };
  /** Any motion at all (drawers still slide on Minimal, just faster). */
  const motionOK = () => animLevel() > 0 && !reducedMotion();
  /** Decorative motion — gliding pills, count-ups, morphs. */
  const smoothOK = () => animLevel() >= 2 && !reducedMotion();

  /** Start an enter transition reliably. Flushing style first gives the
      browser a "before" pose to animate from; flipping the class inside a
      bare rAF can land in the same style pass as the insert, and then the
      element just pops in with no transition. */
  function playIn(el, cls) {
    void el.offsetWidth;
    el.classList.add(cls);
  }

  /** Expand or collapse a block — height, padding, margins and a fade —
      instead of a hard `hidden` jump. It still ends on `hidden`, so every
      existing check keeps working, and an interrupted slide turns round
      from where it is rather than snapping. */
  const SLIDE_PROPS = ["height", "paddingTop", "paddingBottom", "marginTop", "marginBottom",
                       "borderTopWidth", "borderBottomWidth"];
  const boxOf = (el, opacity) => {
    const cs = getComputedStyle(el), k = { opacity: opacity ?? cs.opacity };
    SLIDE_PROPS.forEach(p => { k[p] = cs[p]; });
    return k;
  };
  function slide(el, show) {
    if (!el) return;
    el._psOpen = show;
    const running = el._psSlide;
    const from = running ? boxOf(el) : null;      // read before cancelling
    if (running) { running.cancel(); el._psSlide = null; }
    el.style.overflow = "";

    if (!el.animate || !motionOK()) { el.hidden = !show; return; }

    el.hidden = false;
    const full = boxOf(el, 1);
    const zero = { opacity: 0 };
    SLIDE_PROPS.forEach(p => { zero[p] = "0px"; });
    el.style.overflow = "hidden";
    const quick = animLevel() === 1;
    const a = el._psSlide = el.animate(
      [from || (show ? zero : full), show ? full : zero],
      show ? { duration: quick ? 120 : 300, easing: "cubic-bezier(.22,1,.36,1)" }
           : { duration: quick ? 100 : 220, easing: "cubic-bezier(.4,0,.2,1)" });
    a.onfinish = () => {
      if (el._psSlide !== a) return;
      el._psSlide = null;
      el.style.overflow = "";
      if (!show) el.hidden = true;
    };
  }
  /** Where a slid block is heading (open while it is still unfolding). */
  const slideOpen = (el) => (el._psSlide ? !!el._psOpen : !el.hidden);

  /** Short fade-up when a piece of text is swapped in place. */
  function freshen(el) {
    if (!el || !el.animate || !smoothOK()) return;
    el.animate([{ opacity: 0, transform: "translateY(3px)" }, { opacity: 1, transform: "none" }],
               { duration: 260, easing: "cubic-bezier(.22,1,.36,1)" });
  }

  function applyTheme(animate) {
    let effective = theme;
    if (theme === "auto") {
      effective = document.documentElement.classList.contains("light")
        || document.body.classList.contains("light")
        || window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    }
    // cross-fade the colours instead of flashing from one theme to the other
    if (animate && animLevel() > 0 && panel.classList.contains("psnap-light") !== (effective === "light")) {
      [panel, toast].forEach(el => el.classList.add("psnap-theme-shift"));
      clearTimeout(applyTheme._t);
      applyTheme._t = setTimeout(() =>
        [panel, toast].forEach(el => el.classList.remove("psnap-theme-shift")), 450);
    }
    panel.classList.toggle("psnap-light", effective === "light");
    toast.classList.toggle("psnap-light", effective === "light");
    fabWrap.classList.toggle("psnap-light", effective === "light");
    if (lib) lib.classList.toggle("psnap-lib-light", effective === "light");
  }

  try {
    window.matchMedia("(prefers-color-scheme: light)")
      .addEventListener("change", () => { if (theme === "auto") applyTheme(true); });
  } catch(_) {}

  const persist = (obj) => { try { chrome.storage.local.set(obj); } catch(_) {} };

  // If the tracker ever gets stuck, clicking the status badge clears it.
  $("#psnap-status").addEventListener("click", () => {
    if (tracking || isImageJob) { standDown(); hint(T().hintReset, true); }
  });
  $("#psnap-status").title = "Click to reset the tracker";

  $("#psnap-gear").addEventListener("click", () => {
    const box = $("#psnap-settings");
    const show = !slideOpen(box);
    if (show) { box.hidden = false; paintSettings(); }   // fill it before measuring
    slide(box, show);
    $("#psnap-gear").classList.toggle("psnap-gear-open", show);
  });

  /** Small preview so you can hear/see what you just picked. */
  function previewCelebration() {
    if (celebration === "classic") { burst(); chime(); }
    else { fullScreenCelebration(3, null); chimeBig(); }
  }

  function previewChime() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      [1046.5, 1568.0].forEach((f, i) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.value = f;
        o.connect(g); g.connect(ctx.destination);
        const t0 = ctx.currentTime + i * 0.09;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.18, t0 + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.28);
        o.start(t0); o.stop(t0 + 0.3);
      });
      setTimeout(() => ctx.close(), 900);
    } catch(_) {}
  }

  panel.querySelector("#psnap-langsw").addEventListener("click", e => {
    const b = e.target.closest(".psnap-lang"); if (!b) return;
    lang = b.dataset.lang;
    applyLanguage();
    try { chrome.storage.local.set({ psnapLang: lang }); } catch(_) {}
  });

  // ======================================================================
  // Dynamic fields + suggestion chips
  // ======================================================================

  function varNames(text) {
    const out = []; const re = /\{(\w+)\}/g; let m;
    while ((m = re.exec(text))) if (!RESERVED.has(m[1]) && !out.includes(m[1])) out.push(m[1]);
    return out;
  }
  const suggestionsFor = (n) => [...ownList(SUGGESTIONS, n), ...ownList(custom, n)];
  /** A preset can borrow another field for one of its words (Text-Safe
      Background's {angle} means a side, not a camera angle). The value,
      chips and label all live under the borrowed field's name. */
  const fieldKey = (p, n) => {
    const a = p && p.alias && typeof p.alias === "object" ? own(p.alias, n) : undefined;
    return typeof a === "string" && a ? a : n;
  };

  function buildVars() {
    const t = T();
    const wrap = $("#psnap-vars");
    const cur = presets[state.preset];
    const names = [...new Set(varNames(cur.text).map(w => fieldKey(cur, w)))];

    wrap.innerHTML = names.map(n => {
      const val  = esc(own(state.vars, n) || "");
      const big  = (n === "story" || n === "free");
      const sugg = suggestionsFor(n);

      let html = `<div class="psnap-field" data-field="${n}">
        <label class="psnap-label"><span>${esc(fieldLabel(n))}</span>
          ${sugg.length ? `<button class="psnap-sugg-toggle" data-t="${n}">${esc(t.suggestions)}</button>` : ""}
        </label>`;

      html += big
        ? `<textarea data-v="${n}" rows="4" placeholder="${esc(t.ph_story)}">${val}</textarea>`
        : `<input type="text" data-v="${n}" value="${val}" placeholder="${esc(t.ph_typePick)}">`;

      if (sugg.length) {
        const builtIn = ownList(SUGGESTIONS, n).length;
        html += `<div class="psnap-sugg" data-s="${n}" hidden><div class="psnap-chips">` +
          sugg.map((s,i) => {
            const isCustom = i >= builtIn;
            return `<span class="psnap-chip psnap-sm${isCustom ? " psnap-custom" : ""}" `
              + `data-pick="${esc(s)}" data-var="${n}" title="${esc(s)}">${esc(L(s))}`
              + (isCustom ? `<i class="psnap-x" data-del="${esc(s)}" data-var="${n}">&times;</i>` : "")
              + `</span>`;
          }).join("") +
          `</div><div class="psnap-addrow">
            <input type="text" class="psnap-addinput" data-add="${n}" placeholder="${esc(t.addOwn)}">
            <button class="psnap-addbtn" data-addbtn="${n}">${esc(t.save)}</button>
          </div></div>`;
      }
      return html + `</div>`;
    }).join("");

    wrap.querySelectorAll("[data-v]").forEach(el =>
      el.addEventListener("input", () => { state.vars[el.dataset.v] = el.value; render(); save(); }));
    wrap.querySelectorAll(".psnap-addinput").forEach(inp =>
      inp.addEventListener("keydown", e => {
        if (e.key === "Enter") { e.preventDefault(); addCustom(inp.dataset.add, inp.value); }
      }));
    wrap.onclick = onVarClick;
    markChips();
  }

  function markChips() {
    Object.entries(state.vars).forEach(([k,v]) =>
      panel.querySelectorAll(`.psnap-chip[data-var="${k}"]`)
        .forEach(c => c.classList.toggle("psnap-on", c.dataset.pick === v)));
  }

  function onVarClick(e) {
    const t = e.target;

    const tog = t.closest(".psnap-sugg-toggle");
    if (tog) {
      e.preventDefault();
      const box = panel.querySelector(`.psnap-sugg[data-s="${tog.dataset.t}"]`);
      const show = !slideOpen(box);
      slide(box, show);
      tog.classList.toggle("psnap-on2", show);
      return;
    }

    const del = t.closest(".psnap-x");
    if (del) {
      e.stopPropagation();
      const v = del.dataset.var;
      custom[v] = ownList(custom, v).filter(x => x !== del.dataset.del);
      if (state.vars[v] === del.dataset.del) state.vars[v] = "";
      saveCustom(); save(); buildVars(); render();
      return;
    }

    const chip = t.closest(".psnap-chip[data-pick]");
    if (chip) {
      const v = chip.dataset.var, picked = chip.dataset.pick;
      state.vars[v] = (state.vars[v] === picked) ? "" : picked;   // English value
      panel.querySelector(`[data-v="${v}"]`).value = state.vars[v];
      markChips(); render(); save();
      return;
    }

    const add = t.closest(".psnap-addbtn");
    if (add) addCustom(add.dataset.addbtn,
      panel.querySelector(`.psnap-addinput[data-add="${add.dataset.addbtn}"]`).value);
  }

  function addCustom(name, value) {
    const v = (value || "").trim();
    if (!v) return;
    if (!Array.isArray(own(custom, name))) custom[name] = [];
    if (!custom[name].includes(v) && !ownList(SUGGESTIONS, name).includes(v)) custom[name].push(v);
    state.vars[name] = v;
    saveCustom(); save(); buildVars(); render();
    const box = panel.querySelector(`.psnap-sugg[data-s="${name}"]`);
    if (box) {
      box.hidden = false;
      panel.querySelector(`.psnap-sugg-toggle[data-t="${name}"]`)?.classList.add("psnap-on2");
    }
  }

  // ======================================================================
  // Prompt assembly — always English
  // ======================================================================

  function buildPrompt() {
    const cur = presets[state.preset];
    let t = cur.text;
    const auto = { ratio:state.ratio, quality:state.quality, style:state.style };
    t = t.replace(/\{(\w+)\}/g, (_, k) => {
      const raw = RESERVED.has(k) ? auto[k] : own(state.vars, fieldKey(cur, k));
      const v = (typeof raw === "string" ? raw : "").trim();
      return v || `[${k}]`;
    });
    return t
      .replace(/Aspect ratio Keep original\./g, "Keep the original aspect ratio.")
      .replace(/aspect ratio Keep original\./g, "keep the original aspect ratio.")
      .replace(/in Keep original ratio/gi, "in its original ratio")
      .replace(/\ba Keep original frame/gi, "the original frame")
      .replace(/\s*Shot in —\./g, "")
      .replace(/Shot in —, (\w)/g, (_, c) => c.toUpperCase())
      .replace(/, taken in —/g, "")
      .replace(/taken in —/g, "shot naturally")
      .replace(/in — quality/g, "in high quality")
      .replace(/(^|[.!?]\s+)— quality/g, "$1High quality")
      .replace(/— quality/g, "high quality")
      .replace(/[ \t]+([.,])/g, "$1")
      .replace(/[ \t]{2,}/g, " ")
      .trim();
  }

  /* The final prompt briefly highlights the words that just changed, so
     you can see where a pick or a keystroke landed in it. */
  let _shownPrompt = null;
  const render = () => {
    const el = $("#psnap-preview");
    const text = buildPrompt();
    const prev = _shownPrompt;
    _shownPrompt = text;
    if (prev === null || prev === text || !smoothOK() || !panel.classList.contains("psnap-shown")) {
      el.textContent = text;
      return;
    }
    el.innerHTML = markChanges(prev, text);
  };
  /** Word-level diff (longest common subsequence): new words get <mark>. */
  function markChanges(a, b) {
    const A = a.split(/(\s+)/), B = b.split(/(\s+)/);
    const n = A.length, m = B.length, w = m + 1;
    if (n * m > 160000) return esc(b);
    const dp = new Uint16Array((n + 1) * w);
    for (let i = n - 1; i >= 0; i--)
      for (let j = m - 1; j >= 0; j--)
        dp[i * w + j] = A[i] === B[j] ? dp[(i + 1) * w + j + 1] + 1
                                      : Math.max(dp[(i + 1) * w + j], dp[i * w + j + 1]);
    let i = 0, j = 0, out = "";
    while (j < m) {
      if (i < n && A[i] === B[j]) { out += esc(B[j]); i++; j++; }
      else if (i < n && dp[(i + 1) * w + j] >= dp[i * w + j + 1]) i++;
      else { out += /^\s*$/.test(B[j]) ? esc(B[j]) : "<mark>" + esc(B[j]) + "</mark>"; j++; }
    }
    return out;
  }

  // ======================================================================
  // Reset
  // ======================================================================

  function doReset(alsoCustom) {
    state = DEFAULT_STATE();
    setPreset(0);
    if (alsoCustom) { custom = {}; saveCustom(); }
    save();
    fillPresets(); fillSelects(); paintRatios(); buildVars(); render();
    panel.querySelector(".psnap-body").scrollTo({ top: 0, behavior: smoothOK() ? "smooth" : "auto" });
    hint(alsoCustom ? T().hintResetAll : T().hintReset, true);
    const btn = $("#psnap-reset");
    btn.classList.add("psnap-spun");
    setTimeout(() => btn.classList.remove("psnap-spun"), 600);
  }

  // ======================================================================
  // Insert into composer
  // ======================================================================

  const findComposer = () =>
    document.querySelector("#prompt-textarea") ||
    document.querySelector('div[contenteditable="true"][id*="prompt"]') ||
    document.querySelector('form div[contenteditable="true"]') ||
    document.querySelector("form textarea");

  /** Copy text and report whether it worked. The Clipboard API can refuse
      (the page isn't focused, a permission is off), so fall back to the
      older copy command before giving up — and never claim "Copied" when
      nothing was copied. */
  function copyText(text) {
    const legacy = () => {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      let done = false;
      try { done = document.execCommand("copy"); } catch (_) {}
      ta.remove();
      return done;
    };
    try {
      return navigator.clipboard.writeText(text).then(() => true, () => legacy());
    } catch (_) {
      return Promise.resolve(legacy());
    }
  }

  function writeToComposer(text) {
    const box = findComposer();
    if (!box) return null;
    box.focus();
    if (box.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      setter.call(box, (box.value ? box.value + "\n\n" : "") + text);
      box.dispatchEvent(new Event("input", { bubbles:true }));
    } else {
      document.execCommand("insertText", false, text);
      box.dispatchEvent(new InputEvent("input", { bubbles:true }));
    }
    return box;
  }

  function insertPrompt() {
    const text = buildPrompt();
    if (!writeToComposer(text)) {
      copyText(text);
      hint(T().hintNoComposer, true);
      return;
    }
    hideBubble();
    hint(T().hintInserted, true);
    replay($("#psnap-insert"), "psnap-launch", 600);
  }

  const findSendButton = () =>
    document.querySelector('button[data-testid="send-button"]') ||
    document.querySelector('button[aria-label*="Send prompt" i]') ||
    document.querySelector('button[aria-label*="Send message" i]') ||
    document.querySelector('button[aria-label*="Send" i]') ||
    document.querySelector('form button[type="submit"]');

  function sendPrompt() {
    const text = buildPrompt();
    const box = writeToComposer(text);
    if (!box) {
      copyText(text);
      hint(T().hintNoComposer, true);
      soundError();
      return;
    }
    hideBubble();

    // let React register the new value before we fire the button
    setTimeout(() => {
      const btn = findSendButton();
      if (btn && !btn.disabled) {
        btn.click();
        armTracker();
        hint(T().hintSent, true);
        replay($("#psnap-send"), "psnap-launch", 750);
        return;
      }
      // fallback: synthesise Enter in the composer
      const ev = (type) => new KeyboardEvent(type, {
        key:"Enter", code:"Enter", keyCode:13, which:13, bubbles:true, cancelable:true
      });
      box.focus();
      box.dispatchEvent(ev("keydown"));
      box.dispatchEvent(ev("keypress"));
      box.dispatchEvent(ev("keyup"));

      setTimeout(() => {
        const stillThere = (box.value || box.textContent || "").includes(text.slice(0, 40));
        if (stillThere) { hint(T().hintSendFail, false); soundError(); }
        else { armTracker(); hint(T().hintSent, true); }
      }, 450);
    }, 140);
  }

  let hintTimer;
  const hintDefault = () => {
    const el = $("#psnap-hint");
    const changed = el.textContent !== T().hintDefault;
    el.classList.remove("psnap-note");
    el.textContent = T().hintDefault;
    if (changed && panel.classList.contains("psnap-shown")) freshen(el);
  };
  function hint(msg, good) {
    const el = $("#psnap-hint");
    el.textContent = msg;
    el.classList.toggle("psnap-note", !!good);
    freshen(el);
    clearTimeout(hintTimer);
    hintTimer = setTimeout(hintDefault, 4200);
  }

  // ======================================================================
  // "Need a Help?" bubble
  // ======================================================================

  let bubbleTimer;
  function showBubble() {
    if (panel.classList.contains("psnap-open")) return;
    const t = T();
    fabWrap.querySelector("#psnap-bubble-text").textContent =
      (window.innerWidth < 900 && t.needHelpShort) ? t.needHelpShort : t.needHelp;
    bubble.classList.add("psnap-bubble-show");
    fab.classList.add("psnap-nudge");
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(hideBubble, 9000);
  }
  function hideBubble() {
    bubble.classList.remove("psnap-bubble-show");
    fab.classList.remove("psnap-nudge");
    clearTimeout(bubbleTimer);
  }
  bubble.addEventListener("click", (e) => {
    if (e.target.id === "psnap-bubble-x") { e.stopPropagation(); hideBubble(); return; }
    hideBubble(); openPanel();
  });

  // ======================================================================
  // Generation tracker
  //
  // Only fires for IMAGE generation, never for plain text replies.
  // The rule: we do not commit to "this is an image job" until we have
  // seen hard evidence — ChatGPT's own % badge, or an image that shows up
  // inside an ASSISTANT message. Until then every image on the page
  // (including the one the user just uploaded, which renders instantly in
  // their own message bubble) is added to the ignore set every tick.
  // That upload is what used to make it shout "finished in 1s".
  // ======================================================================

  const origTitle = document.title.replace(/^[^\w\u1780-\u17FF]*\s*/, "");
  const SPIN = ["\u25F7","\u25F6","\u25F5","\u25F4"];

  let tracking = false;
  let isImageJob = false;      // committed only on real evidence
  let startedAt = 0, spinIx = 0, tickTimer = null;
  let pct = null, pctSeenAt = 0, everSawPct = false, endedAt = 0;
  let finishing = false;
  const pendingLoads = new WeakSet();
  // Capped so a very long conversation can't grow this without bound.
  const seenImages = new Set();
  const SEEN_MAX = 400;
  function rememberImage(k) {
    if (seenImages.size > SEEN_MAX) {
      // drop the oldest quarter
      const it = seenImages.values();
      for (let i = 0; i < SEEN_MAX / 4; i++) seenImages.delete(it.next().value);
    }
    seenImages.add(k);
  }

  /* Stable identity for an image. ChatGPT re-signs its image URLs and
     re-mounts the <img> when you come back to the tab, so the raw src of
     an OLD result can change. Keying on the raw src made the previous
     image look "new" and fired the finish screen for it. Key on the file
     id instead, falling back to the URL without its query string. */
  const imgKey = (img) => {
    const src = img.currentSrc || img.src || "";
    if (!src) return "";
    if (/^(blob|data):/i.test(src)) return src.slice(0, 300);
    const id = /file[-_][A-Za-z0-9]{6,}/.exec(src);
    if (id) return "id:" + id[0];
    try { const u = new URL(src, location.href); return u.origin + u.pathname; }
    catch (_) { return src.slice(0, 300); }
  };

  /* Every <img> element that was on the page when this job started.
     A finished job can never be one of these. */
  let preJobEls = new WeakSet();

  /* Is this image AFTER the latest message the user sent? A result for
     the current job always is; the previous job's image never is. */
  function afterLastUserTurn(img) {
    const users = document.querySelectorAll('[data-message-author-role="user"]');
    let last = users[users.length - 1];
    if (!last) return true;                  // no role markup: can't tell
    // compare against the END of the whole user turn, so an upload shown
    // above the text bubble still counts as part of it
    const turn = turnOf(last);
    if (turn && turnRole(turn) !== "assistant") last = turn;
    if (last.contains(img)) return false;
    return !!(last.compareDocumentPosition(img) & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  /* Hard gate used right before celebrating. */
  function isFreshResult(img) {
    if (!img || !img.isConnected) return false;
    if (preJobEls.has(img)) return false;
    if (jobKnownKeys.has(imgKey(img))) return false;
    if (inUserTurn(img) || !inAssistantTurn(img)) return false;
    // A finished result is shown large. Your upload is a small thumbnail.
    const r = img.getBoundingClientRect();
    if (r.width && r.width < 180) return false;
    return afterLastUserTurn(img);
  }
  let jobKnownKeys = new Set();              // keys present when the job began

  /* The element that holds the conversation. The thread has lived in
     <main> for a long time, but ChatGPT's layouts change: once a page has
     a second <main>, or none, "the first <main>" is the wrong place and
     every check here goes blind — no %, no finished image. So find the
     messages first and take the container they actually live in. */
  const MSG_SEL = '[data-message-author-role], [data-turn], [data-testid^="conversation-turn"]';
  let _rootCache = { at: 0, el: null };
  function chatRoot() {
    const now = Date.now();
    if (_rootCache.el && _rootCache.el.isConnected && now - _rootCache.at < 1000) return _rootCache.el;
    const msgs = document.querySelectorAll(MSG_SEL);
    const first = msgs[0], last = msgs[msgs.length - 1];
    let el = null;
    if (first) {
      el = first.closest("main");
      if (!el || !el.contains(last)) {
        // the smallest container holding every message
        el = first.parentElement;
        while (el && !el.contains(last)) el = el.parentElement;
      }
    }
    el = el || document.querySelector("main");
    _rootCache = { at: now, el };
    return el;
  }

  /** PromptSnap's own UI — its "%" labels must never read as ChatGPT's. */
  const ours = (el) => !!el.closest('[id^="psnap-"]');

  /** Inside the composer (the box you type in and its attachment strip).
      A <form> only counts when it holds no messages — if ChatGPT ever
      wraps the whole thread in one, everything would look like "yours". */
  function inComposer(el) {
    const box = el.closest('form, [data-testid*="composer" i]');
    return !!box && !box.querySelector(MSG_SEL);
  }

  /** Every image currently on the page becomes "already known". */
  let _imgCache = { at: 0, list: [] };
  function mainImages() {
    const now = Date.now();
    if (now - _imgCache.at < 200) return _imgCache.list;
    const root = chatRoot();
    _imgCache = { at: now, list: root ? [...root.querySelectorAll("img")].filter(i => !ours(i)) : [] };
    return _imgCache.list;
  }

  function markKnownImages(snapshot) {
    _imgCache.at = 0;
    for (const i of mainImages()) {
      // The "was already here" snapshot is only taken when you press
      // Send. Taking it later (e.g. when the tracker starts after you
      // switch back to the tab) could catch the NEW image mid-render.
      if (snapshot) preJobEls.add(i);
      const k = imgKey(i);
      if (!k) continue;
      rememberImage(k);
      if (snapshot) jobKnownKeys.add(k);
    }
  }

  /** Blacklist ONLY images that can never be a generated result — the
      user's own uploads and the composer attachment strip. Used while
      we're still deciding whether this is an image job, so a fast result
      doesn't get blacklisted before we commit. */
  function markUserImages() {
    try { noteUserImages(); } catch (_) {}
    for (const i of mainImages()) {
      const k = imgKey(i);
      if (!k) continue;
      if (inUserTurn(i) || /avatar|profile|icon|favicon/i.test(k)) seenImages.add(k);
    }
  }

  let _genCache = { at: 0, val: false };
  function isGenerating() {
    const now = Date.now();
    if (now - _genCache.at < 200) return _genCache.val;
    const v = !!(
      document.querySelector('button[data-testid="stop-button"]') ||
      document.querySelector('button[aria-label*="Stop" i]') ||
      document.querySelector('[data-testid*="generating" i]')
    );
    _genCache = { at: now, val: v };
    return v;
  }

  /** Is this node inside a message the USER wrote? */
  /* The whole turn an element belongs to. ChatGPT draws an image you
     upload ABOVE your message bubble, outside the element marked
     author-role="user" — so checking only that element let your own
     upload pass as a "new result" and fire the finish screen at 20%.
     Looking at the whole turn (the <article> / data-turn wrapper)
     catches it. */
  const TURN_SEL = 'article[data-turn], [data-turn], article[data-testid^="conversation-turn"], [data-testid^="conversation-turn"]';
  function turnOf(el) { return el.closest(TURN_SEL); }
  function turnRole(turn) {
    if (!turn) return "";
    const d = (turn.getAttribute("data-turn") || "").toLowerCase();
    if (d === "user" || d === "assistant") return d;
    const tid = (turn.getAttribute("data-testid") || "").toLowerCase();
    if (/user/.test(tid)) return "user";
    if (/assistant/.test(tid)) return "assistant";
    const u = turn.querySelector('[data-message-author-role="user"]');
    const a = turn.querySelector('[data-message-author-role="assistant"]');
    if (u && !a) return "user";
    if (a && !u) return "assistant";
    return "";
  }

  /* When ChatGPT doesn't wrap turns in a marked container, work out
     which message an image belongs to from the page structure: compare
     the nearest message marker BEFORE it and AFTER it, and pick the one
     it shares the closer parent with. Your upload sits right next to
     your own text (same small wrapper); a result sits next to ChatGPT's
     reply. Without this, an input photo above your message counted as
     part of ChatGPT's previous reply. */
  function depthOf(n) { let d = 0; while (n) { d++; n = n.parentNode; } return d; }
  function commonDepth(a, b) {
    const seen = new Set();
    for (let n = a; n; n = n.parentNode) seen.add(n);
    for (let n = b; n; n = n.parentNode) if (seen.has(n)) return depthOf(n);
    return 0;
  }
  function ownerRole(el) {
    const own = el.closest("[data-message-author-role]");
    if (own) return own.getAttribute("data-message-author-role");
    const marks = document.querySelectorAll("[data-message-author-role]");
    if (!marks.length) return "";
    let prev = null, next = null;
    for (const m of marks) {
      if (m.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) prev = m;
      else if (!next) next = m;
    }
    const dp = prev ? commonDepth(prev, el) : 0;
    const dn = next ? commonDepth(next, el) : 0;
    const pick = dn > dp ? next : prev;
    return pick ? pick.getAttribute("data-message-author-role") : "";
  }

  function inUserTurn(el) {
    if (el.closest('[data-message-author-role="user"]')
        || el.closest('[data-testid*="conversation-turn"][data-testid*="user"]')
        || inComposer(el)) return true;                    // composer attachment strip
    const tr = turnRole(turnOf(el));
    if (tr) return tr === "user";
    return ownerRole(el) === "user";
  }

  /** Does this page even use author-role markers? */
  function hasRoleMarkup() {
    return !!document.querySelector('[data-message-author-role]');
  }

  /** Is this node inside an assistant reply?
      If ChatGPT isn't using role markers on this view (image results are
      often rendered in their own container outside the message wrapper),
      we fall back to "anywhere in main that isn't the user's turn". */
  function inAssistantTurn(el) {
    if (el.closest('[data-message-author-role="assistant"]')) return true;
    if (inUserTurn(el)) return false;
    const role = turnRole(turnOf(el));
    if (role) return role === "assistant";
    const own = ownerRole(el);
    if (own) return own === "assistant";
    const root = chatRoot();
    return !!root && root.contains(el) && !ours(el);
  }

  /* ---- ChatGPT's live % badge ----------------------------------------
     A visible element in the conversation whose ENTIRE text is a number
     + %. A "50%" inside prose won't match. The number can arrive as one
     text node ("91%"), as two ("91" + "%" — how React renders {pct}%),
     or one element per digit for a rolling counter, so the test is on
     the element's whole text, not on single text nodes. Accessible
     progress bars (aria-valuenow, or aria-label="91%") count too. */
  /** ChatGPT's own words while an image is being made. */
  const IMG_STATUS_RE =
    /generating (a |an )?(more detailed )?image|creating (your |the |an )?image|adding (the )?final touches/i;

  let _pctEl = null;                 // last element that held the badge
  let _pctFullAt = 0;                // last whole-conversation sweep
  let _pctCache = { at: 0, val: null };

  const PCT_RE = /^(\d{1,3})%$/;
  function textPct(el) {
    const t = el.textContent || "";
    if (t.length > 24) return null;
    const m = PCT_RE.exec(t.replace(/\s+/g, ""));
    return m ? Number(m[1]) : null;
  }
  function ariaPct(el) {
    const lab = PCT_RE.exec((el.getAttribute("aria-label") || "").replace(/\s+/g, ""));
    if (lab) return Number(lab[1]);
    if (el.getAttribute("role") !== "progressbar" || !el.hasAttribute("aria-valuenow")) return null;
    const now = Number(el.getAttribute("aria-valuenow"));
    const min = Number(el.getAttribute("aria-valuemin") || 0);
    const max = Number(el.getAttribute("aria-valuemax") || 100);
    if (!isFinite(now) || !(max > min)) return null;
    return Math.round((now - min) / (max - min) * 100);
  }
  function pctBadgeOK(el, root) {
    if (ours(el) || inUserTurn(el)) return false;
    // with no clear container, only trust a badge that sits in a message
    if (root === document.body && !el.closest(MSG_SEL)) return false;
    const r = el.getBoundingClientRect();
    return !!(r.width || r.height);
  }

  function readPercentUncached() {
    // Fast path: the badge usually stays in the same element between
    // ticks, so check the one we already found before scanning again.
    if (_pctEl && _pctEl.isConnected) {
      const v = textPct(_pctEl) ?? ariaPct(_pctEl);
      if (v !== null && v >= 0 && v <= 100) return v;
      _pctEl = null;
    }

    const root = chatRoot();
    if (!root) return null;

    // ChatGPT draws the badge in the newest reply, so look there first —
    // on a long chat that's a small fraction of the page. The whole
    // conversation is still swept every few seconds as a fallback.
    const turns = root.querySelectorAll(TURN_SEL);
    let scopes = [root];
    const now = Date.now();
    if (turns.length > 2 && now - _pctFullAt < 4000) scopes = [turns[turns.length - 2], turns[turns.length - 1]];
    else _pctFullAt = now;

    // Walk text nodes instead of querySelectorAll on every div/span/p.
    // Far cheaper: we only touch short nodes that carry a "%", then climb
    // a few levels to the element whose whole text is "N%".
    let hit = null, hitV = null;     // the last match on the page wins
    let node, guard = 0;
    for (const scope of scopes) {
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const s = n.nodeValue;
        return s && s.length <= 6 && s.indexOf("%") !== -1
          ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    while ((node = walker.nextNode()) && ++guard < 600) {
      let el = node.parentElement;
      for (let up = 0; el && up < 4; up++, el = el.parentElement) {
        if ((el.textContent || "").length > 24) break;    // climbed into prose
        const v = textPct(el);
        if (v === null) continue;
        if (v <= 100 && pctBadgeOK(el, root)) { hit = el; hitV = v; }
        break;
      }
    }
    }

    if (!hit) {
      for (const el of root.querySelectorAll('[aria-label*="%"], [role="progressbar"][aria-valuenow]')) {
        const v = ariaPct(el);
        if (v === null || v < 0 || v > 100 || !pctBadgeOK(el, root)) continue;
        // a bare progress bar only counts beside ChatGPT's image wording —
        // replies can hold other bars (audio, research) unrelated to images
        const labelled = PCT_RE.test((el.getAttribute("aria-label") || "").replace(/\s+/g, ""));
        const msg = el.closest(MSG_SEL);
        if (!labelled && !(msg && IMG_STATUS_RE.test((msg.textContent || "").slice(0, 400)))) continue;
        hit = el; hitV = v;
      }
    }

    if (!hit) return null;
    _pctEl = hit;
    return hitV;
  }

  /** Cached wrapper — several call sites ask per tick; one scan is enough. */
  function readPercent() {
    const now = Date.now();
    if (now - _pctCache.at < 250) return _pctCache.val;
    const v = readPercentUncached();
    _pctCache = { at: now, val: v };
    return v;
  }

  /** Other hints that an image is being produced. */
  let _hintedImage = false;
  function imageJobHint() {
    if (readPercent() !== null) { _hintedImage = true; return true; }
    const main = chatRoot();
    if (!main) return false;
    if (main.querySelector('[data-testid*="image-gen" i], [class*="image-gen" i]')) return true;
    // the assistant's own status line, e.g. "Generating a more detailed image"
    // or, on the newer screen, "Adding final touches"
    const turns = main.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (last && IMG_STATUS_RE.test((last.textContent || "").slice(0, 400))) return true;
    return false;
  }

  /** A genuinely new, large image that is not the user's own upload. */
  function newAssistantImage() {
    for (const img of mainImages()) {
      const k = imgKey(img);
      if (!k || seenImages.has(k)) continue;
      if (inUserTurn(img))      { seenImages.add(k); continue; }
      if (!inAssistantTurn(img)) { seenImages.add(k); continue; }
      if (preJobEls.has(img) || !afterLastUserTurn(img)) { seenImages.add(k); continue; }
      if (/avatar|profile|icon|favicon|\.svg(\?|$)/i.test(k)) { seenImages.add(k); continue; }

      // Size check only once the image has actually decoded. An image that
      // hasn't loaded yet reports 0 — rejecting it there was making real
      // results get blacklisted before they ever had a size.
      if (img.complete && img.naturalWidth) {
        if (img.naturalWidth < 200) { seenImages.add(k); continue; }
        return img;
      }
      const r = img.getBoundingClientRect();
      if (r.width >= 150 || !img.complete) return img;
      seenImages.add(k);
    }
    return null;
  }

  /** Last resort: the largest image on the page that isn't the user's. */
  function bestVisibleImage() {
    let best = null, area = 0;
    for (const img of mainImages()) {
      if (inUserTurn(img)) continue;
      if (!isFreshResult(img)) continue;     // never the previous job's image
      const k = imgKey(img);
      if (/avatar|profile|icon|favicon/i.test(k)) continue;
      const r = img.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area) { area = a; best = img; }
    }
    return area > 22500 ? best : null;   // at least ~150x150
  }

  let armedAt = 0;
  let returnedAt = 0;          // last time this tab became visible / focused
  window.addEventListener("focus", () => { returnedAt = Date.now(); endedAt = 0; });
  const ARM_WINDOW = 5 * 60 * 1000;

  /** Called the moment we press Send, so we're listening early. */
  function armTracker() {
    armedAt = Date.now();
    _hintedImage = true;
    preJobEls = new WeakSet();
    jobKnownKeys = new Set();
    markKnownImages(true);
    setTimeout(() => markKnownImages(true), 300);   // catch the upload thumbnail too
    setTimeout(() => markKnownImages(true), 900);
  }

  const recentlyArmed = () => armedAt && (Date.now() - armedAt) < ARM_WINDOW;

  /** Safety net for when we never noticed the job starting. */
  function rescueCheck() {
    if (tracking || finishing || !recentlyArmed()) return;
    if (Date.now() - returnedAt < 2500) return;   // page is re-mounting
    const img = newAssistantImage();
    if (!img || !isFreshResult(img)) return;
    if (!(img.complete && img.naturalWidth >= 200)) return;
    // treat as a completed job that we simply never saw begin
    tracking = true;
    isImageJob = true;
    everSawPct = true;                 // bypass the fast-finish guard
    startedAt = startedAt || Date.now() - 2000;
    finishTracking(img);
  }

  let stallPct = null, stallAt = 0;
  function startTracking() {
    if (tracking) return;
    tracking = true;
    isImageJob = false;
    everSawPct = false;
    startedAt = Date.now();
    pct = null; pctSeenAt = 0; endedAt = 0; finishing = false; _hintedImage = false;
    stallPct = null; stallAt = Date.now();
    if (!recentlyArmed()) { preJobEls = new WeakSet(); jobKnownKeys = new Set(); }
    markKnownImages();
    tickTimer = setInterval(tick, 400);
    tick();
  }

  /** Switch from "something is happening" to "this is an image job". */
  function commitImageJob() {
    if (isImageJob) return;
    isImageJob = true;
    fab.classList.add("psnap-working");
    fab.classList.remove("psnap-done");
    hideBubble();
    setProgress(null);
    paintBar(null);
  }

  /* The ring's sweep is a registered <angle> property, so the browser can
     ease it from one reading to the next instead of jumping 20% → 35%.
     If registration isn't available the ring simply updates in steps. */
  let ringSmooth = false;
  try {
    CSS.registerProperty({ name: "--ps-deg", syntax: "<angle>", inherits: false, initialValue: "0deg" });
  } catch (_) {}   // already registered (the stylesheet's @property) or unsupported
  try {
    const ring = fabWrap.querySelector("#psnap-fab-ring");
    ringSmooth = getComputedStyle(ring).getPropertyValue("--ps-deg").trim() === "0deg";
    if (!ringSmooth) ring.classList.add("psnap-ring-snap");
  } catch (_) {}

  let pctShown = null, pctTarget = null, pctRaf = 0;
  /** The % shows on the button and on the progress card at once. */
  function writePct(lab, v) {
    lab.textContent = v + "%";
    if (job.state === "live") job.pct.textContent = v + "%";
  }
  /** Count the % label up to the new reading rather than flicking to it. */
  function countPct(lab, to) {
    if (to === pctTarget) return;
    cancelAnimationFrame(pctRaf);
    pctTarget = to;
    const from = pctShown;
    if (from === null || document.hidden || !smoothOK()) {
      pctShown = to; writePct(lab, to); return;
    }
    const t0 = performance.now(), dur = 650;
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur);
      const v = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3)));
      if (v !== pctShown) { pctShown = v; writePct(lab, v); }   // no rewrite for the same number
      if (k < 1) pctRaf = requestAnimationFrame(step);
    };
    pctRaf = requestAnimationFrame(step);
  }

  /** Turn the glowing tip to the new angle on the compositor, starting
      from wherever it is now, in step with the ring's sweep. */
  function moveTip(tip, deg, instant) {
    if (!tip) return;
    if (instant || !ringSmooth || !tip.animate || !smoothOK()) {
      if (tip._anim) { tip._anim.cancel(); tip._anim = null; }
      tip.style.rotate = deg;
      return;
    }
    const now = getComputedStyle(tip).rotate;              // mid-turn if it's still moving
    tip.style.rotate = deg;
    if (tip._anim) tip._anim.cancel();
    tip._anim = tip.animate([{ rotate: now === "none" ? "0deg" : now }, { rotate: deg }],
                            { duration: 600, easing: "cubic-bezier(.22,1,.36,1)" });
  }

  function setProgress(p) {
    const ring = fabWrap.querySelector("#psnap-fab-ring");
    const lab  = fabWrap.querySelector("#psnap-fab-pct");
    if (!ring || !lab) return;
    if (p === null || p === undefined) {
      fab.classList.remove("psnap-haspct");
      cancelAnimationFrame(pctRaf);
      if (pctTarget !== null) lab.textContent = pctTarget + "%";   // fade out on the real number
      pctShown = pctTarget = null;
      // the sweep is left where it was so the ring fades out full, not unwinding
    } else {
      const deg = Math.max(0, Math.min(100, p)) * 3.6 + "deg";
      const tip = fabWrap.querySelector("#psnap-fab-tip");
      // the ring warms from amber to green as the job nears the end
      ring.style.setProperty("--ps-ring", pctColor(p));
      if (tip) tip.style.setProperty("--ps-ring", pctColor(p));
      if (!fab.classList.contains("psnap-haspct")) {
        // a fresh ring starts at the current reading, not swept up from 0
        ring.classList.add("psnap-ring-snap");
        ring.style.setProperty("--ps-deg", deg);
        void ring.offsetWidth;
        if (ringSmooth) ring.classList.remove("psnap-ring-snap");
        moveTip(tip, deg, true);
        writePct(lab, p);
        pctShown = pctTarget = p;
      } else {
        if (ring.style.getPropertyValue("--ps-deg") !== deg) {
          ring.style.setProperty("--ps-deg", deg);
          moveTip(tip, deg, false);
        }
        countPct(lab, p);
      }
      fab.classList.add("psnap-haspct");
    }
  }

  // ======================================================================
  // Live generation view — progress card, time left, tab icon, hover chip
  // ======================================================================

  /** Write text only when it differs — same-value writes still cost a relayout. */
  const setText = (el, v) => { if (el.textContent !== v) el.textContent = v; };

  const clockOf = (secs) => {
    const s = Math.max(0, Math.round(secs));
    return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
  };

  /** Amber at the start, green at the finish line. */
  const pctColor = (p, l = 62) =>
    `hsl(${(38 + 116 * Math.max(0, Math.min(100, p)) / 100).toFixed(0)} 88% ${l}%)`;

  /* ---- time left ----------------------------------------------------
     ChatGPT's % doesn't climb at a steady rate, so the live rate alone
     swings about. Blend it with how long your recent jobs took (the last
     12, kept on this computer), trust the live rate more as the % climbs,
     and smooth what's shown so it counts down instead of jumping. */
  const jobTimes = [];
  try {
    chrome.storage.local.get("psnapJobTimes", (r) => {
      const a = r && r.psnapJobTimes;
      if (Array.isArray(a)) jobTimes.push(...a.filter(n => n > 3 && n < 900).slice(-12));
    });
  } catch (_) {}
  function rememberJobTime(secs) {
    if (!(secs > 3 && secs < 900)) return;
    jobTimes.push(secs);
    while (jobTimes.length > 12) jobTimes.shift();
    persist({ psnapJobTimes: jobTimes.slice() });
  }
  function typicalJob() {
    if (!jobTimes.length) return null;
    const s = [...jobTimes].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)];
  }
  let etaSmooth = null;
  function timeLeft(p, elapsedMs) {
    const e = elapsedMs / 1000, typ = typicalJob();
    const live = (p !== null && p >= 6 && e >= 3) ? e * (100 - p) / p : null;
    if (live === null) { etaSmooth = null; return null; }
    const est = Math.max(0, typ ? Math.min(1, p / 50) * live + (1 - Math.min(1, p / 50)) * Math.max(typ - e, 0)
                                : live);
    etaSmooth = etaSmooth === null ? est : etaSmooth + (est - etaSmooth) * 0.25;
    return etaSmooth;
  }

  /* ---- ChatGPT's own stage words ("Sketching it out", "Adding final
     touches") — the short line that sits with the % badge. Falls back to
     the image wording in the reply, then to a plain "Generating image". */
  let _stage = { at: 0, text: "" };
  function readStage() {
    const now = Date.now();
    if (now - _stage.at < 600) return _stage.text;
    let text = "";
    try {
      const badge = _pctEl && _pctEl.isConnected ? _pctEl : null;
      let box = badge && badge.parentElement;
      for (let up = 0; box && up < 5 && !text; up++, box = box.parentElement) {
        if ((box.textContent || "").length > 400) break;
        const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT);
        for (let n; (n = w.nextNode()); ) {
          const s = (n.nodeValue || "").trim();
          if (s.length < 4 || s.length > 40 || /[\d%:]/.test(s) || !/\p{L}{3}/u.test(s)) continue;
          const el = n.parentElement;
          if (!el || ours(el) || inUserTurn(el) || el.closest("button, a, [role='button']")) continue;
          if (!(el.compareDocumentPosition(badge) & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 4 || r.height < 4) continue;          // screen-reader-only text
          text = s;                                              // nearest line before the badge
        }
      }
      if (!text) {
        const m = IMG_STATUS_RE.exec(lastAssistantText().slice(0, 400));
        if (m) text = m[0].charAt(0).toUpperCase() + m[0].slice(1);
      }
    } catch (_) {}
    _stage = { at: now, text };
    return text;
  }

  /* ---- the browser tab's icon becomes a small progress ring, so you can
     follow the job from any other tab; a green tick when it's ready, and
     ChatGPT's own icon comes back once you've seen it. */
  const tabIcon = (() => {
    const saved = new Map();              // <link> → [href, type] it had before
    let shown = "";
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    function draw(p, done) {
      const g = c.getContext("2d");
      g.clearRect(0, 0, 64, 64);
      g.beginPath(); g.arc(32, 32, 31, 0, Math.PI * 2);
      g.fillStyle = done ? "#14c294" : "#1d1f22"; g.fill();
      g.lineCap = "round"; g.lineJoin = "round";
      if (done) {
        g.strokeStyle = "#fff"; g.lineWidth = 7;
        g.beginPath(); g.moveTo(18, 33); g.lineTo(28, 43); g.lineTo(47, 22); g.stroke();
      } else {
        const a0 = -Math.PI / 2;
        g.lineWidth = 9; g.strokeStyle = "rgba(255,255,255,.2)";
        g.beginPath(); g.arc(32, 32, 22, 0, Math.PI * 2); g.stroke();
        g.strokeStyle = pctColor(p === null ? 0 : p, 60);
        g.beginPath();
        g.arc(32, 32, 22, a0, a0 + Math.PI * 2 * (p === null ? 0.18 : Math.max(0.02, Math.min(100, p) / 100)));
        g.stroke();
      }
      return c.toDataURL("image/png");
    }
    function set(p, done) {
      const key = done ? "done" : (p === null ? "wait" : String(p));
      if (key === shown) return;
      shown = key;
      try {
        const url = draw(p, done);
        let links = [...document.querySelectorAll('link[rel~="icon"]')];
        if (!links.length) {
          const l = document.createElement("link");
          l.rel = "icon"; l.dataset.psnap = "1";
          (document.head || document.documentElement).appendChild(l);
          links = [l];
        }
        for (const l of links) {
          if (!saved.has(l)) saved.set(l, [l.getAttribute("href"), l.getAttribute("type")]);
          l.type = "image/png";
          l.href = url;
        }
      } catch (_) {}
    }
    function restore() {
      if (!shown) return;
      shown = "";
      for (const [l, [href, type]] of saved) {
        if (l.dataset.psnap) { l.remove(); continue; }
        if (href === null) l.removeAttribute("href"); else l.setAttribute("href", href);
        if (type === null) l.removeAttribute("type"); else l.setAttribute("type", type);
      }
      saved.clear();
    }
    return { set, restore };
  })();

  /* ---- the progress card at the top of the panel ------------------- */
  const job = {
    el: $("#psnap-job"), art: $("#psnap-job-art"), stage: $("#psnap-job-stage"),
    pct: $("#psnap-job-pct"), track: $("#psnap-job-track"), time: $("#psnap-job-time"),
    eta: $("#psnap-job-eta"), view: $("#psnap-job-view"),
    state: "off",                  // off | live | done
    p: null, stalled: false, hideT: 0
  };
  const chipPct  = fabWrap.querySelector("#psnap-chip-pct");
  const chipText = fabWrap.querySelector("#psnap-chip-text");

  job.view.addEventListener("click", () => jumpToLastImage());

  /* The "developing" picture: a 7×7 dot grid, a nod to ChatGPT's own
     dotted placeholder. Each dot has its own threshold, ordered from the
     middle outwards with a little randomness, so the grid fills in like a
     print coming up as the % climbs; a soft sheen keeps passing over it
     so you can see it's alive even when the % pauses. */
  const ART_N = 7, ART_SIZE = 40;
  const artDots = (() => {
    const dots = [], mid = (ART_N - 1) / 2;
    for (let y = 0; y < ART_N; y++) for (let x = 0; x < ART_N; x++)
      dots.push({ x, y, k: Math.hypot(x - mid, y - mid) / 4.25 + Math.random() * 0.45, a: 0 });
    dots.sort((a, b) => a.k - b.k).forEach((d, i) => { d.th = (i + 1) / dots.length * 100; });
    return dots;
  })();
  let artRaf = 0, artLast = 0, artKey = "", artSettled = false;
  /** Ask for a redraw — skipped when the picture already shows this state. */
  const artKick = () => {
    const key = job.state + "|" + job.p + "|" + panel.classList.contains("psnap-light");
    if (key === artKey && artSettled) return;
    artKey = key;
    if (!artRaf) artRaf = requestAnimationFrame(artFrame);
  };
  /* Redrawn only while dots are fading in after a change — the passing
     sheen is a GPU layer in the stylesheet, so a steady job costs no
     canvas work at all. */
  function artFrame(now) {
    artRaf = 0;
    const cv = job.art;
    if (!cv || job.state === "off") { artLast = 0; return; }
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (cv.width !== ART_SIZE * dpr) cv.width = cv.height = ART_SIZE * dpr;
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, ART_SIZE, ART_SIZE);

    const moving = smoothOK();
    const dt = artLast ? Math.min(120, now - artLast) : 16;
    artLast = now;
    const done = job.state === "done";
    const p = done ? 100 : (job.p === null ? 0 : job.p);
    const dim = panel.classList.contains("psnap-light") ? "rgba(0,0,0,.13)" : "rgba(255,255,255,.13)";
    const lit = done ? "#14c294" : pctColor(p);
    const step = ART_SIZE / ART_N;
    let settling = false;

    for (const d of artDots) {
      const target = p >= d.th ? 1 : 0;
      d.a = moving ? d.a + (target - d.a) * Math.min(1, dt / 240) : target;
      if (Math.abs(target - d.a) > 0.01) settling = true; else d.a = target;
      const cx = d.x * step + step / 2, cy = d.y * step + step / 2;
      g.globalAlpha = 1;
      g.fillStyle = dim;
      g.beginPath(); g.arc(cx, cy, step * 0.2, 0, Math.PI * 2); g.fill();
      if (d.a > 0.01) {
        g.globalAlpha = Math.min(1, d.a * 0.95);
        g.fillStyle = lit;
        g.beginPath(); g.arc(cx, cy, step * (0.2 + 0.08 * d.a), 0, Math.PI * 2); g.fill();
      }
    }
    g.globalAlpha = 1;
    const visible = panel.classList.contains("psnap-shown") && !document.hidden;
    artSettled = !settling;
    if (moving && visible && settling) artRaf = requestAnimationFrame(artFrame);
    else artLast = 0;
  }

  function jobShow() {
    if (!panel.classList.contains("psnap-shown")) { job.el.hidden = false; return; }
    if (!slideOpen(job.el)) slide(job.el, true);
  }
  function jobBegin() {
    clearTimeout(job.hideT);
    job.state = "live"; job.p = null; job.stalled = false; etaSmooth = null;
    job.el.classList.remove("psnap-job-done", "psnap-job-stalled");
    job.view.hidden = true;
    job.pct.textContent = "";
    job.track.classList.add("psnap-job-indet");
    job.track.style.setProperty("--ps-p", 0);
    artDots.forEach(d => { d.a = 0; });
    artSettled = false;
    fabWrap.classList.add("psnap-job-live");
    jobShow();
    artKick();
  }

  /** Called on every tracker tick. Returns the time-left text for the tab title. */
  function jobUpdate(p, elapsedMs, stalled) {
    if (job.state !== "live") jobBegin();
    const t = T();
    job.p = p; job.stalled = stalled;
    const stage = readStage() || t.jobMaking;
    if (job.stage.textContent !== stage) { job.stage.textContent = stage; freshen(job.stage); }
    setText(job.time, clockOf(elapsedMs / 1000));

    const left = timeLeft(p, elapsedMs), typ = typicalJob();
    let eta = "", tabEta = "";
    if (stalled) eta = t.jobStill;
    else if (p !== null && (p >= 97 || (left !== null && left < 1.5))) eta = tabEta = t.jobAlmost;
    else if (left !== null) eta = tabEta = t.jobLeft(clockOf(left));
    else if (typ && elapsedMs / 1000 < typ) eta = t.jobUsually(clockOf(typ));
    setText(job.eta, eta);
    job.el.classList.toggle("psnap-job-stalled", stalled);

    if (p === null) {
      job.track.classList.add("psnap-job-indet");
      job.pct.textContent = "";
    } else {
      job.track.classList.remove("psnap-job-indet");
      if (job.track.style.getPropertyValue("--ps-p") !== String(p / 100)) {
        job.track.style.setProperty("--ps-p", p / 100);
        job.track.style.setProperty("--ps-ring", pctColor(p));
      }
    }
    artKick();

    setText(chipPct, p === null ? "" : p + "%");
    if (p !== null) chipPct.style.color = pctColor(p);
    setText(chipText, [stage, eta].filter(Boolean).join(" · "));
    tabIcon.set(p, false);
    return tabEta;
  }

  function jobDone(secs) {
    const t = T();
    if (job.state === "off") jobBegin();
    job.state = "done"; job.p = 100; job.stalled = false;
    job.el.classList.remove("psnap-job-stalled");
    job.el.classList.add("psnap-job-done");
    job.stage.textContent = t.imageReady;
    freshen(job.stage);
    job.pct.textContent = "";
    job.time.textContent = t.jobDoneIn(clockOf(secs));
    job.eta.textContent = "";
    job.track.classList.remove("psnap-job-indet");
    job.track.style.setProperty("--ps-p", 1);
    job.view.textContent = t.jobView;
    job.view.title = t.jobViewTip;
    job.view.hidden = false;
    fabWrap.classList.remove("psnap-job-live");
    artKick();
    tabIcon.set(100, true);
    clearTimeout(job.hideT);
    job.hideT = setTimeout(jobClear, 12000);
  }

  /** Fold the card away and give the tab its icon back. After a finish,
      if you're in another tab, both wait until you come back to look. */
  function jobClear(force) {
    clearTimeout(job.hideT);
    if (!force && job.state !== "done") return;
    if (!force && document.hidden) {
      const back = () => {
        if (document.hidden) return;
        document.removeEventListener("visibilitychange", back);
        if (job.state === "done") job.hideT = setTimeout(jobClear, 4000);
      };
      document.addEventListener("visibilitychange", back);
      return;
    }
    job.state = "off";
    fabWrap.classList.remove("psnap-job-live");
    if (slideOpen(job.el)) {
      if (panel.classList.contains("psnap-shown")) slide(job.el, false); else job.el.hidden = true;
    }
    tabIcon.restore();
  }

  function tick() {
    const t = T();
    const elapsed = Date.now() - startedAt;

    const read = readPercent();
    if (read !== null) {
      if (pct === null || read >= pct || read === 0) pct = read;
      pctSeenAt = Date.now();
      everSawPct = true;
      commitImageJob();
    } else if (pct !== null && Date.now() - pctSeenAt > 4000) {
      pct = null;
    }

    if (!isImageJob) {
      markUserImages();
      // a large new image showing up on its own is evidence enough
      if (imageJobHint() || newAssistantImage()) commitImageJob();
      if (!isGenerating() && elapsed > 2500) {
        if (_hintedImage) checkRefusal();
        standDown();
      }
      return;
    }

    // ---- completion check, run every tick -----------------------------
    // The MutationObserver can go quiet once the image finishes painting,
    // which used to leave the tracker spinning forever. Polling here means
    // we always notice.
    const fresh = newAssistantImage();
    if (fresh) {
      if (fresh.complete && fresh.naturalWidth) { finishTracking(fresh); return; }
      if (!pendingLoads.has(fresh)) {
        pendingLoads.add(fresh);
        fresh.addEventListener("load",  () => finishTracking(fresh), { once:true });
        fresh.addEventListener("error", () => { seenImages.add(imgKey(fresh)); }, { once:true });
      }
    }

    // ---- watchdog -----------------------------------------------------
    // Generation has clearly stopped: no stop button, no % badge.
    // Coming back to the tab makes ChatGPT re-render the thread; for a
    // moment the stop button and % badge can be missing. Don't read that
    // as "finished".
    const settling = Date.now() - returnedAt < 3000;
    const quiet = !settling && !isGenerating() && read === null && !stillCreating();
    if (quiet) {
      if (!endedAt) endedAt = Date.now();
      const since = Date.now() - endedAt;

      // give the image a moment to appear, then settle it one way or another
      if (since > 1800) {
        const candidate = fresh || bestVisibleImage();
        if (candidate && (everSawPct || elapsed > 4000)) {
          finishTracking(candidate);
        } else if (checkRefusal()) {
          standDown();
        } else if (since > 6000) {
          standDown();
        }
        return;
      }
    } else {
      endedAt = 0;
    }

    // hard ceiling so it can never spin forever
    if (elapsed > 300000) { standDown(); return; }

    const s = Math.floor(elapsed / 1000);
    const clock = `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
    const st = $("#psnap-status");

    setProgress(pct);

    // "stalled" = the % hasn't moved for a while (ChatGPT sometimes pauses)
    if (pct !== stallPct) { stallPct = pct; stallAt = Date.now(); }
    const stalled = pct !== null && pct < 97 && Date.now() - stallAt > 15000;
    fab.classList.toggle("psnap-stalled", stalled);
    const left = jobUpdate(pct, elapsed, stalled);

    if (pct !== null) {
      const title = `${pct}%${left ? " · " + left : ""} — ${t.tabGenerating} | ${origTitle}`;
      if (document.title !== title) document.title = title;
      if (st) {
        const html = `<span class="psnap-pctnum">${pct}%</span> <span class="psnap-clock">${clock}</span>`;
        if (st._html !== html) { st._html = html; st.innerHTML = html; }
        if (st.className !== "psnap-working-badge psnap-clickable") st.className = "psnap-working-badge psnap-clickable";
      }
      paintBar(pct);
    } else {
      spinIx = (spinIx + 1) % SPIN.length;
      const phase = elapsed < 4000 ? t.starting : t.rendering;
      document.title = `${SPIN[spinIx]} ${clock} — ${phase} | ${origTitle}`;
      if (st) {
        const html = `${SPIN[spinIx]} <span class="psnap-clock">${clock}</span>`;
        if (st._html !== html) { st._html = html; st.innerHTML = html; }
        if (st.className !== "psnap-working-badge psnap-clickable") st.className = "psnap-working-badge psnap-clickable";
      }
      paintBar(null);
    }
  }

  /** ChatGPT's own "Creating image" placeholder is still on screen. */
  function stillCreating() {
    const main = chatRoot();
    if (!main) return false;
    const turns = main.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (!last) return false;
    return IMG_STATUS_RE.test((last.textContent || "").slice(0, 300));
  }

  /** Did the assistant refuse? Called when a job ends with no image. */
  function checkRefusal() {
    if (!isImageJob && !everSawPct) return false;   // wasn't an image job
    const txt = lastAssistantText();
    if (!looksRefused(txt)) return false;
    // pull the sentence that matched, for the alert body
    const sent = (txt.split(/(?<=[.!?])\s+/).filter(x => looksRefused(x))[0] || "").trim();
    showBlocked(sent.length > 12 && sent.length < 220 ? sent : "");
    return true;
  }

  /** Quietly reset — no sound, no toast, no celebration. */
  function standDown() {
    stopTicker();
    endedAt = 0;
    finishing = false;
    isImageJob = false;
    document.title = origTitle;
    fab.classList.remove("psnap-working", "psnap-haspct", "psnap-stalled");
    setProgress(null);
    clearBar(false);
    // a finished image keeps its "ready" card and tab tick for their full
    // time — only a job that never finished is folded away here
    if (job.state === "live") jobClear(true);
    const st = $("#psnap-status");
    if (st) { st.className = ""; st.textContent = ""; st._html = ""; }
  }

  function stopTicker() { tracking = false; clearInterval(tickTimer); }

  function paintBar(p) {
    let bar = panel.querySelector("#psnap-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "psnap-bar";
      bar.innerHTML = "<i></i>";
      panel.insertBefore(bar, panel.firstChild);
    }
    // the fill is scaled (--ps-p, 0–1) rather than resized, so it glides on
    // the compositor even while ChatGPT keeps the main thread busy
    const fill = bar.firstElementChild;
    bar.classList.remove("psnap-bar-done");
    if (p === null) {
      bar.classList.add("psnap-bar-on", "psnap-bar-indet");
    } else {
      bar.classList.add("psnap-bar-on");
      bar.classList.remove("psnap-bar-indet");
      fill.style.setProperty("--ps-p", Math.max(0, Math.min(100, p)) / 100);
    }
  }
  function clearBar(done) {
    const bar = panel.querySelector("#psnap-bar");
    if (!bar) return;
    bar.classList.remove("psnap-bar-indet");
    if (done) {
      bar.firstElementChild.style.setProperty("--ps-p", 1);
      bar.classList.add("psnap-bar-done");
      // fade out still green, then reset quietly once it's invisible
      setTimeout(() => {
        bar.classList.remove("psnap-bar-on");
        setTimeout(() => {
          if (bar.classList.contains("psnap-bar-on")) return;   // a new job took over
          bar.classList.remove("psnap-bar-done");
          bar.firstElementChild.style.setProperty("--ps-p", 0);
        }, 340);
      }, 900);
    } else {
      bar.classList.remove("psnap-bar-on");
      bar.firstElementChild.style.setProperty("--ps-p", 0);
    }
  }

  function finishTracking(img) {
    // guards: must be a committed image job, and not suspiciously instant
    if (finishing) return;
    if (!tracking || !isImageJob) return;
    // Never celebrate an image that was already there before this job,
    // or one that belongs to your own message.
    if (img && !isFreshResult(img)) { seenImages.add(imgKey(img)); return; }
    // ChatGPT is still showing its own progress (e.g. 20%) — whatever
    // image we're looking at, the result isn't finished yet.
    const livePct = readPercent();
    if (livePct !== null && livePct < 95) return;
    const elapsed = Date.now() - startedAt;
    if (elapsed < 1500 && !everSawPct) return;
    finishing = true;
    endedAt = 0;

    const secs = Math.max(1, Math.round(elapsed / 1000));

    setProgress(100);
    paintBar(100);
    stopTicker();
    isImageJob = false;

    setTimeout(() => {
      fab.classList.remove("psnap-working", "psnap-haspct", "psnap-stalled");
      setProgress(null);
      fab.classList.add("psnap-done", "psnap-fab-checked");
      setTimeout(() => fab.classList.remove("psnap-fab-checked"), 2600);
      clearBar(true);
    }, 420);
    rememberJobTime(secs);
    jobDone(secs);

    const st = $("#psnap-status");
    if (st) { st.className = "psnap-done-badge"; st.textContent = T().ready; st._html = ""; }

    document.title = `\u2705 ${T().tabReady} | ${origTitle}`;
    setTimeout(() => { if (!tracking) document.title = origTitle; }, 12000);

    canvaSending = false;
    if (img) { lastImageUrl = img.currentSrc || img.src || ""; lastResultEl = img; }
    _imgCache.at = 0;
    // fall back to a live scan if the capture came up empty
    if (!lastImageUrl) currentImageUrl();
    // Refresh the list quietly. The drawer stays however you left it —
    // it only opens when you click it.
    refreshCanvaTabs();

    celebrate(secs, img);
    setTimeout(() => fab.classList.remove("psnap-done"), 7000);
  }

  // ----------------------------------------------------------------------
  // Celebration
  // ----------------------------------------------------------------------

  function celebrate(secs, img) {
    if (celebration === "off") { chime(); if (img) flashImage(img); return; }

    if (celebration === "classic") {
      showToast(secs);
      burst();
      chime();
      if (document.hidden) notify(secs);
      if (img) flashImage(img);
      return;
    }

    // with animation off, use the quiet toast instead of the overlay
    if (animLevel() === 0) { showToast(secs); chimeBig(); notify(secs); return; }

    // full screen — fall back to the toast if anything goes wrong so a
    // finished job is never completely silent
    let ok = false;
    try { ok = fullScreenCelebration(secs, img); } catch(_) { ok = false; }
    if (!ok) showToast(secs);
    chimeBig();
    notify(secs);
    if (img) flashImage(img);
  }

  function showToast(secs) {
    const t = T();
    document.getElementById("psnap-toast-title").textContent = t.imageReady;
    document.getElementById("psnap-toast-sub").textContent = secs ? t.finishedIn(secs) : t.jumpToIt;
    toast.classList.add("psnap-toast-show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove("psnap-toast-show"), 8000);
  }

  toast.addEventListener("click", () => {
    toast.classList.remove("psnap-toast-show");
    jumpToLastImage();
  });

  function jumpToLastImage() {
    const imgs = mainImages()
      .filter(i => (i.naturalWidth || 0) >= 220 && inAssistantTurn(i));
    imgs[imgs.length - 1]?.scrollIntoView({ behavior:"smooth", block:"center" });
  }

  function flashImage(img) {
    const holder = img.closest("div") || img;
    holder.classList.add("psnap-flash");
    setTimeout(() => holder.classList.remove("psnap-flash"), 2800);
    if (document.visibilityState === "visible") img.scrollIntoView({ behavior:"smooth", block:"center" });
  }

  /** Full-viewport finish sequence. */
  function fullScreenCelebration(secs, img) {
    if (!document.body) return false;
    const t = T();
    const old = document.getElementById("psnap-cel");
    if (old) old.remove();

    const src = img ? (img.currentSrc || img.src || "") : "";
    const el = document.createElement("div");
    el.id = "psnap-cel";
    el.className = "psnap-ui psnap-cel" + (theme === "light" ? " psnap-cel-light" : "");
    el.innerHTML = `
      <div class="psnap-cel-glow"></div>
      <div class="psnap-cel-rings"><i></i><i></i><i></i></div>
      <div class="psnap-cel-card">
        ${src ? `<div class="psnap-cel-thumb"><img src="${src.replace(/"/g,"&quot;")}" alt=""></div>` : ""}
        <div class="psnap-cel-check">
          <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 15-16"/></svg>
        </div>
        <div class="psnap-cel-title">${esc(t.celTitle)}</div>
        <div class="psnap-cel-sub">${esc(t.celSub(secs))}</div>
        <div class="psnap-cel-hint">${esc(t.celDismiss)}</div>
      </div>
      <div class="psnap-cel-confetti"></div>
    `;
    document.body.appendChild(el);

    // confetti — built when the show actually starts, so it never rains
    // unseen in a background tab. Each piece falls, spins, and flips on
    // its own clock (see psnap-confetti-fall / -flip) so it flutters.
    const spawnConfetti = () => {
      const wrap = el.querySelector(".psnap-cel-confetti");
      const colors = ["#14c294","#7ee8c6","#ffd479","#ff9f6e","#8bd3ff","#ffffff"];
      const count = { 3:70, 2:34, 1:14, 0:0 }[animLevel()];
      const frag = document.createDocumentFragment();
      for (let i = 0; i < count; i++) {
        const p = document.createElement("i");
        p.style.left = Math.random() * 100 + "%";
        p.style.background = colors[i % colors.length];
        p.style.animationDelay = (Math.random() * 0.7).toFixed(2) + "s";
        p.style.animationDuration = (2.2 + Math.random() * 1.6).toFixed(2) + "s, "
                                  + (0.6 + Math.random() * 0.9).toFixed(2) + "s";
        p.style.setProperty("--spin", (Math.random() * 720 - 360).toFixed(0) + "deg");
        p.style.setProperty("--drift", (Math.random() * 160 - 80).toFixed(0) + "px");
        const sz = 6 + Math.random() * 7;
        p.style.width = sz + "px";
        p.style.height = (sz * (Math.random() > .5 ? 1 : 0.45)) + "px";
        if (Math.random() > .6) p.style.borderRadius = "50%";
        frag.appendChild(p);
      }
      wrap.appendChild(frag);
    };

    // "Send to Canva" appears on the card once a design tab is open
    const acts = el.querySelector("#psnap-cel-acts");
    if (acts && currentImageUrl()) {
      refreshCanvaTabs(() => {
        if (!canvaTabs.length || !document.body.contains(el)) return;
        acts.innerHTML =
          `<button class="psnap-cel-btn" id="psnap-cel-canva">
             <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
               <path d="M5 12h13M13 6l6 6-6 6"/></svg>
             <span>${esc(t.sendToCanva)}</span>
           </button>`;
        acts.classList.add("psnap-cel-acts-in");
        acts.querySelector("#psnap-cel-canva").onclick = (ev) => {
          ev.stopPropagation();
          const b = ev.currentTarget;
          const lbl = b.querySelector("span");
          const target = canvaTabs.find(tb => tb.id === canvaPick) || canvaTabs[0];
          const imgUrl = currentImageUrl();
          if (!imgUrl || !canvaSendGuard(target.id, imgUrl)) return;
          b.disabled = true;
          lbl.textContent = t.sending;
          deliverToCanva(target.id, latestResultImage(), imgUrl).then((res) => {
            canvaSendDone();
            if (res && res.ok) { lbl.textContent = t.sentToCanva; soundSuccess(); }
            else { lbl.textContent = t.canvaFail; soundError(); b.disabled = false; }
          }, () => {
            canvaSendDone(); lbl.textContent = t.canvaFail; soundError(); b.disabled = false;
          });
        };
      });
    }

    // If the job finished while you were in another tab, hold the show
    // until you come back so you actually see it, instead of returning to
    // the last frame. No rAF involved — it doesn't run in background tabs.
    let started = false, closed = false;
    const begin = () => {
      if (started || closed || document.hidden || !document.body.contains(el)) return;
      started = true;
      spawnConfetti();
      playIn(el, "psnap-cel-in");
    };

    // "-in" stays on while closing so the card fades out from where it
    // landed instead of snapping back to its starting pose
    const close = () => {
      if (closed) return;
      closed = true;
      el.dispatchEvent(new CustomEvent("psnap-closed"));
      el.classList.add("psnap-cel-out");
      setTimeout(() => el.remove(), 420);
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    document.addEventListener("keydown", onKey, true);
    el.addEventListener("click", (e) => {
      if (e.target.closest(".psnap-cel-thumb")) { close(); jumpToLastImage(); return; }
      close();
    });
    // Auto-dismiss only counts time while the tab is actually visible.
    let autoTimer = null;
    const startAutoClose = () => {
      clearTimeout(autoTimer);
      autoTimer = setTimeout(() => {
        if (el.querySelector("#psnap-cel-canva")) return;   // a send is on offer
        if (document.body.contains(el)) close();
      }, 6000);
    };
    const onVis = () => {
      if (document.hidden) { clearTimeout(autoTimer); }
      else { begin(); startAutoClose(); }
    };
    document.addEventListener("visibilitychange", onVis);
    el.addEventListener("psnap-closed", () => {
      clearTimeout(autoTimer);
      document.removeEventListener("visibilitychange", onVis);
    });
    begin();
    if (!document.hidden) startAutoClose();
    return true;
  }

  /** Small particle burst from the floating button (classic mode). */
  function burst() {
    const r = fab.getBoundingClientRect();
    const colors = ["#14c294","#7ee8c6","#ffd479","#ffffff","#0d8e6f"];
    const layer = document.createElement("div");
    layer.className = "psnap-ui psnap-burst";
    const n = { 3:16, 2:9, 1:5, 0:0 }[animLevel()];
    if (!n) return;
    for (let i = 0; i < n; i++) {
      const p = document.createElement("i");
      const ang = (Math.PI * 2 * i) / n + Math.random() * 0.4;
      const dist = 46 + Math.random() * 46;
      p.style.setProperty("--dx", Math.cos(ang) * dist + "px");
      p.style.setProperty("--dy", Math.sin(ang) * dist + "px");
      p.style.background = colors[i % colors.length];
      p.style.animationDelay = (Math.random() * 90) + "ms";
      if (i % 3 === 0) p.style.borderRadius = "2px";
      layer.appendChild(p);
    }
    layer.style.left = (r.left + r.width/2) + "px";
    layer.style.top  = (r.top + r.height/2) + "px";
    document.body.appendChild(layer);
    setTimeout(() => layer.remove(), 1400);
  }

  // ----------------------------------------------------------------------
  // Sound
  // ----------------------------------------------------------------------

  // One shared context, resumed on demand. Creating a fresh one per
  // chime meant Chrome sometimes handed back a suspended context that
  // played nothing at all, silently.
  let _ctx = null;
  function audioCtx() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!_ctx || _ctx.state === "closed") _ctx = new Ctx();
    if (_ctx.state === "suspended") _ctx.resume().catch(() => {});
    return _ctx;
  }

  // Unlock audio on the first interaction anywhere on the page.
  ["pointerdown","keydown"].forEach(ev =>
    document.addEventListener(ev, function unlock() {
      try { audioCtx(); } catch(_) {}
      document.removeEventListener(ev, unlock, true);
    }, { capture:true, once:true }));

  function reverb(ctx, seconds, wetLevel) {
    const conv = ctx.createConvolver();
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random()*2-1) * Math.pow(1 - i/len, 2.6);
    }
    conv.buffer = buf;
    const wet = ctx.createGain();
    wet.gain.value = wetLevel;
    conv.connect(wet); wet.connect(ctx.destination);
    return conv;
  }

  /** Shared voice builder — one oscillator with an envelope. */
  function voice(ctx, opts) {
    const { freq, start, dur, type = "sine", peak = 0.3, to = null, dest } = opts;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, start);
    if (to) o.frequency.exponentialRampToValueAtTime(to, start + dur * 0.9);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(peak, start + Math.min(0.02, dur * 0.15));
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(dest.master);
    if (dest.conv) g.connect(dest.conv);
    o.start(start);
    o.stop(start + dur + 0.05);
    return o;
  }

  function bus(gain, revSecs, revWet) {
    const ctx = audioCtx();
    const master = ctx.createGain();
    master.gain.value = gain;
    master.connect(ctx.destination);
    const conv = revSecs ? reverb(ctx, revSecs, revWet) : null;
    return { ctx, master, conv, now: ctx.currentTime };
  }

  /** Classic finish: four-note rising arpeggio. */
  function chime() {
    if (!soundOn) return;
    try {
      const d = bus(0.22, 1.1, 0.3);
      [1046.5, 1318.5, 1568.0, 2093.0].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + i*0.085, dur: i===3 ? 0.85 : 0.42,
                       type: i===3 ? "triangle" : "sine", peak: i===3 ? 0.5 : 0.34, dest:d }));
    } catch(_) {}
  }

  /** Full-screen finish: shimmer sweep into a held major chord. */
  function chimeBig() {
    if (!soundOn) return;
    try {
      const d = bus(0.2, 1.8, 0.42);
      voice(d.ctx, { freq:420, to:2400, start:d.now, dur:0.4, peak:0.14, dest:d });
      [523.25, 659.25, 783.99, 1046.5, 1174.7].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + 0.28 + i*0.07, dur:1.5,
                       type: i>2 ? "triangle" : "sine", peak:0.3, dest:d }));
      voice(d.ctx, { freq:130.8, start:d.now + 0.28, dur:1.6, peak:0.26, dest:{ master:d.master } });
    } catch(_) {}
  }

  /** UPDATE DETECTED — two soft rising taps, like a gentle notification. */
  function soundUpdate() {
    if (!soundOn) return;
    try {
      const d = bus(0.17, 1.2, 0.34);
      voice(d.ctx, { freq:987.77,  start:d.now,        dur:0.3, type:"sine",     peak:0.3,  dest:d });
      voice(d.ctx, { freq:1318.51, start:d.now + 0.14, dur:0.55, type:"triangle", peak:0.34, dest:d });
      // faint bell tail
      voice(d.ctx, { freq:2637.02, start:d.now + 0.16, dur:0.7, type:"sine",     peak:0.07, dest:d });
    } catch(_) {}
  }

  /** UPDATE SUCCEEDED — confident four-note resolve, brighter than the
      finish chime so the two never get confused. */
  function soundSuccess() {
    if (!soundOn) return;
    try {
      const d = bus(0.21, 1.6, 0.4);
      // G  B  D  G' — clean major resolve
      [783.99, 987.77, 1174.66, 1567.98].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + i*0.075, dur: i===3 ? 1.1 : 0.5,
                       type: i===3 ? "triangle" : "sine",
                       peak: i===3 ? 0.42 : 0.28, dest:d }));
      voice(d.ctx, { freq:196, start:d.now + 0.05, dur:1.2, peak:0.2, dest:{ master:d.master } });
    } catch(_) {}
  }

  /** FAILED — low descending pair. Deliberately soft, not a buzzer. */
  function soundError() {
    if (!soundOn) return;
    try {
      const d = bus(0.19, 0.7, 0.22);
      voice(d.ctx, { freq:392,    start:d.now,        dur:0.26, type:"triangle", peak:0.3,  dest:d });
      voice(d.ctx, { freq:293.66, start:d.now + 0.15, dur:0.5,  type:"triangle", peak:0.34, dest:d });
      voice(d.ctx, { freq:146.83, start:d.now + 0.15, dur:0.55, type:"sine",     peak:0.18,
                     dest:{ master:d.master } });
    } catch(_) {}
  }

  function notify(secs) {
    try {
      if (!document.hidden) return;
      if (!("Notification" in window)) return;
      if (Notification.permission === "granted") {
        new Notification("PromptSnap", { body: T().notifyBody(secs) });
      } else if (Notification.permission !== "denied") Notification.requestPermission();
    } catch(_) {}
  }

  // ----------------------------------------------------------------------
  // Watchers
  // ----------------------------------------------------------------------

  // The observer fires in bursts while a reply streams. Collapse each
  // burst into one pass on the next frame instead of running the whole
  // check hundreds of times a second.
  let _pending = false;
  const onMutations = () => {
    if (_pending) return;
    _pending = true;
    requestAnimationFrame(() => { _pending = false; scanNow(); });
  };

  function scanNow() {
    if (!tracking) {
      if (isGenerating() || readPercent() !== null) { startTracking(); return; }
      rescueCheck();
      return;
    }
    if (!isImageJob) return;               // wait for commitment
    const img = newAssistantImage();
    if (img) {
      img.complete ? finishTracking(img)
                   : img.addEventListener("load", () => finishTracking(img), { once:true });
      return;
    }
    if (!isGenerating() && readPercent() === null && Date.now() - startedAt > 4000) standDown();
  }

  const watcher = new MutationObserver(onMutations);

  /* Watch the conversation container — and move to the new one when
     ChatGPT swaps it (new chat, re-mounted layout). Images already there
     are only marked "known" between jobs, so a result that lands while
     the container is being replaced still counts. */
  let _watched = null;
  function startWatching() {
    const root = chatRoot() || document.body;
    if (root === _watched && root.isConnected) return;
    watcher.disconnect();
    watcher.observe(root,
      { childList:true, subtree:true, characterData:true, attributes:true, attributeFilter:["src"] });
    _watched = root;
    if (!tracking) markKnownImages();
  }
  startWatching();
  setTimeout(startWatching, 3000);

  // Idle poll. Backs off to 3s when the tab is hidden and pauses
  // entirely when the page has been idle, so it costs almost nothing.
  let idleTimer = null;
  function scheduleIdlePoll() {
    clearTimeout(idleTimer);
    const gap = document.hidden ? 3000 : 1200;
    idleTimer = setTimeout(() => {
      try { startWatching(); } catch (_) {}
      if (!tracking) {
        if (readPercent() !== null) startTracking();
        else rescueCheck();
      }
      scheduleIdlePoll();
    }, gap);
  }
  scheduleIdlePoll();

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) { returnedAt = Date.now(); endedAt = 0; }
    if (!document.hidden && !tracking) document.title = origTitle;
    // reset caches on return so nothing stale is used
    _pctCache = { at: 0, val: null };
    _genCache = { at: 0, val: false };
    _imgCache = { at: 0, list: [] };
  });

  // ======================================================================
  // Open / close / drag / paste detection
  // ======================================================================

  /* Open/close with a proper motion: the panel grows out of the floating
     button (scale + lift + fade, springy ease), the sections inside
     follow a beat later, and closing shrinks it back into the button. */
  let _closeT = null;
  function aimAtFab() {
    try {
      const f = fab.getBoundingClientRect(), p = panel.getBoundingClientRect();
      const ox = Math.max(0, Math.min(p.width,  f.left + f.width / 2 - p.left));
      const oy = Math.max(0, Math.min(p.height, f.top + f.height / 2 - p.top));
      panel.style.transformOrigin = ox + "px " + oy + "px";
    } catch (_) {}
  }
  const openPanel  = () => {
    clearTimeout(_closeT);
    const wasShown = panel.classList.contains("psnap-shown");
    panel.classList.remove("psnap-closing");
    panel.classList.add("psnap-open");
    if (!wasShown) {
      aimAtFab();
      playIn(panel, "psnap-shown");           // start from the closed pose
    }
    if (!panelUsed) { panelUsed = true; fillPresets(); prewarmArt(); }
    fab.classList.add("psnap-fab-active");
    fabWrap.classList.add("psnap-panel-up");      // the hover chip would sit on the panel
    if (job.state !== "off") artKick();
    hideBubble();
    render();
    renderUpdateBanner();
    refreshCanvaTabs();
    try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
  };
  const closePanel = () => {
    if (!panel.classList.contains("psnap-open")) return;
    if (libOpen) closeLib(true);
    fab.classList.remove("psnap-fab-active");
    fabWrap.classList.remove("psnap-panel-up");
    if (animLevel() === 0) {
      panel.classList.remove("psnap-shown", "psnap-closing", "psnap-open");
      return;
    }
    aimAtFab();
    panel.classList.add("psnap-closing");
    panel.classList.remove("psnap-shown");
    clearTimeout(_closeT);
    _closeT = setTimeout(() => panel.classList.remove("psnap-open", "psnap-closing"), 260);
  };
  const togglePanel = () =>
    (panel.classList.contains("psnap-open") && !panel.classList.contains("psnap-closing"))
      ? closePanel() : openPanel();

  fab.addEventListener("click", togglePanel);
  $("#psnap-close").addEventListener("click", closePanel);
  $("#psnap-copy").addEventListener("click", () => {
    copyText(buildPrompt()).then((done) => {
      if (!done) { hint(T().hintCopyFail, false); soundError(); return; }
      hint(T().hintCopied, true);
      const b = $("#psnap-copy");
      b.classList.add("psnap-copied");
      clearTimeout(b._t); b._t = setTimeout(() => b.classList.remove("psnap-copied"), 1400);
    });
  });

  /** Replay a one-shot CSS animation class. */
  function replay(el, cls, ms) {
    if (!el) return;
    el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls);
    clearTimeout(el["_" + cls]); el["_" + cls] = setTimeout(() => el.classList.remove(cls), ms);
  }

  // a soft ripple from the point you pressed a button
  panel.addEventListener("pointerdown", (e) => {
    const b = e.target.closest(".psnap-btn");
    if (!b || b.disabled || !smoothOK()) return;
    const r = b.getBoundingClientRect();
    const dot = document.createElement("span");
    dot.className = "psnap-press";
    dot.style.left = (e.clientX - r.left) + "px";
    dot.style.top = (e.clientY - r.top) + "px";
    dot.style.setProperty("--ps-press", (Math.hypot(r.width, r.height) / 10 * 1.15).toFixed(1));
    b.appendChild(dot);
    setTimeout(() => dot.remove(), 650);
  });
  $("#psnap-insert").addEventListener("click", insertPrompt);
  $("#psnap-send").addEventListener("click", sendPrompt);
  $("#psnap-reset").addEventListener("click", (e) => doReset(e.shiftKey));

  qualSel .addEventListener("change", () => { state.quality = qualSel.value; render(); save(); });
  styleSel.addEventListener("change", () => { state.style   = styleSel.value; render(); save(); });

  // Pressing Enter in the composer counts as a send, so arm the tracker
  // even when the prompt wasn't inserted by us.
  document.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
      const c = findComposer();
      if (c && (e.target === c || c.contains(e.target))) armTracker();
    }
  }, true);

  document.addEventListener("keydown", e => {
    if (e.ctrlKey && e.shiftKey && e.code === "Space") { e.preventDefault(); togglePanel(); }
    if (e.ctrlKey && e.key === "Enter" && panel.classList.contains("psnap-open")) {
      // Only from inside PromptSnap (or with nothing focused). Pressed in
      // ChatGPT's own message box it belongs to ChatGPT — it used to add
      // PromptSnap's prompt to your own message and send both.
      const t = e.target;
      if (!t || t === document.body || panel.contains(t)) { e.preventDefault(); sendPrompt(); }
    }
    if (e.key === "Escape") { if (panel.classList.contains("psnap-open")) closePanel(); hideBubble(); }
  });

  /* Drag by the header. Pointer capture keeps the drag alive when the
     cursor outruns the panel, moves are coalesced to one write per frame,
     and the header can't be dropped somewhere it can no longer be grabbed. */
  (function drag() {
    const head = $("#psnap-head");
    let sx, sy, sl, st, nx, ny, on = false, raf = 0;
    const paint = () => {
      raf = 0;
      panel.style.left = nx + "px";
      panel.style.top  = ny + "px";
    };
    head.addEventListener("pointerdown", e => {
      if (e.button !== 0 || e.target.closest("button")) return;
      const r = panel.getBoundingClientRect();
      Object.assign(panel.style, { left:r.left+"px", top:r.top+"px", right:"auto", bottom:"auto" });
      sx=e.clientX; sy=e.clientY; sl=r.left; st=r.top; on=true;
      try { head.setPointerCapture(e.pointerId); } catch(_) {}
      panel.classList.add("psnap-dragging");
      e.preventDefault();
    });
    head.addEventListener("pointermove", e => {
      if (!on) return;
      nx = Math.min(Math.max(0, sl + e.clientX - sx), Math.max(0, window.innerWidth - 80));
      ny = Math.min(Math.max(0, st + e.clientY - sy), Math.max(0, window.innerHeight - 48));
      if (!raf) raf = requestAnimationFrame(paint);
    });
    const end = () => {
      if (!on) return;
      on = false;
      if (raf) { cancelAnimationFrame(raf); paint(); }
      panel.classList.remove("psnap-dragging");
    };
    head.addEventListener("pointerup", end);
    head.addEventListener("pointercancel", end);
    head.addEventListener("lostpointercapture", end);

    // a dragged panel stays reachable when the window gets smaller
    let rz = 0;
    window.addEventListener("resize", () => {
      if (rz) return;
      rz = requestAnimationFrame(() => {
        rz = 0;
        const l = parseFloat(panel.style.left), t = parseFloat(panel.style.top);
        if (!isFinite(l) || !isFinite(t)) return;          // still docked bottom-right
        const cl = Math.min(Math.max(0, l), Math.max(0, window.innerWidth - 80));
        const ct = Math.min(Math.max(0, t), Math.max(0, window.innerHeight - 48));
        if (cl !== l) panel.style.left = cl + "px";
        if (ct !== t) panel.style.top = ct + "px";
      });
    });
  })();

  function sawImage() {
    if (panel.classList.contains("psnap-open")) { hint(T().hintDetected, true); return; }
    showBubble();
  }
  document.addEventListener("paste", e => {
    const items = e.clipboardData && e.clipboardData.items; if (!items) return;
    for (const it of items) if (it.type && it.type.startsWith("image/")) { sawImage(); break; }
  }, true);
  document.addEventListener("drop", e => {
    const f = e.dataTransfer && e.dataTransfer.files;
    if (f && [...f].some(x => x.type.startsWith("image/"))) sawImage();
  }, true);
  // file picker route
  document.addEventListener("change", e => {
    const t = e.target;
    if (t && t.type === "file" && t.files && [...t.files].some(f => f.type.startsWith("image/"))) sawImage();
  }, true);

  // ======================================================================
  // Persistence
  // ======================================================================

  /* Saved a moment after the last change rather than on every keystroke,
     and flushed straight away if the tab is being hidden or closed. */
  let saveT = 0;
  const flushSave = () => {
    if (!saveT) return;
    clearTimeout(saveT); saveT = 0;
    try { chrome.storage.local.set({ psnapState: state }); } catch(_){}
  };
  const save = () => { clearTimeout(saveT); saveT = setTimeout(flushSave, 300); };
  window.addEventListener("pagehide", flushSave);
  document.addEventListener("visibilitychange", () => { if (document.hidden) flushSave(); });
  const saveCustom = () => { try { chrome.storage.local.set({ psnapCustom: custom }); } catch(_){} };

  function boot() {
    /** Run a step in isolation. One broken optional section must never
        stop the rest of the panel from painting — that is exactly what
        left every label blank when paintCanvaCurrent went missing. */
    const step = (name, fn) => {
      try { fn(); }
      catch (err) { console.warn("[PromptSnap] " + name + " failed:", err); }
    };

    const apply = (r = {}) => {
      step("state", () => {
        storedPresets = (Array.isArray(r.psnapPresets) && r.psnapPresets.length) ? r.psnapPresets : null;
        const ids = (v) => Array.isArray(v) ? v.filter(x => typeof x === "string").slice(0, 200) : [];
        fav = ids(r.psnapFav);
        recent = ids(r.psnapRecent).slice(0, 12);
        mine = Array.isArray(r.psnapMine)
          ? r.psnapMine.filter(m => m && typeof m.id === "string" && typeof m.name === "string" && typeof m.text === "string")
          : [];
        presets = buildLibrary(storedPresets);
        if (r.psnapCustom && typeof r.psnapCustom === "object") custom = r.psnapCustom;
        if (r.psnapState) state = Object.assign(DEFAULT_STATE(), r.psnapState);
        // the saved preset, by id; 3.0 and earlier saved a position in the old list
        let at = state.pid ? presets.findIndex(p => p.id === state.pid) : -1;
        if (at < 0 && !state.pid && r.psnapState) {
          const old = storedPresets ? storedPresets.map(p => p && p.name) : (LIB.legacyOrder || []);
          const name = old[state.preset];
          if (name) at = presets.findIndex(p => p.name === name);
          if (at >= 0) { setPreset(at); save(); }    // store it by id from now on
        }
        setPreset(at >= 0 ? at : 0);
        if (r.psnapLang === "km" || r.psnapLang === "en") lang = r.psnapLang;
        if (typeof r.psnapSound === "boolean") soundOn = r.psnapSound;
        if (["full","classic","off"].includes(r.psnapCel))   celebration = r.psnapCel;
        if (["dark","light","auto"].includes(r.psnapTheme))  theme = r.psnapTheme;
        if (["full","reduced","minimal","off"].includes(r.psnapAnim)) anim = r.psnapAnim;
        if (typeof r.psnapFeed === "string") feedUrl = r.psnapFeed;
        if (typeof r.psnapCanvaPick === "number") canvaPick = r.psnapCanvaPick;
        if (["s","m","l"].includes(r.psnapSize)) panelSize = r.psnapSize;
        if (r.psnapUpdate) updateState = r.psnapUpdate;
      });

      // LANGUAGE FIRST. Everything the user actually reads comes from
      // this pass, so nothing optional is allowed to run ahead of it.
      step("language", applyLanguage);
      step("anim",     applyAnim);
      step("size",     applySize);
      step("theme",    applyTheme);
      step("update",   renderUpdateBanner);
      step("canva",    () => {
        paintCanva();
        setCanvaOpen(false, true);        // collapsed until you open it
      });
    };

    try {
      chrome.storage.local.get(
        ["psnapState","psnapPresets","psnapCustom","psnapLang","psnapFav","psnapRecent","psnapMine",
         "psnapSound","psnapCel","psnapTheme","psnapFeed","psnapUpdate","psnapAnim",
         "psnapCanvaOpen","psnapCanvaPick","psnapSize"],
        (r) => {
          if (chrome.runtime.lastError) { apply({}); return; }
          apply(r || {});
        });
    } catch (err) {
      console.warn("[PromptSnap] storage unavailable, using defaults:", err);
      apply({});
    }

    // Last-ditch safety net: if the labels somehow never painted, force
    // one more language pass a moment later rather than sitting blank.
    setTimeout(() => {
      try {
        if (!$("#lbl-preset").textContent) applyLanguage();
      } catch (_) {}
    }, 800);
  }

  boot();
})();
