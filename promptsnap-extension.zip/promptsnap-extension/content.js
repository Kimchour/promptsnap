/* PromptSnap v1.3 — floating image-prompt builder for ChatGPT
 * - English / Khmer interface (prompt output is ALWAYS English)
 * - preset library with dynamic fields + suggestion chips you can extend
 * - Reset button
 * - smooth FAB animation + "Need a Help?" bubble on image insert
 * - generation tracker with taskbar/tab status and done animation
 */

(() => {
  if (window.__promptSnapLoaded) return;
  window.__promptSnapLoaded = true;

  const I18N     = window.PSNAP_I18N || {};
  const KM_VALS  = window.PSNAP_KM_VALUES || {};
  const KM_PRE   = window.PSNAP_KM_PRESETS || {};

  let lang = "en";
  let soundOn = true;
  let celebration = "full";     // full | classic | off
  let theme = "dark";           // dark | light | auto
  let feedUrl = "";
  let anim = "full";   // full | reduced | minimal | off
  const DEFAULT_FEED =
    "https://raw.githubusercontent.com/Kimchour/promptsnap/main/version.json";
  const T = () => I18N[lang] || I18N.en;

  /** Khmer display label for an English value. Falls back to English. */
  const L = (v) => (lang === "km" && KM_VALS[v]) ? KM_VALS[v] : v;

  // ======================================================================
  // Data — all VALUES below are English and go into the prompt verbatim
  // ======================================================================

  const RATIOS  = ["4:5","1:1","3:4","2:3","9:16","5:4","4:3","3:2","16:9","21:9","Keep original"];
  const QUALITY = ["8K","4K","6K","12K","HD","—"];
  const STYLES  = [
    "editorial / stock image style",
    "photojournalism, wire-service style",
    "raw iPhone photo, unprepared angle",
    "aviation spotter photography",
    "cinematic still",
    "documentary realism",
    "security camera footage",
    "drone / aerial photography",
    "golden hour natural light",
    "clean product shot",
    "vintage film photo, grainy",
    "—"
  ];

  const SUGGESTIONS = {
    angle: [
      "on the runway, side-on / broadside",
      "close up on the runway",
      "head-on, nose filling the frame",
      "three-quarter front view on the taxiway",
      "three-quarter rear view, engines visible",
      "low angle from ground level, looking up",
      "high angle from the terminal window",
      "rotating for takeoff, gear still down",
      "on final approach, gear down, flaps extended",
      "touching down, tyre smoke on contact",
      "parked at the gate with jet bridge attached",
      "tail close up, livery filling the frame",
      "cockpit windows close up",
      "engine nacelle close up",
      "wing view from a passenger window",
      "taxiing through rain, wet tarmac reflections",
      "at night, runway lights glowing",
      "silhouetted against sunset",
      "banking overhead, belly visible",
      "seen through heat haze down the runway"
    ],
    lighting: ["harsh midday sun","golden hour, warm low sun","overcast, flat soft light",
               "blue hour, just after sunset","night, artificial floodlights",
               "backlit, subject in silhouette","stormy grey sky"],
    weather:  ["clear blue sky","heavy rain","light snow","thick fog","windy with low cloud","dust haze"],
    emotion:  ["tense and urgent","quiet and sombre","joyful and chaotic","shocked bystanders","calm aftermath"],
    location: ["busy international airport","small regional airstrip","city street","suburban neighbourhood",
               "hospital corridor","courtroom","police cordon","rural roadside"],
    subject:  ["a middle-aged man","a young woman","an elderly couple","a small child",
               "airport ground crew","police officers","a crowd of onlookers"]
  };

  const DEFAULT_PRESETS = [
    { g:"Enhance", name:"Enhance + Expand",
      text:"Enhance and expand this image in {quality} quality with very well detailed textures. Keep the original subject, lighting and composition exactly as they are. Aspect ratio {ratio}." },
    { g:"Enhance", name:"Enhance + Remove Text/Overlay",
      text:"Enhance and expand this image in {ratio} ratio. Remove all text, watermarks, logos and graphic overlays from the image, but keep the original state of the photo untouched — same subject, same lighting, same angle. Output in {quality} quality." },
    { g:"Enhance", name:"Upscale Only (no changes)",
      text:"Upscale this image to {quality} quality. Do not change, add or remove anything — same framing, same colours, same content. Only sharpen detail and clean up compression artifacts." },
    { g:"Enhance", name:"Outpaint / Extend Edges",
      text:"Extend this image outward to fill a {ratio} frame. Continue the existing background, lighting and perspective naturally into the new area. Do not alter the original subject. {quality} quality." },
    { g:"Enhance", name:"Restore Old / Damaged Photo",
      text:"Restore this photograph. Repair scratches, tears, fading and colour casts. Recover natural skin tones and detail. Keep the original composition and era-accurate look — do not modernise faces or clothing. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Remove Background",
      text:"Remove the background from this image completely, leaving only the main subject on a clean transparent background. Keep edges sharp and natural, including fine detail. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Change Background",
      text:"Keep the main subject of this image exactly as it is. Replace the background with {location}. Match the lighting and shadows on the subject to the new background so it looks like one real photograph. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Fix Lighting / Colour Grade",
      text:"Colour grade this image with {lighting}. Keep all content identical — only adjust exposure, contrast, white balance and colour. {quality} quality, aspect ratio {ratio}." },

    { g:"Aviation", name:"Aircraft — Custom Angle",
      text:"A {airline} aircraft {angle}. The image is in {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Close Up on Runway",
      text:"Close up image of a {airline} aircraft on the runway. The image is in {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Side-On / Broadside",
      text:"A {airline} aircraft on the runway, photographed side-on / broadside. The image is in {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Weather + Angle",
      text:"A {airline} aircraft {angle}, in {weather}, {lighting}. The image is in {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Airport Scene (no aircraft focus)",
      text:"A wide scene at {location}. {subject} in frame. {lighting}, {weather}. The image is in {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Cabin Interior",
      text:"Inside the cabin of a {airline} aircraft. {subject} visible. Natural cabin lighting, realistic seat and window detail. {quality} quality, taken in {style}. Aspect ratio {ratio}." },

    { g:"Story", name:"Raw iPhone Photo from Story",
      text:"Generate a raw image taken on an iPhone camera at an unprepared, candid angle, based on this story:\n\n\"{story}\"\n\nSlight motion blur, natural available light, imperfect framing — it should look like a real bystander photo, not a staged shot. Aspect ratio {ratio}." },
    { g:"Story", name:"Raw iPhone Photo + Reference Image",
      text:"Generate a raw image taken on an iPhone camera at an unprepared, candid angle, based on this story:\n\n\"{story}\"\n\nUse the reference image I provided to match the subject, setting and details as accurately as possible. Natural light, imperfect framing, real bystander feel. Aspect ratio {ratio}." },
    { g:"Story", name:"News Photo from Story",
      text:"Create a news photograph illustrating this story:\n\n\"{story}\"\n\nShot in {style}, {lighting}. It should look like a real wire-service image — no text, no watermarks, no captions burned in. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Security Camera Still",
      text:"Create a still frame from a fixed security camera showing this moment:\n\n\"{story}\"\n\nHigh mounted wide angle, slight fisheye, mild grain and compression, muted colour, timestamp-free. Aspect ratio {ratio}." },
    { g:"Story", name:"Aftermath Scene",
      text:"Show the aftermath of this event, no people in distress in frame:\n\n\"{story}\"\n\nSetting: {location}. {lighting}, {weather}. Shot in {style}. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Portrait from Story",
      text:"A natural portrait of {subject}, connected to this story:\n\n\"{story}\"\n\n{lighting}. Shot in {style}, shallow depth of field, honest and unposed. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Historical Recreation",
      text:"Recreate this historical moment as a period-accurate photograph:\n\n\"{story}\"\n\nMatch the clothing, vehicles, signage and film look of the era. No modern objects in frame. {quality} quality, aspect ratio {ratio}." },

    { g:"Utility", name:"Thumbnail — Bold & Scroll-Stopping",
      text:"Create a bold social thumbnail based on this: \"{story}\"\nSingle clear focal subject, strong contrast, uncluttered background so text can be added later. Do NOT put any text in the image. {quality} quality, aspect ratio {ratio}." },
    { g:"Utility", name:"Variations of This Image",
      text:"Generate {count} variations of this image. Keep the same subject, style and mood, but vary the camera angle and framing each time. {quality} quality, aspect ratio {ratio}." },
    { g:"Utility", name:"Same Scene, Different Angle",
      text:"Same scene and same subject as the image I provided, but reshot {angle}. Keep the lighting, weather and time of day consistent. {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Enhance", name:"Sharpen Faces Only",
      text:"Sharpen and recover detail in the faces in this image only. Leave the background exactly as it is. Keep skin texture natural — no smoothing, no beautifying. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Denoise / Clean Grain",
      text:"Remove digital noise and grain from this image while keeping edge detail and texture intact. Do not soften faces or lose fine detail. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Fix Perspective / Straighten",
      text:"Straighten and correct the perspective of this image so vertical lines are vertical and the horizon is level. Crop minimally. Keep all content. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Recolour to Match Brand",
      text:"Recolour this image to a {lighting} look with a consistent, brand-ready palette. Keep the subject and composition identical. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Day to Night",
      text:"Convert this daytime image to a convincing night scene. Add realistic artificial lighting, correct shadow direction, cooler ambient colour and appropriate window and street lights. Keep every object in place. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Remove a Person or Object",
      text:"Remove {subject} from this image and reconstruct the background behind them so it looks untouched. Keep everything else identical. {quality} quality, aspect ratio {ratio}." },
    { g:"Enhance", name:"Add Depth / Bokeh",
      text:"Add a natural shallow depth of field to this image. Keep the main subject sharp and blur the background progressively with realistic lens bokeh. Do not create a cut-out halo around the subject. {quality} quality, aspect ratio {ratio}." },

    { g:"Aviation", name:"Aircraft — Engine / Damage Detail",
      text:"Close detail shot of the engine and surrounding structure of a {airline} aircraft, {angle}. Technical and clear, no dramatisation. {lighting}. {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Two Aircraft in Frame",
      text:"Two {airline} aircraft in the same frame at {location}, one in the foreground {angle} and one behind. Natural depth and separation. {lighting}, {weather}. {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Ground Crew at Work",
      text:"Ground crew working around a {airline} aircraft at {location}. Realistic high-visibility clothing, equipment and posture. {lighting}, {weather}. {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Aircraft — Emergency Response",
      text:"Emergency vehicles positioned near a {airline} aircraft on the ground at {location}. Calm, procedural, no injuries or distress shown. {lighting}, {weather}. {quality} quality, taken in {style}. Aspect ratio {ratio}." },
    { g:"Aviation", name:"Airport — Departure Board / Terminal",
      text:"Interior of {location} showing the departure area and information displays. Do not render readable text on the boards — keep it blurred or generic. {subject} in frame. {lighting}. {quality} quality, taken in {style}. Aspect ratio {ratio}." },

    { g:"Story", name:"Courtroom / Legal Scene",
      text:"A courtroom scene connected to this story:\n\n\"{story}\"\n\nRestrained and neutral, no identifiable real people, no readable documents. {lighting}. Shot in {style}. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Crowd Reaction Shot",
      text:"A crowd reacting to this moment:\n\n\"{story}\"\n\nMood: {emotion}. Faces partially turned or out of focus so no one is identifiable. {lighting}. Shot in {style}. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Before and After Pair",
      text:"Create a single image split into two halves, before on the left and after on the right, illustrating this:\n\n\"{story}\"\n\nMatch the camera position and lighting across both halves so the change is obvious. No text labels. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Establishing Wide Shot",
      text:"A wide establishing shot that sets the scene for this story:\n\n\"{story}\"\n\nLocation: {location}. {lighting}, {weather}. Plenty of context in frame, subject small within the environment. Shot in {style}. {quality} quality, aspect ratio {ratio}." },
    { g:"Story", name:"Object Close Up (evidence style)",
      text:"A tight, plainly lit close up of the key object in this story:\n\n\"{story}\"\n\nNeutral background, even lighting, documentary clarity, no styling or drama. {quality} quality, aspect ratio {ratio}." },

    { g:"Utility", name:"Carousel Set (3 images)",
      text:"Create 3 images that work as a social carousel about this: \"{story}\"\nConsistent lighting, palette and style across all three, but a different framing in each. No text in any of them. {quality} quality, aspect ratio {ratio}." },
    { g:"Utility", name:"Text-Safe Background",
      text:"Same subject and scene as the image I provided, but recomposed so the {angle} side of the frame is clean and uncluttered, leaving empty space for a headline to be added later. Do not add any text yourself. {quality} quality, aspect ratio {ratio}." },
    { g:"Utility", name:"Profile / Avatar Crop",
      text:"Crop and recompose this image into a clean profile picture. Centre the subject's face, leave comfortable headroom, keep the background simple. {quality} quality, aspect ratio {ratio}." },
    { g:"Utility", name:"Colour Palette Match",
      text:"Regenerate this image using the colour palette and mood of {lighting}, keeping the subject, pose and composition identical. {quality} quality, aspect ratio {ratio}." },

    { g:"Utility", name:"Free Prompt",
      text:"{free}\n\nAspect ratio {ratio}. {quality} quality." }
  ];

  const RESERVED = new Set(["ratio","quality","style"]);
  const DEFAULT_STATE = () => ({ preset:0, ratio:"4:5", quality:"8K", style:STYLES[0], vars:{} });

  let presets = DEFAULT_PRESETS;
  let custom  = {};
  let state   = DEFAULT_STATE();

  // ======================================================================
  // UI shell
  // ======================================================================

  const fabWrap = document.createElement("div");
  fabWrap.id = "psnap-fab-wrap";
  fabWrap.innerHTML = `
    <div id="psnap-bubble">
      <span id="psnap-bubble-dot"></span>
      <span id="psnap-bubble-text"></span>
      <span id="psnap-bubble-x" title="Dismiss">&times;</span>
    </div>
    <button id="psnap-fab" title="PromptSnap  (Ctrl+Shift+Space)">
      <span id="psnap-fab-ring"></span>
      <span id="psnap-fab-icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path class="psnap-star-lg" d="M12 3.2l1.7 4.6 4.6 1.7-4.6 1.7L12 15.8l-1.7-4.6L5.7 9.5l4.6-1.7L12 3.2z"
                fill="currentColor"/>
          <path class="psnap-star-sm" d="M18.2 14.4l.85 2.3 2.3.85-2.3.85-.85 2.3-.85-2.3-2.3-.85 2.3-.85.85-2.3z"
                fill="currentColor" opacity=".85"/>
          <path class="psnap-star-xs" d="M5.6 15.1l.6 1.6 1.6.6-1.6.6-.6 1.6-.6-1.6L3.4 17.3l1.6-.6.6-1.6z"
                fill="currentColor" opacity=".6"/>
        </svg>
      </span>
      <span id="psnap-fab-pct"></span>
      <span id="psnap-fab-orbit"><i></i><i></i></span>
    </button>
  `;

  const panel = document.createElement("div");
  panel.id = "psnap-panel";
  panel.innerHTML = `
    <div class="psnap-head" id="psnap-head">
      <strong>PromptSnap</strong>
      <span id="psnap-status"></span>
      <button id="psnap-gear" class="psnap-iconbtn" title="Settings"></button>
      <div class="psnap-langsw" id="psnap-langsw">
        <button data-lang="en" class="psnap-lang psnap-lang-on">EN</button>
        <button data-lang="km" class="psnap-lang">ខ្មែរ</button>
      </div>
      <button id="psnap-close" title="Close">&times;</button>
    </div>
    <div class="psnap-update" id="psnap-update" hidden>
      <div class="psnap-up-main">
        <span class="psnap-up-dot"></span>
        <div class="psnap-up-text">
          <strong id="psnap-up-title"></strong>
          <span id="psnap-up-sub"></span>
        </div>
      </div>
      <div id="psnap-up-notes" class="psnap-up-notes" hidden></div>
      <div class="psnap-up-actions">
        <button class="psnap-btn psnap-up-later" id="psnap-up-later"></button>
        <button class="psnap-btn psnap-primary" id="psnap-up-go"></button>
      </div>
    </div>
    <div class="psnap-settings" id="psnap-settings" hidden>
      <div class="psnap-set-row">
        <span id="set-lbl-sound"></span>
        <div class="psnap-seg" id="set-sound"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-cel"></span>
        <div class="psnap-seg" id="set-cel"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-theme"></span>
        <div class="psnap-seg" id="set-theme"></div>
      </div>
      <div class="psnap-set-row">
        <span id="set-lbl-anim"></span>
        <div class="psnap-seg" id="set-anim"></div>
      </div>
      <div class="psnap-set-divider"></div>
      <div class="psnap-set-row">
        <span id="set-lbl-updates"></span>
        <button class="psnap-minibtn" id="set-check"></button>
      </div>
      <div class="psnap-set-meta" id="set-upmeta"></div>
    </div>
    <div class="psnap-body">
      <label class="psnap-label"><span id="lbl-preset"></span></label>
      <select id="psnap-preset"></select>

      <label class="psnap-label"><span id="lbl-ratio"></span></label>
      <div class="psnap-chips" id="psnap-ratios"></div>

      <div class="psnap-row" style="margin-top:10px">
        <div><label class="psnap-label"><span id="lbl-quality"></span></label><select id="psnap-quality"></select></div>
        <div><label class="psnap-label"><span id="lbl-style"></span></label><select id="psnap-style"></select></div>
      </div>

      <div id="psnap-vars"></div>

      <label class="psnap-label">
        <span id="lbl-final"></span>
        <span class="psnap-en-tag">EN</span>
      </label>
      <div id="psnap-preview"></div>
      <div class="psnap-hint" id="psnap-hint"></div>
    </div>
    <div class="psnap-canva" id="psnap-canva" hidden>
      <div class="psnap-canva-head">
        <span class="psnap-canva-label" id="psnap-canva-lbl"></span>
        <button class="psnap-canva-refresh" id="psnap-canva-refresh" title="Refresh"></button>
      </div>
      <select id="psnap-canva-sel"></select>
      <button class="psnap-btn psnap-canva-send" id="psnap-canva-send"></button>
      <div class="psnap-canva-note" id="psnap-canva-note"></div>
    </div>
    <div class="psnap-foot">
      <button class="psnap-btn psnap-reset" id="psnap-reset"></button>
      <button class="psnap-btn" id="psnap-copy"></button>
      <button class="psnap-btn" id="psnap-insert"></button>
      <button class="psnap-btn psnap-primary psnap-send" id="psnap-send"></button>
    </div>
  `;

  const toast = document.createElement("div");
  toast.id = "psnap-toast";
  toast.innerHTML = `
    <div class="psnap-toast-ring"><div class="psnap-toast-check">&#10003;</div></div>
    <div class="psnap-toast-text"><strong id="psnap-toast-title"></strong><span id="psnap-toast-sub"></span></div>
  `;

  document.body.appendChild(fabWrap);
  document.body.appendChild(panel);
  document.body.appendChild(toast);

  const fab    = fabWrap.querySelector("#psnap-fab");
  const bubble = fabWrap.querySelector("#psnap-bubble");
  const $  = (s) => panel.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

  const presetSel = $("#psnap-preset");
  const qualSel   = $("#psnap-quality");
  const styleSel  = $("#psnap-style");
  const ratioWrap = $("#psnap-ratios");

  // ======================================================================
  // Language
  // ======================================================================

  function presetLabel(p) {
    return (lang === "km" && KM_PRE[p.name]) ? KM_PRE[p.name] : p.name;
  }
  function fieldLabel(n) {
    const f = T().fields || {};
    if (f[n]) return f[n];
    return n.replace(/_/g," ").replace(/\b\w/g, c => c.toUpperCase());
  }

  function applyLanguage() {
    const t = T();
    panel.classList.toggle("psnap-km", lang === "km");

    $("#lbl-preset").textContent  = t.preset;
    $("#lbl-ratio").textContent   = t.ratio;
    $("#lbl-quality").textContent = t.quality;
    $("#lbl-style").textContent   = t.style;
    $("#lbl-final").textContent   = t.finalPrompt;

    $("#psnap-reset").textContent  = t.reset;
    $("#psnap-reset").title        = t.resetTip;
    $("#psnap-copy").textContent   = t.copy;
    $("#psnap-insert").textContent = t.insert;
    $("#psnap-insert").title        = t.insertTip;
    $("#psnap-send").textContent    = t.send;
    $("#psnap-send").title          = t.sendTip;

    panel.querySelectorAll(".psnap-lang").forEach(b =>
      b.classList.toggle("psnap-lang-on", b.dataset.lang === lang));
    if (!$("#psnap-settings").hidden) paintSettings();
    $("#psnap-gear").title = T().settings;

    fillPresets();
    fillRatios();
    fillSelects();
    buildVars();
    render();
    hintDefault();
  }

  function fillSelects() {
    const t = T();
    qualSel.innerHTML = QUALITY.map(q =>
      `<option value="${esc(q)}">${q === "—" ? t.none : esc(q)}</option>`).join("");
    styleSel.innerHTML = STYLES.map(s =>
      `<option value="${esc(s)}">${s === "—" ? t.none : esc(L(s))}</option>`).join("");
    qualSel.value  = state.quality;
    styleSel.value = state.style;
  }

  function fillRatios() {
    ratioWrap.innerHTML = RATIOS.map(r =>
      `<span class="psnap-chip" data-r="${esc(r)}">${r === "Keep original" ? esc(T().keepOriginal) : r}</span>`
    ).join("");
    paintRatios();
  }

  function fillPresets() {
    const groups = {};
    presets.forEach((p,i) => { (groups[p.g || "Presets"] ||= []).push([i,p]); });
    const gmap = T().groups || {};
    presetSel.innerHTML = Object.entries(groups).map(([g, items]) =>
      `<optgroup label="${esc(gmap[g] || g)}">` +
      items.map(([i,p]) => `<option value="${i}">${esc(presetLabel(p))}</option>`).join("") +
      `</optgroup>`).join("");
    presetSel.value = String(Math.min(state.preset, presets.length - 1));
  }

  const paintRatios = () => ratioWrap.querySelectorAll(".psnap-chip")
    .forEach(c => c.classList.toggle("psnap-on", c.dataset.r === state.ratio));

  ratioWrap.addEventListener("click", e => {
    const c = e.target.closest(".psnap-chip"); if (!c) return;
    state.ratio = c.dataset.r; paintRatios(); render(); save();
  });

  const GEAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
    + 'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/>'
    + '<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 '
    + '1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 '
    + '1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 '
    + '4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 '
    + '1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A'
    + '1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';

  $("#psnap-gear").innerHTML = GEAR;

  function seg(container, options, current, onPick) {
    container.innerHTML = options.map(o =>
      `<button data-val="${esc(o.val)}" class="${o.val === current ? "psnap-seg-on" : ""}">${esc(o.label)}</button>`
    ).join("");
    container.onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      onPick(b.dataset.val);
    };
  }


  // ======================================================================
  // Canva bridge
  // ======================================================================

  let canvaTabs = [];
  let lastImageUrl = "";

  const REFRESH_ICON =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" '
    + 'stroke-linecap="round" stroke-linejoin="round">'
    + '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/></svg>';

  function refreshCanvaTabs(then) {
    try {
      chrome.runtime.sendMessage({ type: "psnap-canva-tabs" }, (tabs) => {
        canvaTabs = Array.isArray(tabs) ? tabs : [];
        paintCanva();
        if (then) then();
      });
    } catch(_) { canvaTabs = []; paintCanva(); }
  }

  function paintCanva() {
    const t = T();
    const box = $("#psnap-canva");
    const sel = $("#psnap-canva-sel");
    const btn = $("#psnap-canva-send");
    const note = $("#psnap-canva-note");

    $("#psnap-canva-lbl").textContent = t.canva;
    $("#psnap-canva-refresh").innerHTML = REFRESH_ICON;
    $("#psnap-canva-refresh").title = t.refresh;
    btn.textContent = t.sendToCanva;

    box.hidden = false;

    if (!canvaTabs.length) {
      sel.innerHTML = `<option>${esc(t.noCanva)}</option>`;
      sel.disabled = true;
      btn.disabled = true;
      note.textContent = t.canvaHint;
      note.className = "psnap-canva-note";
      return;
    }

    sel.disabled = false;
    const prev = sel.value;
    sel.innerHTML = canvaTabs
      .map(tb => `<option value="${tb.id}">${esc(tb.title)}</option>`)
      .join("");
    if (prev && canvaTabs.some(tb => String(tb.id) === prev)) sel.value = prev;

    btn.disabled = !lastImageUrl;
    note.textContent = lastImageUrl ? "" : t.noImageYet;
    note.className = "psnap-canva-note";
  }

  function sendToCanva(fromButton) {
    const t = T();
    const sel = $("#psnap-canva-sel");
    const btn = $("#psnap-canva-send");
    const note = $("#psnap-canva-note");
    const tabId = Number(sel.value);
    if (!tabId || !lastImageUrl) return;

    btn.disabled = true;
    btn.textContent = t.sending;
    btn.classList.add("psnap-um-busy");

    try {
      chrome.runtime.sendMessage(
        { type: "psnap-canva-send", tabId, imageUrl: lastImageUrl },
        (res) => {
          btn.classList.remove("psnap-um-busy");
          btn.textContent = t.sendToCanva;
          btn.disabled = false;
          if (res && res.ok) {
            note.textContent = t.sentToCanva;
            note.className = "psnap-canva-note psnap-canva-ok";
            soundSuccess();
          } else {
            note.textContent = t.canvaFail;
            note.className = "psnap-canva-note psnap-canva-err";
            soundError();
          }
        });
    } catch(_) {
      btn.classList.remove("psnap-um-busy");
      btn.textContent = t.sendToCanva;
      btn.disabled = false;
      note.textContent = t.canvaFail;
      note.className = "psnap-canva-note psnap-canva-err";
      soundError();
    }
  }

  $("#psnap-canva-refresh").addEventListener("click", () => refreshCanvaTabs());
  $("#psnap-canva-send").addEventListener("click", () => sendToCanva(true));

  // ======================================================================
  // Guardrail / refusal detection
  // ======================================================================

  const REFUSAL_PATTERNS = [
    /i can'?t (help with|create|generate|make|produce) th(at|is)/i,
    /i'?m (not able|unable) to (create|generate|make|produce)/i,
    /i wasn'?t able to (create|generate|produce)/i,
    /(violates?|against|doesn'?t follow) (our |the )?(content|usage) polic/i,
    /content polic(y|ies)/i,
    /this request (was|has been) (blocked|flagged)/i,
    /(can'?t|cannot) (create|generate) images? (of|that|depicting)/i,
    /i'?m sorry,? but i (can'?t|cannot)/i,
    /didn'?t pass (our )?(content|safety)/i,
    /flagged by (our )?(content|safety) (system|filter)/i,
    /unable to (comply|continue) with/i
  ];

  /** Read the tail of the last assistant message. */
  function lastAssistantText() {
    const main = document.querySelector("main");
    if (!main) return "";
    const turns = main.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (!last) return "";
    return (last.textContent || "").slice(-1200);
  }

  function looksRefused(text) {
    if (!text || text.length < 12) return false;
    return REFUSAL_PATTERNS.some(re => re.test(text));
  }

  function showBlocked(reason) {
    const t = T();
    document.getElementById("psnap-blocked")?.remove();

    const el = document.createElement("div");
    el.id = "psnap-blocked";
    el.className = "psnap-blocked"
      + (panel.classList.contains("psnap-light") ? " psnap-blocked-light" : "");
    el.innerHTML = `
      <div class="psnap-bl-ico">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
             stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="9"/><path d="M12 7v6"/><path d="M12 16.5v.01"/>
        </svg>
      </div>
      <div class="psnap-bl-txt">
        <strong>${esc(t.blocked)}</strong>
        <span>${esc(reason || t.blockedSub)}</span>
        <em>${esc(t.blockedHint)}</em>
      </div>
      <button class="psnap-bl-x" title="${esc(t.dismiss)}">&times;</button>
    `;
    document.body.appendChild(el);
    const begin = () => el.classList.add("psnap-bl-in");
    requestAnimationFrame(begin); setTimeout(begin, 30);

    const close = () => {
      el.classList.remove("psnap-bl-in");
      setTimeout(() => el.remove(), 320);
    };
    el.querySelector(".psnap-bl-x").onclick = close;
    el.addEventListener("click", (e) => { if (e.target === el) close(); });
    setTimeout(close, 11000);

    soundError();
    if (document.hidden) {
      try {
        if (Notification.permission === "granted")
          new Notification("PromptSnap", { body: t.blockedSub });
      } catch(_) {}
    }
  }

  // ======================================================================
  // Updates
  // ======================================================================

  let updateState = null;

  const myVersion = () => {
    try { return chrome.runtime.getManifest().version; } catch(_) { return "?"; }
  };

  function renderUpdateBanner() {
    const box = $("#psnap-update");
    const t = T();
    const u = updateState;

    const show = !!(u && u.available && u.latest && u.dismissed !== u.latest);
    box.hidden = !show;
    $("#psnap-gear").classList.toggle("psnap-has-update", show);
    fab.classList.toggle("psnap-has-update", show);
    if (!show) return;

    $("#psnap-up-title").textContent = t.updateAvailable;
    $("#psnap-up-sub").textContent   = `${t.newVersion(u.latest)} · ${t.youHave(u.current)}`;
    $("#psnap-up-later").textContent = t.later;
    $("#psnap-up-go").textContent    = t.updateNow;

    const notes = $("#psnap-up-notes");
    if (u.notes) { notes.textContent = u.notes; notes.hidden = false; }
    else notes.hidden = true;

    box.classList.toggle("psnap-up-required", !!u.required);
    $("#psnap-up-later").style.display = u.required ? "none" : "";
  }

  $("#psnap-up-later").addEventListener("click", () => {
    if (!updateState || !updateState.latest) return;
    const next = Object.assign({}, updateState, { dismissed: updateState.latest });
    updateState = next;
    persist({ psnapUpdate: next });
    try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
    renderUpdateBanner();
  });

  $("#psnap-up-go").addEventListener("click", () => showUpdateModal());


  // ----------------------------------------------------------------------
  // Update modal — version cards, changelog, one-button install
  // ----------------------------------------------------------------------

  function showUpdateModal() {
    const t = T();
    const u = updateState || {};
    document.getElementById("psnap-um")?.remove();

    const list = (items) => items.map((x, i) =>
      `<li style="animation-delay:${0.18 + i * 0.05}s">${esc(x)}</li>`).join("");

    const hasNew   = (u.added || []).length > 0;
    const hasFixed = (u.fixed || []).length > 0;
    const isLatest = !u.available;

    const el = document.createElement("div");
    el.id = "psnap-um";
    el.className = "psnap-um" + (panel.classList.contains("psnap-light") ? " psnap-um-light" : "");
    el.innerHTML = `
      <div class="psnap-um-box" role="dialog">
        <button class="psnap-um-x" id="psnap-um-x">&times;</button>

        <div class="psnap-um-head">
          <div class="psnap-um-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 19V5"/><path d="M5 12l7-7 7 7"/>
            </svg>
          </div>
          <div class="psnap-um-title">${esc(isLatest ? t.allDone : t.updateAvailable)}</div>
        </div>

        <div class="psnap-um-vers">
          <span class="psnap-um-v psnap-um-old">v${esc(u.current || "?")}</span>
          <span class="psnap-um-arrow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"
                 stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M13 6l6 6-6 6"/></svg>
          </span>
          <span class="psnap-um-v psnap-um-newv">v${esc(u.latest || u.current || "?")}</span>
        </div>

        ${u.notes ? `<div class="psnap-um-notes">${esc(u.notes)}</div>` : ""}

        <div class="psnap-um-body">
          ${hasNew ? `
            <div class="psnap-um-sec psnap-um-sec-new">
              <h4><span class="psnap-um-pill psnap-um-pill-new">+</span>${esc(t.whatsNew)}</h4>
              <ul>${list(u.added)}</ul>
            </div>` : ""}
          ${hasFixed ? `
            <div class="psnap-um-sec psnap-um-sec-fix">
              <h4><span class="psnap-um-pill psnap-um-pill-fix">&#10003;</span>${esc(t.whatsFixed)}</h4>
              <ul>${list(u.fixed)}</ul>
            </div>` : ""}
        </div>

        <div class="psnap-um-foot">
          ${isLatest
            ? `<button class="psnap-btn psnap-primary psnap-um-go" id="psnap-um-close2">${esc(t.close)}</button>`
            : `<button class="psnap-btn psnap-um-later" id="psnap-um-later">${esc(t.later)}</button>
               <button class="psnap-btn psnap-primary psnap-um-go" id="psnap-um-go">
                 <span class="psnap-um-golabel">${esc(t.updateNow)}</span>
               </button>`}
        </div>

        <div class="psnap-um-done" id="psnap-um-done" hidden>
          <div class="psnap-um-check">
            <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 15-16"/></svg>
          </div>
          <div class="psnap-um-donetitle" id="psnap-um-donetitle"></div>
          <div class="psnap-um-donesub" id="psnap-um-donesub"></div>
          <div class="psnap-um-doneact" id="psnap-um-doneact"></div>
        </div>
      </div>
    `;
    document.body.appendChild(el);

    const begin = () => el.classList.add("psnap-um-in");
    requestAnimationFrame(begin);
    setTimeout(begin, 30);

    const close = () => {
      el.classList.remove("psnap-um-in");
      el.classList.add("psnap-um-out");
      setTimeout(() => el.remove(), 320);
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    document.addEventListener("keydown", onKey, true);

    el.querySelector("#psnap-um-x").onclick = close;
    el.querySelector("#psnap-um-close2") && (el.querySelector("#psnap-um-close2").onclick = close);
    el.addEventListener("click", (e) => { if (e.target === el) close(); });

    const later = el.querySelector("#psnap-um-later");
    if (later) later.onclick = () => {
      if (updateState && updateState.latest) {
        updateState = Object.assign({}, updateState, { dismissed: updateState.latest });
        persist({ psnapUpdate: updateState });
        try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
        renderUpdateBanner();
      }
      close();
    };

    const go = el.querySelector("#psnap-um-go");
    if (go) go.onclick = () => runInstall(el, go, close);
  }

  /** The install sequence. Content updates land by themselves; a code
      update starts the download and shows the single remaining step. */
  function runInstall(el, btn, close) {
    const t = T();
    const u = updateState || {};

    btn.disabled = true;
    btn.classList.add("psnap-um-busy");
    btn.querySelector(".psnap-um-golabel").textContent = t.installing;

    const finish = (res) => {
      const lines = [];
      if (res && res.ok) {
        if (res.presets) lines.push(t.contentApplied(res.presets));
        if (res.chips)   lines.push(t.chipsApplied(res.chips));
      }

      const needsReload = !u.content || u.needsReload !== false;

      el.querySelector(".psnap-um-box").classList.add("psnap-um-flip");
      const done = el.querySelector("#psnap-um-done");
      done.hidden = false;
      requestAnimationFrame(() => done.classList.add("psnap-um-done-in"));

      el.querySelector("#psnap-um-donetitle").textContent =
        needsReload ? t.reloadNeeded : t.installed;
      if (needsReload) soundUpdate();
      el.querySelector("#psnap-um-donesub").textContent =
        needsReload ? t.reloadSteps : lines.join(" · ");

      const act = el.querySelector("#psnap-um-doneact");
      if (needsReload) {
        if (u.downloadUrl) {
          const a = document.createElement("a");
          a.href = u.downloadUrl;
          a.download = "";
          a.rel = "noopener";
          a.target = "_blank";
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
        act.innerHTML = `<button class="psnap-btn psnap-primary" id="psnap-um-ext">${esc(t.reloadBtn)}</button>`;
        act.querySelector("#psnap-um-ext").onclick = () => {
          try { chrome.runtime.sendMessage({ type:"psnap-open-extensions" }); } catch(_) {}
        };
      } else {
        // content-only update — fully installed, reload the panel data
        act.innerHTML = `<button class="psnap-btn psnap-primary" id="psnap-um-ok">${esc(t.close)}</button>`;
        act.querySelector("#psnap-um-ok").onclick = () => { close(); reloadData(); };
        soundSuccess();
        setTimeout(() => { close(); reloadData(); }, 3200);
      }
    };

    try {
      chrome.runtime.sendMessage({ type: "psnap-apply-content" }, (res) => finish(res));
    } catch(_) { finish(null); }
  }

  /** Re-read presets and chips after a content update, without a reload. */
  function reloadData() {
    try {
      chrome.storage.local.get(["psnapPresets","psnapCustom"], (r) => {
        if (Array.isArray(r.psnapPresets) && r.psnapPresets.length) presets = r.psnapPresets;
        if (r.psnapCustom && typeof r.psnapCustom === "object") custom = r.psnapCustom;
        state.preset = Math.min(state.preset, presets.length - 1);
        fillPresets(); buildVars(); render();
        renderUpdateBanner();
      });
    } catch(_) {}
  }

  function checkForUpdate(openModal) {
    const t = T();
    const before = (updateState && updateState.latest) || "";
    const btn = $("#set-check");
    if (btn) { btn.textContent = t.checking; btn.disabled = true; }
    try {
      chrome.runtime.sendMessage({ type:"psnap-check-update" }, (res) => {
        if (res) { updateState = res; renderUpdateBanner(); }
        paintUpdateMeta();
        if (btn) { btn.textContent = t.checkNow; btn.disabled = false; }
        if (res && res.error) soundError();
        else if (res && res.available && res.latest !== before) soundUpdate();
        if (openModal) showUpdateModal();
      });
    } catch(_) {
      if (btn) { btn.textContent = t.checkNow; btn.disabled = false; }
    }
  }

  function paintUpdateMeta() {
    const el = $("#set-upmeta");
    if (!el) return;
    const t = T();
    const u = updateState;
    if (!u) { el.textContent = `v${myVersion()}`; return; }
    if (u.error) { el.innerHTML = `v${esc(u.current || myVersion())} · <span class="psnap-up-err">${esc(t.checkFailed)}</span>`; return; }
    const when = u.checkedAt ? new Date(u.checkedAt).toLocaleString() : t.never;
    const status = u.available ? `<span class="psnap-up-new">${esc(t.updateAvailable)}</span>`
                               : esc(t.upToDate);
    el.innerHTML = `v${esc(u.current || myVersion())} · ${status}<br><span class="psnap-up-when">${esc(t.lastChecked)}: ${esc(when)}</span>`;
  }

  // react to a check that finished in the background
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.psnapUpdate) return;
      const prev = changes.psnapUpdate.oldValue || {};
      updateState = changes.psnapUpdate.newValue;
      renderUpdateBanner();
      paintUpdateMeta();
      // announce a genuinely new version, once
      const u = updateState || {};
      if (u.available && u.latest && u.latest !== prev.latest && u.dismissed !== u.latest) {
        soundUpdate();
      }
    });
  } catch(_) {}

  function paintSettings() {
    const t = T();
    $("#set-lbl-sound").textContent = t.sound;
    $("#set-lbl-cel").textContent   = t.celebration;
    $("#set-lbl-theme").textContent = t.theme;

    seg($("#set-sound"), [{val:"on",label:t.on},{val:"off",label:t.off}],
      soundOn ? "on" : "off", v => {
        soundOn = (v === "on");
        persist({ psnapSound: soundOn });
        paintSettings();
        if (soundOn) previewChime();
      });

    seg($("#set-cel"), [
      {val:"full",    label:t.celFull},
      {val:"classic", label:t.celClassic},
      {val:"off",     label:t.celOff}
    ], celebration, v => {
      celebration = v;
      persist({ psnapCel: celebration });
      paintSettings();
      if (v !== "off") previewCelebration();
    });

    $("#set-lbl-updates").textContent = t.updates;
    const chk = $("#set-check");
    chk.textContent = t.checkNow;
    chk.onclick = () => checkForUpdate(true);
    paintUpdateMeta();

    $("#set-lbl-anim").textContent = t.animation;
    seg($("#set-anim"), [
      {val:"full",    label:t.animFull},
      {val:"reduced", label:t.animReduced},
      {val:"minimal", label:t.animMinimal},
      {val:"off",     label:t.animOff}
    ], anim, v => { anim = v; persist({ psnapAnim: anim }); applyAnim(); paintSettings(); });

    seg($("#set-theme"), [
      {val:"dark",  label:t.thDark},
      {val:"light", label:t.thLight},
      {val:"auto",  label:t.thAuto}
    ], theme, v => { theme = v; persist({ psnapTheme: theme }); applyTheme(); paintSettings(); });
  }

  /** Animation level is a class on <html>, so every element the
      extension owns (panel, button, overlays) reads it from one place. */
  function applyAnim() {
    const root = document.documentElement;
    root.classList.remove("psnap-anim-full","psnap-anim-reduced","psnap-anim-minimal","psnap-anim-off");
    root.classList.add("psnap-anim-" + anim);
  }

  /** Cheap gate used by JS-driven effects (confetti counts etc). */
  const animLevel = () => ({ full:3, reduced:2, minimal:1, off:0 })[anim] ?? 3;

  function applyTheme() {
    let effective = theme;
    if (theme === "auto") {
      effective = document.documentElement.classList.contains("light")
        || document.body.classList.contains("light")
        || window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    }
    panel.classList.toggle("psnap-light", effective === "light");
    toast.classList.toggle("psnap-light", effective === "light");
    fabWrap.classList.toggle("psnap-light", effective === "light");
  }

  try {
    window.matchMedia("(prefers-color-scheme: light)")
      .addEventListener("change", () => { if (theme === "auto") applyTheme(); });
  } catch(_) {}

  const persist = (obj) => { try { chrome.storage.local.set(obj); } catch(_) {} };

  // If the tracker ever gets stuck, clicking the status badge clears it.
  $("#psnap-status").addEventListener("click", () => {
    if (tracking || isImageJob) { standDown(); hint(T().hintReset, true); }
  });
  $("#psnap-status").title = "Click to reset the tracker";

  $("#psnap-gear").addEventListener("click", () => {
    const box = $("#psnap-settings");
    box.hidden = !box.hidden;
    $("#psnap-gear").classList.toggle("psnap-gear-open", !box.hidden);
    if (!box.hidden) paintSettings();
  });

  /** Small preview so you can hear/see what you just picked. */
  function previewCelebration() {
    if (celebration === "classic") { burst(); chime(); }
    else { fullScreenCelebration(3, null); chimeBig(); }
  }

  function previewChime() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      [1046.5, 1568.0].forEach((f, i) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.value = f;
        o.connect(g); g.connect(ctx.destination);
        const t0 = ctx.currentTime + i * 0.09;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.18, t0 + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.28);
        o.start(t0); o.stop(t0 + 0.3);
      });
      setTimeout(() => ctx.close(), 900);
    } catch(_) {}
  }

  panel.querySelector("#psnap-langsw").addEventListener("click", e => {
    const b = e.target.closest(".psnap-lang"); if (!b) return;
    lang = b.dataset.lang;
    applyLanguage();
    try { chrome.storage.local.set({ psnapLang: lang }); } catch(_) {}
  });

  // ======================================================================
  // Dynamic fields + suggestion chips
  // ======================================================================

  function varNames(text) {
    const out = []; const re = /\{(\w+)\}/g; let m;
    while ((m = re.exec(text))) if (!RESERVED.has(m[1]) && !out.includes(m[1])) out.push(m[1]);
    return out;
  }
  const suggestionsFor = (n) => [...(SUGGESTIONS[n] || []), ...(custom[n] || [])];

  function buildVars() {
    const t = T();
    const wrap = $("#psnap-vars");
    const names = varNames(presets[state.preset].text);

    wrap.innerHTML = names.map(n => {
      const val  = esc(state.vars[n] || "");
      const big  = (n === "story" || n === "free");
      const sugg = suggestionsFor(n);

      let html = `<div class="psnap-field" data-field="${n}">
        <label class="psnap-label"><span>${esc(fieldLabel(n))}</span>
          ${sugg.length ? `<button class="psnap-sugg-toggle" data-t="${n}">${esc(t.suggestions)}</button>` : ""}
        </label>`;

      html += big
        ? `<textarea data-v="${n}" rows="4" placeholder="${esc(t.ph_story)}">${val}</textarea>`
        : `<input type="text" data-v="${n}" value="${val}" placeholder="${esc(t.ph_typePick)}">`;

      if (sugg.length) {
        const builtIn = (SUGGESTIONS[n] || []).length;
        html += `<div class="psnap-sugg" data-s="${n}" hidden><div class="psnap-chips">` +
          sugg.map((s,i) => {
            const isCustom = i >= builtIn;
            return `<span class="psnap-chip psnap-sm${isCustom ? " psnap-custom" : ""}" `
              + `data-pick="${esc(s)}" data-var="${n}" title="${esc(s)}">${esc(L(s))}`
              + (isCustom ? `<i class="psnap-x" data-del="${esc(s)}" data-var="${n}">&times;</i>` : "")
              + `</span>`;
          }).join("") +
          `</div><div class="psnap-addrow">
            <input type="text" class="psnap-addinput" data-add="${n}" placeholder="${esc(t.addOwn)}">
            <button class="psnap-addbtn" data-addbtn="${n}">${esc(t.save)}</button>
          </div></div>`;
      }
      return html + `</div>`;
    }).join("");

    wrap.querySelectorAll("[data-v]").forEach(el =>
      el.addEventListener("input", () => { state.vars[el.dataset.v] = el.value; render(); save(); }));
    wrap.querySelectorAll(".psnap-addinput").forEach(inp =>
      inp.addEventListener("keydown", e => {
        if (e.key === "Enter") { e.preventDefault(); addCustom(inp.dataset.add, inp.value); }
      }));
    wrap.onclick = onVarClick;
    markChips();
  }

  function markChips() {
    Object.entries(state.vars).forEach(([k,v]) =>
      panel.querySelectorAll(`.psnap-chip[data-var="${k}"]`)
        .forEach(c => c.classList.toggle("psnap-on", c.dataset.pick === v)));
  }

  function onVarClick(e) {
    const t = e.target;

    const tog = t.closest(".psnap-sugg-toggle");
    if (tog) {
      e.preventDefault();
      const box = panel.querySelector(`.psnap-sugg[data-s="${tog.dataset.t}"]`);
      box.hidden = !box.hidden;
      tog.classList.toggle("psnap-on2", !box.hidden);
      return;
    }

    const del = t.closest(".psnap-x");
    if (del) {
      e.stopPropagation();
      const v = del.dataset.var;
      custom[v] = (custom[v] || []).filter(x => x !== del.dataset.del);
      if (state.vars[v] === del.dataset.del) state.vars[v] = "";
      saveCustom(); save(); buildVars(); render();
      return;
    }

    const chip = t.closest(".psnap-chip[data-pick]");
    if (chip) {
      const v = chip.dataset.var, picked = chip.dataset.pick;
      state.vars[v] = (state.vars[v] === picked) ? "" : picked;   // English value
      panel.querySelector(`[data-v="${v}"]`).value = state.vars[v];
      markChips(); render(); save();
      return;
    }

    const add = t.closest(".psnap-addbtn");
    if (add) addCustom(add.dataset.addbtn,
      panel.querySelector(`.psnap-addinput[data-add="${add.dataset.addbtn}"]`).value);
  }

  function addCustom(name, value) {
    const v = (value || "").trim();
    if (!v) return;
    custom[name] = custom[name] || [];
    if (!custom[name].includes(v) && !(SUGGESTIONS[name] || []).includes(v)) custom[name].push(v);
    state.vars[name] = v;
    saveCustom(); save(); buildVars(); render();
    const box = panel.querySelector(`.psnap-sugg[data-s="${name}"]`);
    if (box) {
      box.hidden = false;
      panel.querySelector(`.psnap-sugg-toggle[data-t="${name}"]`)?.classList.add("psnap-on2");
    }
  }

  // ======================================================================
  // Prompt assembly — always English
  // ======================================================================

  function buildPrompt() {
    let t = presets[state.preset].text;
    const vals = { ratio:state.ratio, quality:state.quality, style:state.style, ...state.vars };
    t = t.replace(/\{(\w+)\}/g, (_, k) => {
      const v = (vals[k] ?? "").toString().trim();
      return v || `[${k}]`;
    });
    return t
      .replace(/Aspect ratio Keep original\./g, "Keep the original aspect ratio.")
      .replace(/in Keep original ratio/g, "in its original ratio")
      .replace(/, taken in —/g, "")
      .replace(/taken in —/g, "shot naturally")
      .replace(/in — quality/g, "in high quality")
      .replace(/— quality/g, "high quality")
      .replace(/[ \t]+([.,])/g, "$1")
      .replace(/[ \t]{2,}/g, " ")
      .trim();
  }

  const render = () => { $("#psnap-preview").textContent = buildPrompt(); };

  // ======================================================================
  // Reset
  // ======================================================================

  function doReset(alsoCustom) {
    state = DEFAULT_STATE();
    if (alsoCustom) { custom = {}; saveCustom(); }
    save();
    fillPresets(); fillSelects(); paintRatios(); buildVars(); render();
    panel.querySelector(".psnap-body").scrollTop = 0;
    hint(alsoCustom ? T().hintResetAll : T().hintReset, true);
    const btn = $("#psnap-reset");
    btn.classList.add("psnap-spun");
    setTimeout(() => btn.classList.remove("psnap-spun"), 600);
  }

  // ======================================================================
  // Insert into composer
  // ======================================================================

  const findComposer = () =>
    document.querySelector("#prompt-textarea") ||
    document.querySelector('div[contenteditable="true"][id*="prompt"]') ||
    document.querySelector('form div[contenteditable="true"]') ||
    document.querySelector("form textarea");

  function writeToComposer(text) {
    const box = findComposer();
    if (!box) return null;
    box.focus();
    if (box.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      setter.call(box, (box.value ? box.value + "\n\n" : "") + text);
      box.dispatchEvent(new Event("input", { bubbles:true }));
    } else {
      document.execCommand("insertText", false, text);
      box.dispatchEvent(new InputEvent("input", { bubbles:true }));
    }
    return box;
  }

  function insertPrompt() {
    const text = buildPrompt();
    if (!writeToComposer(text)) {
      navigator.clipboard.writeText(text);
      hint(T().hintNoComposer, true);
      return;
    }
    hideBubble();
    hint(T().hintInserted, true);
  }

  const findSendButton = () =>
    document.querySelector('button[data-testid="send-button"]') ||
    document.querySelector('button[aria-label*="Send prompt" i]') ||
    document.querySelector('button[aria-label*="Send message" i]') ||
    document.querySelector('button[aria-label*="Send" i]') ||
    document.querySelector('form button[type="submit"]');

  function sendPrompt() {
    const text = buildPrompt();
    const box = writeToComposer(text);
    if (!box) {
      navigator.clipboard.writeText(text);
      hint(T().hintNoComposer, true);
      soundError();
      return;
    }
    hideBubble();

    // let React register the new value before we fire the button
    setTimeout(() => {
      const btn = findSendButton();
      if (btn && !btn.disabled) {
        btn.click();
        armTracker();
        hint(T().hintSent, true);
        return;
      }
      // fallback: synthesise Enter in the composer
      const ev = (type) => new KeyboardEvent(type, {
        key:"Enter", code:"Enter", keyCode:13, which:13, bubbles:true, cancelable:true
      });
      box.focus();
      box.dispatchEvent(ev("keydown"));
      box.dispatchEvent(ev("keypress"));
      box.dispatchEvent(ev("keyup"));

      setTimeout(() => {
        const stillThere = (box.value || box.textContent || "").includes(text.slice(0, 40));
        if (stillThere) { hint(T().hintSendFail, false); soundError(); }
        else { armTracker(); hint(T().hintSent, true); }
      }, 450);
    }, 140);
  }

  let hintTimer;
  const hintDefault = () => {
    const el = $("#psnap-hint");
    el.classList.remove("psnap-note");
    el.textContent = T().hintDefault;
  };
  function hint(msg, good) {
    const el = $("#psnap-hint");
    el.textContent = msg;
    el.classList.toggle("psnap-note", !!good);
    clearTimeout(hintTimer);
    hintTimer = setTimeout(hintDefault, 4200);
  }

  // ======================================================================
  // "Need a Help?" bubble
  // ======================================================================

  let bubbleTimer;
  function showBubble() {
    if (panel.classList.contains("psnap-open")) return;
    const t = T();
    fabWrap.querySelector("#psnap-bubble-text").textContent =
      (window.innerWidth < 900 && t.needHelpShort) ? t.needHelpShort : t.needHelp;
    bubble.classList.add("psnap-bubble-show");
    fab.classList.add("psnap-nudge");
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(hideBubble, 9000);
  }
  function hideBubble() {
    bubble.classList.remove("psnap-bubble-show");
    fab.classList.remove("psnap-nudge");
    clearTimeout(bubbleTimer);
  }
  bubble.addEventListener("click", (e) => {
    if (e.target.id === "psnap-bubble-x") { e.stopPropagation(); hideBubble(); return; }
    hideBubble(); openPanel();
  });

  // ======================================================================
  // Generation tracker
  //
  // Only fires for IMAGE generation, never for plain text replies.
  // The rule: we do not commit to "this is an image job" until we have
  // seen hard evidence — ChatGPT's own % badge, or an image that shows up
  // inside an ASSISTANT message. Until then every image on the page
  // (including the one the user just uploaded, which renders instantly in
  // their own message bubble) is added to the ignore set every tick.
  // That upload is what used to make it shout "finished in 1s".
  // ======================================================================

  const origTitle = document.title.replace(/^[^\w\u1780-\u17FF]*\s*/, "");
  const SPIN = ["\u25F7","\u25F6","\u25F5","\u25F4"];

  let tracking = false;
  let isImageJob = false;      // committed only on real evidence
  let startedAt = 0, spinIx = 0, tickTimer = null;
  let pct = null, pctSeenAt = 0, everSawPct = false, endedAt = 0;
  let finishing = false;
  const pendingLoads = new WeakSet();
  // Capped so a very long conversation can't grow this without bound.
  const seenImages = new Set();
  const SEEN_MAX = 400;
  function rememberImage(k) {
    if (seenImages.size > SEEN_MAX) {
      // drop the oldest quarter
      const it = seenImages.values();
      for (let i = 0; i < SEEN_MAX / 4; i++) seenImages.delete(it.next().value);
    }
    seenImages.add(k);
  }

  const imgKey = (img) => (img.currentSrc || img.src || "").slice(0, 300);

  /** Every image currently on the page becomes "already known". */
  let _imgCache = { at: 0, list: [] };
  function mainImages() {
    const now = Date.now();
    if (now - _imgCache.at < 200) return _imgCache.list;
    const main = document.querySelector("main");
    _imgCache = { at: now, list: main ? [...main.querySelectorAll("img")] : [] };
    return _imgCache.list;
  }

  function markKnownImages() {
    _imgCache.at = 0;
    for (const i of mainImages()) {
      const k = imgKey(i);
      if (k) rememberImage(k);
    }
  }

  /** Blacklist ONLY images that can never be a generated result — the
      user's own uploads and the composer attachment strip. Used while
      we're still deciding whether this is an image job, so a fast result
      doesn't get blacklisted before we commit. */
  function markUserImages() {
    for (const i of mainImages()) {
      const k = imgKey(i);
      if (!k) continue;
      if (inUserTurn(i) || /avatar|profile|icon|favicon/i.test(k)) seenImages.add(k);
    }
  }

  let _genCache = { at: 0, val: false };
  function isGenerating() {
    const now = Date.now();
    if (now - _genCache.at < 200) return _genCache.val;
    const v = !!(
      document.querySelector('button[data-testid="stop-button"]') ||
      document.querySelector('button[aria-label*="Stop" i]') ||
      document.querySelector('[data-testid*="generating" i]')
    );
    _genCache = { at: now, val: v };
    return v;
  }

  /** Is this node inside a message the USER wrote? */
  function inUserTurn(el) {
    return !!el.closest('[data-message-author-role="user"]')
        || !!el.closest('[data-testid*="conversation-turn"][data-testid*="user"]')
        || !!el.closest("form");                       // composer attachment strip
  }

  /** Does this page even use author-role markers? */
  function hasRoleMarkup() {
    return !!document.querySelector('[data-message-author-role]');
  }

  /** Is this node inside an assistant reply?
      If ChatGPT isn't using role markers on this view (image results are
      often rendered in their own container outside the message wrapper),
      we fall back to "anywhere in main that isn't the user's turn". */
  function inAssistantTurn(el) {
    if (el.closest('[data-message-author-role="assistant"]')) return true;
    if (inUserTurn(el)) return false;
    return !!el.closest("main");
  }

  /* ---- ChatGPT's live % badge ----------------------------------------
     Leaf elements inside <main> whose ENTIRE text is a number + %, and
     which are actually visible. A "50%" inside prose won't match. */
  let _pctEl = null;                 // last element that held the badge
  let _pctCache = { at: 0, val: null };

  function readPercentUncached() {
    // Fast path: the badge usually stays in the same element between
    // ticks, so check the one we already found before scanning again.
    if (_pctEl && _pctEl.isConnected) {
      const m = /^(\d{1,3})\s*%$/.exec((_pctEl.textContent || "").trim());
      if (m) {
        const v = Number(m[1]);
        if (v >= 0 && v <= 100) return v;
      }
      _pctEl = null;
    }

    const main = document.querySelector("main");
    if (!main) return null;

    // Walk text nodes instead of querySelectorAll on every div/span/p.
    // Far cheaper: we only touch nodes that actually contain text.
    const walker = document.createTreeWalker(main, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const s = n.nodeValue;
        if (!s || s.length > 5) return NodeFilter.FILTER_REJECT;
        return /^\s*\d{1,3}\s*%\s*$/.test(s)
          ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });

    let node, last = null;
    let guard = 0;
    while ((node = walker.nextNode()) && ++guard < 600) last = node;
    if (!last) return null;

    const el = last.parentElement;
    if (!el || inUserTurn(el)) return null;
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return null;

    const v = Number(/(\d{1,3})/.exec(last.nodeValue)[1]);
    if (v < 0 || v > 100) return null;
    _pctEl = el;
    return v;
  }

  /** Cached wrapper — several call sites ask per tick; one scan is enough. */
  function readPercent() {
    const now = Date.now();
    if (now - _pctCache.at < 250) return _pctCache.val;
    const v = readPercentUncached();
    _pctCache = { at: now, val: v };
    return v;
  }

  /** Other hints that an image is being produced. */
  let _hintedImage = false;
  function imageJobHint() {
    if (readPercent() !== null) { _hintedImage = true; return true; }
    const main = document.querySelector("main");
    if (!main) return false;
    if (main.querySelector('[data-testid*="image-gen" i], [class*="image-gen" i]')) return true;
    // the assistant's own status line, e.g. "Generating a more detailed image"
    const turns = main.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (last && /generating (a |an )?(more detailed )?image|creating (your |the )?image/i
          .test((last.textContent || "").slice(0, 400))) return true;
    return false;
  }

  /** A genuinely new, large image that is not the user's own upload. */
  function newAssistantImage() {
    for (const img of mainImages()) {
      const k = imgKey(img);
      if (!k || seenImages.has(k)) continue;
      if (inUserTurn(img))      { seenImages.add(k); continue; }
      if (!inAssistantTurn(img)) { seenImages.add(k); continue; }
      if (/avatar|profile|icon|favicon|\.svg(\?|$)/i.test(k)) { seenImages.add(k); continue; }

      // Size check only once the image has actually decoded. An image that
      // hasn't loaded yet reports 0 — rejecting it there was making real
      // results get blacklisted before they ever had a size.
      if (img.complete && img.naturalWidth) {
        if (img.naturalWidth < 200) { seenImages.add(k); continue; }
        return img;
      }
      const r = img.getBoundingClientRect();
      if (r.width >= 150 || !img.complete) return img;
      seenImages.add(k);
    }
    return null;
  }

  /** Last resort: the largest image on the page that isn't the user's. */
  function bestVisibleImage() {
    let best = null, area = 0;
    for (const img of mainImages()) {
      if (inUserTurn(img)) continue;
      const k = imgKey(img);
      if (/avatar|profile|icon|favicon/i.test(k)) continue;
      const r = img.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area) { area = a; best = img; }
    }
    return area > 22500 ? best : null;   // at least ~150x150
  }

  let armedAt = 0;
  const ARM_WINDOW = 5 * 60 * 1000;

  /** Called the moment we press Send, so we're listening early. */
  function armTracker() {
    armedAt = Date.now();
    _hintedImage = true;
    markKnownImages();
    setTimeout(markKnownImages, 300);   // catch the upload thumbnail too
    setTimeout(markKnownImages, 900);
  }

  const recentlyArmed = () => armedAt && (Date.now() - armedAt) < ARM_WINDOW;

  /** Safety net for when we never noticed the job starting. */
  function rescueCheck() {
    if (tracking || finishing || !recentlyArmed()) return;
    const img = newAssistantImage();
    if (!img) return;
    if (!(img.complete && img.naturalWidth >= 200)) return;
    // treat as a completed job that we simply never saw begin
    tracking = true;
    isImageJob = true;
    everSawPct = true;                 // bypass the fast-finish guard
    startedAt = startedAt || Date.now() - 2000;
    finishTracking(img);
  }

  function startTracking() {
    if (tracking) return;
    tracking = true;
    isImageJob = false;
    everSawPct = false;
    startedAt = Date.now();
    pct = null; pctSeenAt = 0; endedAt = 0; finishing = false; _hintedImage = false;
    markKnownImages();
    tickTimer = setInterval(tick, 400);
    tick();
  }

  /** Switch from "something is happening" to "this is an image job". */
  function commitImageJob() {
    if (isImageJob) return;
    isImageJob = true;
    fab.classList.add("psnap-working");
    fab.classList.remove("psnap-done");
    hideBubble();
    setProgress(null);
    paintBar(null);
  }

  function setProgress(p) {
    const ring = fabWrap.querySelector("#psnap-fab-ring");
    const lab  = fabWrap.querySelector("#psnap-fab-pct");
    if (!ring || !lab) return;
    if (p === null || p === undefined) {
      fab.classList.remove("psnap-haspct");
      ring.style.background = "";
      lab.textContent = "";
    } else {
      fab.classList.add("psnap-haspct");
      const deg = Math.max(0, Math.min(100, p)) * 3.6;
      ring.style.background =
        `conic-gradient(var(--ps-ring) 0deg ${deg}deg, rgba(255,255,255,.15) ${deg}deg 360deg)`;
      lab.textContent = p + "%";
    }
  }

  function tick() {
    const t = T();
    const elapsed = Date.now() - startedAt;

    const read = readPercent();
    if (read !== null) {
      if (pct === null || read >= pct || read === 0) pct = read;
      pctSeenAt = Date.now();
      everSawPct = true;
      commitImageJob();
    } else if (pct !== null && Date.now() - pctSeenAt > 4000) {
      pct = null;
    }

    if (!isImageJob) {
      markUserImages();
      // a large new image showing up on its own is evidence enough
      if (imageJobHint() || newAssistantImage()) commitImageJob();
      if (!isGenerating() && elapsed > 2500) {
        if (_hintedImage) checkRefusal();
        standDown();
      }
      return;
    }

    // ---- completion check, run every tick -----------------------------
    // The MutationObserver can go quiet once the image finishes painting,
    // which used to leave the tracker spinning forever. Polling here means
    // we always notice.
    const fresh = newAssistantImage();
    if (fresh) {
      if (fresh.complete && fresh.naturalWidth) { finishTracking(fresh); return; }
      if (!pendingLoads.has(fresh)) {
        pendingLoads.add(fresh);
        fresh.addEventListener("load",  () => finishTracking(fresh), { once:true });
        fresh.addEventListener("error", () => { seenImages.add(imgKey(fresh)); }, { once:true });
      }
    }

    // ---- watchdog -----------------------------------------------------
    // Generation has clearly stopped: no stop button, no % badge.
    const quiet = !isGenerating() && read === null;
    if (quiet) {
      if (!endedAt) endedAt = Date.now();
      const since = Date.now() - endedAt;

      // give the image a moment to appear, then settle it one way or another
      if (since > 1800) {
        const candidate = fresh || bestVisibleImage();
        if (candidate && (everSawPct || elapsed > 4000)) {
          finishTracking(candidate);
        } else if (checkRefusal()) {
          standDown();
        } else if (since > 6000) {
          standDown();
        }
        return;
      }
    } else {
      endedAt = 0;
    }

    // hard ceiling so it can never spin forever
    if (elapsed > 300000) { standDown(); return; }

    const s = Math.floor(elapsed / 1000);
    const clock = `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
    const st = $("#psnap-status");

    setProgress(pct);

    if (pct !== null) {
      document.title = `${pct}% — ${t.tabGenerating} | ${origTitle}`;
      if (st) {
        st.className = "psnap-working-badge psnap-clickable";
        st.innerHTML = `<span class="psnap-pctnum">${pct}%</span> <span class="psnap-clock">${clock}</span>`;
      }
      paintBar(pct);
    } else {
      spinIx = (spinIx + 1) % SPIN.length;
      const phase = elapsed < 4000 ? t.starting : t.rendering;
      document.title = `${SPIN[spinIx]} ${clock} — ${phase} | ${origTitle}`;
      if (st) {
        st.className = "psnap-working-badge psnap-clickable";
        st.innerHTML = `${SPIN[spinIx]} <span class="psnap-clock">${clock}</span>`;
      }
      paintBar(null);
    }
  }

  /** Did the assistant refuse? Called when a job ends with no image. */
  function checkRefusal() {
    if (!isImageJob && !everSawPct) return false;   // wasn't an image job
    const txt = lastAssistantText();
    if (!looksRefused(txt)) return false;
    // pull the sentence that matched, for the alert body
    const sent = (txt.split(/(?<=[.!?])\s+/).filter(x => looksRefused(x))[0] || "").trim();
    showBlocked(sent.length > 12 && sent.length < 220 ? sent : "");
    return true;
  }

  /** Quietly reset — no sound, no toast, no celebration. */
  function standDown() {
    stopTicker();
    endedAt = 0;
    finishing = false;
    isImageJob = false;
    document.title = origTitle;
    fab.classList.remove("psnap-working", "psnap-haspct");
    setProgress(null);
    clearBar(false);
    const st = $("#psnap-status");
    if (st) { st.className = ""; st.textContent = ""; }
  }

  function stopTicker() { tracking = false; clearInterval(tickTimer); }

  function paintBar(p) {
    let bar = panel.querySelector("#psnap-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "psnap-bar";
      bar.innerHTML = "<i></i>";
      panel.insertBefore(bar, panel.firstChild);
    }
    const fill = bar.firstElementChild;
    if (p === null) {
      bar.classList.add("psnap-bar-on", "psnap-bar-indet");
      fill.style.width = "";
    } else {
      bar.classList.add("psnap-bar-on");
      bar.classList.remove("psnap-bar-indet");
      fill.style.width = p + "%";
    }
  }
  function clearBar(done) {
    const bar = panel.querySelector("#psnap-bar");
    if (!bar) return;
    bar.classList.remove("psnap-bar-indet");
    if (done) {
      bar.firstElementChild.style.width = "100%";
      bar.classList.add("psnap-bar-done");
      setTimeout(() => bar.classList.remove("psnap-bar-on","psnap-bar-done"), 900);
    } else {
      bar.classList.remove("psnap-bar-on");
      bar.firstElementChild.style.width = "0%";
    }
  }

  function finishTracking(img) {
    // guards: must be a committed image job, and not suspiciously instant
    if (finishing) return;
    if (!tracking || !isImageJob) return;
    const elapsed = Date.now() - startedAt;
    if (elapsed < 1500 && !everSawPct) return;
    finishing = true;
    endedAt = 0;

    const secs = Math.max(1, Math.round(elapsed / 1000));

    setProgress(100);
    paintBar(100);
    stopTicker();
    isImageJob = false;

    setTimeout(() => {
      fab.classList.remove("psnap-working", "psnap-haspct");
      setProgress(null);
      fab.classList.add("psnap-done");
      clearBar(true);
    }, 420);

    const st = $("#psnap-status");
    if (st) { st.className = "psnap-done-badge"; st.textContent = T().ready; }

    document.title = `\u2705 ${T().tabReady} | ${origTitle}`;
    setTimeout(() => { if (!tracking) document.title = origTitle; }, 12000);

    if (img) {
      lastImageUrl = img.currentSrc || img.src || "";
      refreshCanvaTabs();
    }

    celebrate(secs, img);
    setTimeout(() => fab.classList.remove("psnap-done"), 7000);
  }

  // ----------------------------------------------------------------------
  // Celebration
  // ----------------------------------------------------------------------

  function celebrate(secs, img) {
    if (celebration === "off") { chime(); if (img) flashImage(img); return; }

    if (celebration === "classic") {
      showToast(secs);
      burst();
      chime();
      if (document.hidden) notify(secs);
      if (img) flashImage(img);
      return;
    }

    // with animation off, use the quiet toast instead of the overlay
    if (animLevel() === 0) { showToast(secs); chimeBig(); notify(secs); return; }

    // full screen — fall back to the toast if anything goes wrong so a
    // finished job is never completely silent
    let ok = false;
    try { ok = fullScreenCelebration(secs, img); } catch(_) { ok = false; }
    if (!ok) showToast(secs);
    chimeBig();
    notify(secs);
    if (img) flashImage(img);
  }

  function showToast(secs) {
    const t = T();
    document.getElementById("psnap-toast-title").textContent = t.imageReady;
    document.getElementById("psnap-toast-sub").textContent = secs ? t.finishedIn(secs) : t.jumpToIt;
    toast.classList.add("psnap-toast-show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove("psnap-toast-show"), 8000);
  }

  toast.addEventListener("click", () => {
    toast.classList.remove("psnap-toast-show");
    jumpToLastImage();
  });

  function jumpToLastImage() {
    const imgs = [...document.querySelectorAll("main img")]
      .filter(i => (i.naturalWidth || 0) >= 220 && inAssistantTurn(i));
    imgs[imgs.length - 1]?.scrollIntoView({ behavior:"smooth", block:"center" });
  }

  function flashImage(img) {
    const holder = img.closest("div") || img;
    holder.classList.add("psnap-flash");
    setTimeout(() => holder.classList.remove("psnap-flash"), 2800);
    if (document.visibilityState === "visible") img.scrollIntoView({ behavior:"smooth", block:"center" });
  }

  /** Full-viewport finish sequence. */
  function fullScreenCelebration(secs, img) {
    if (!document.body) return false;
    const t = T();
    const old = document.getElementById("psnap-cel");
    if (old) old.remove();

    const src = img ? (img.currentSrc || img.src || "") : "";
    const el = document.createElement("div");
    el.id = "psnap-cel";
    el.className = "psnap-cel" + (theme === "light" ? " psnap-cel-light" : "");
    el.innerHTML = `
      <div class="psnap-cel-glow"></div>
      <div class="psnap-cel-rings"><i></i><i></i><i></i></div>
      <div class="psnap-cel-card">
        ${src ? `<div class="psnap-cel-thumb"><img src="${src.replace(/"/g,"&quot;")}" alt=""></div>` : ""}
        <div class="psnap-cel-check">
          <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 15-16"/></svg>
        </div>
        <div class="psnap-cel-title">${esc(t.celTitle)}</div>
        <div class="psnap-cel-sub">${esc(t.celSub(secs))}</div>
        <div class="psnap-cel-hint">${esc(t.celDismiss)}</div>
      </div>
      <div class="psnap-cel-confetti"></div>
    `;
    document.body.appendChild(el);

    // confetti
    const wrap = el.querySelector(".psnap-cel-confetti");
    const colors = ["#14c294","#7ee8c6","#ffd479","#ff9f6e","#8bd3ff","#ffffff"];
    const count = { 3:70, 2:34, 1:14, 0:0 }[animLevel()];
    for (let i = 0; i < count; i++) {
      const p = document.createElement("i");
      p.style.left = Math.random() * 100 + "%";
      p.style.background = colors[i % colors.length];
      p.style.animationDelay = (Math.random() * 0.7) + "s";
      p.style.animationDuration = (1.9 + Math.random() * 1.6) + "s";
      p.style.setProperty("--spin", (Math.random() * 720 - 360) + "deg");
      p.style.setProperty("--drift", (Math.random() * 160 - 80) + "px");
      const sz = 6 + Math.random() * 7;
      p.style.width = sz + "px";
      p.style.height = (sz * (Math.random() > .5 ? 1 : 0.45)) + "px";
      if (Math.random() > .6) p.style.borderRadius = "50%";
      wrap.appendChild(p);
    }

    // "Send to Canva" appears on the card once a design tab is open
    const acts = el.querySelector("#psnap-cel-acts");
    if (acts && lastImageUrl) {
      refreshCanvaTabs(() => {
        if (!canvaTabs.length || !document.body.contains(el)) return;
        acts.innerHTML =
          `<button class="psnap-cel-btn" id="psnap-cel-canva">
             <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
               <path d="M5 12h13M13 6l6 6-6 6"/></svg>
             <span>${esc(t.sendToCanva)}</span>
           </button>`;
        acts.classList.add("psnap-cel-acts-in");
        acts.querySelector("#psnap-cel-canva").onclick = (ev) => {
          ev.stopPropagation();
          const b = ev.currentTarget;
          const lbl = b.querySelector("span");
          b.disabled = true;
          lbl.textContent = t.sending;
          try {
            chrome.runtime.sendMessage(
              { type:"psnap-canva-send", tabId: canvaTabs[0].id, imageUrl: lastImageUrl },
              (res) => {
                if (res && res.ok) { lbl.textContent = t.sentToCanva; soundSuccess(); }
                else { lbl.textContent = t.canvaFail; soundError(); b.disabled = false; }
              });
          } catch(_) { lbl.textContent = t.canvaFail; soundError(); b.disabled = false; }
        };
      });
    }

    // rAF is paused in background tabs — use a timer as well so the
    // animation always starts, and never rely on rAF alone.
    const begin = () => el.classList.add("psnap-cel-in");
    setTimeout(begin, 30);

    const close = () => {
      el.dispatchEvent(new CustomEvent("psnap-closed"));
      el.classList.remove("psnap-cel-in");
      el.classList.add("psnap-cel-out");
      setTimeout(() => el.remove(), 420);
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    document.addEventListener("keydown", onKey, true);
    el.addEventListener("click", (e) => {
      if (e.target.closest(".psnap-cel-thumb")) { close(); jumpToLastImage(); return; }
      close();
    });
    // Auto-dismiss only counts time while the tab is actually visible.
    let autoTimer = null;
    const startAutoClose = () => {
      clearTimeout(autoTimer);
      autoTimer = setTimeout(() => {
        if (el.querySelector("#psnap-cel-canva")) return;   // a send is on offer
        if (document.body.contains(el)) close();
      }, 6000);
    };
    const onVis = () => {
      if (document.hidden) { clearTimeout(autoTimer); }
      else { begin(); startAutoClose(); }
    };
    document.addEventListener("visibilitychange", onVis);
    el.addEventListener("psnap-closed", () => {
      clearTimeout(autoTimer);
      document.removeEventListener("visibilitychange", onVis);
    });
    if (!document.hidden) startAutoClose();
    return true;
  }

  /** Small particle burst from the floating button (classic mode). */
  function burst() {
    const r = fab.getBoundingClientRect();
    const colors = ["#14c294","#7ee8c6","#ffd479","#ffffff","#0d8e6f"];
    const layer = document.createElement("div");
    layer.className = "psnap-burst";
    const n = { 3:16, 2:9, 1:5, 0:0 }[animLevel()];
    if (!n) return;
    for (let i = 0; i < n; i++) {
      const p = document.createElement("i");
      const ang = (Math.PI * 2 * i) / n + Math.random() * 0.4;
      const dist = 46 + Math.random() * 46;
      p.style.setProperty("--dx", Math.cos(ang) * dist + "px");
      p.style.setProperty("--dy", Math.sin(ang) * dist + "px");
      p.style.background = colors[i % colors.length];
      p.style.animationDelay = (Math.random() * 90) + "ms";
      if (i % 3 === 0) p.style.borderRadius = "2px";
      layer.appendChild(p);
    }
    layer.style.left = (r.left + r.width/2) + "px";
    layer.style.top  = (r.top + r.height/2) + "px";
    document.body.appendChild(layer);
    setTimeout(() => layer.remove(), 1400);
  }

  // ----------------------------------------------------------------------
  // Sound
  // ----------------------------------------------------------------------

  // One shared context, resumed on demand. Creating a fresh one per
  // chime meant Chrome sometimes handed back a suspended context that
  // played nothing at all, silently.
  let _ctx = null;
  function audioCtx() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!_ctx || _ctx.state === "closed") _ctx = new Ctx();
    if (_ctx.state === "suspended") _ctx.resume().catch(() => {});
    return _ctx;
  }

  // Unlock audio on the first interaction anywhere on the page.
  ["pointerdown","keydown"].forEach(ev =>
    document.addEventListener(ev, function unlock() {
      try { audioCtx(); } catch(_) {}
      document.removeEventListener(ev, unlock, true);
    }, { capture:true, once:true }));

  function reverb(ctx, seconds, wetLevel) {
    const conv = ctx.createConvolver();
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random()*2-1) * Math.pow(1 - i/len, 2.6);
    }
    conv.buffer = buf;
    const wet = ctx.createGain();
    wet.gain.value = wetLevel;
    conv.connect(wet); wet.connect(ctx.destination);
    return conv;
  }

  /** Shared voice builder — one oscillator with an envelope. */
  function voice(ctx, opts) {
    const { freq, start, dur, type = "sine", peak = 0.3, to = null, dest } = opts;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, start);
    if (to) o.frequency.exponentialRampToValueAtTime(to, start + dur * 0.9);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(peak, start + Math.min(0.02, dur * 0.15));
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(dest.master);
    if (dest.conv) g.connect(dest.conv);
    o.start(start);
    o.stop(start + dur + 0.05);
    return o;
  }

  function bus(gain, revSecs, revWet) {
    const ctx = audioCtx();
    const master = ctx.createGain();
    master.gain.value = gain;
    master.connect(ctx.destination);
    const conv = revSecs ? reverb(ctx, revSecs, revWet) : null;
    return { ctx, master, conv, now: ctx.currentTime };
  }

  /** Classic finish: four-note rising arpeggio. */
  function chime() {
    if (!soundOn) return;
    try {
      const d = bus(0.22, 1.1, 0.3);
      [1046.5, 1318.5, 1568.0, 2093.0].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + i*0.085, dur: i===3 ? 0.85 : 0.42,
                       type: i===3 ? "triangle" : "sine", peak: i===3 ? 0.5 : 0.34, dest:d }));
    } catch(_) {}
  }

  /** Full-screen finish: shimmer sweep into a held major chord. */
  function chimeBig() {
    if (!soundOn) return;
    try {
      const d = bus(0.2, 1.8, 0.42);
      voice(d.ctx, { freq:420, to:2400, start:d.now, dur:0.4, peak:0.14, dest:d });
      [523.25, 659.25, 783.99, 1046.5, 1174.7].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + 0.28 + i*0.07, dur:1.5,
                       type: i>2 ? "triangle" : "sine", peak:0.3, dest:d }));
      voice(d.ctx, { freq:130.8, start:d.now + 0.28, dur:1.6, peak:0.26, dest:{ master:d.master } });
    } catch(_) {}
  }

  /** UPDATE DETECTED — two soft rising taps, like a gentle notification. */
  function soundUpdate() {
    if (!soundOn) return;
    try {
      const d = bus(0.17, 1.2, 0.34);
      voice(d.ctx, { freq:987.77,  start:d.now,        dur:0.3, type:"sine",     peak:0.3,  dest:d });
      voice(d.ctx, { freq:1318.51, start:d.now + 0.14, dur:0.55, type:"triangle", peak:0.34, dest:d });
      // faint bell tail
      voice(d.ctx, { freq:2637.02, start:d.now + 0.16, dur:0.7, type:"sine",     peak:0.07, dest:d });
    } catch(_) {}
  }

  /** UPDATE SUCCEEDED — confident four-note resolve, brighter than the
      finish chime so the two never get confused. */
  function soundSuccess() {
    if (!soundOn) return;
    try {
      const d = bus(0.21, 1.6, 0.4);
      // G  B  D  G' — clean major resolve
      [783.99, 987.77, 1174.66, 1567.98].forEach((f, i) =>
        voice(d.ctx, { freq:f, start:d.now + i*0.075, dur: i===3 ? 1.1 : 0.5,
                       type: i===3 ? "triangle" : "sine",
                       peak: i===3 ? 0.42 : 0.28, dest:d }));
      voice(d.ctx, { freq:196, start:d.now + 0.05, dur:1.2, peak:0.2, dest:{ master:d.master } });
    } catch(_) {}
  }

  /** FAILED — low descending pair. Deliberately soft, not a buzzer. */
  function soundError() {
    if (!soundOn) return;
    try {
      const d = bus(0.19, 0.7, 0.22);
      voice(d.ctx, { freq:392,    start:d.now,        dur:0.26, type:"triangle", peak:0.3,  dest:d });
      voice(d.ctx, { freq:293.66, start:d.now + 0.15, dur:0.5,  type:"triangle", peak:0.34, dest:d });
      voice(d.ctx, { freq:146.83, start:d.now + 0.15, dur:0.55, type:"sine",     peak:0.18,
                     dest:{ master:d.master } });
    } catch(_) {}
  }

  function notify(secs) {
    try {
      if (!document.hidden) return;
      if (!("Notification" in window)) return;
      if (Notification.permission === "granted") {
        new Notification("PromptSnap", { body: T().notifyBody(secs) });
      } else if (Notification.permission !== "denied") Notification.requestPermission();
    } catch(_) {}
  }

  // ----------------------------------------------------------------------
  // Watchers
  // ----------------------------------------------------------------------

  // The observer fires in bursts while a reply streams. Collapse each
  // burst into one pass on the next frame instead of running the whole
  // check hundreds of times a second.
  let _pending = false;
  const onMutations = () => {
    if (_pending) return;
    _pending = true;
    requestAnimationFrame(() => { _pending = false; scanNow(); });
  };

  function scanNow() {
    if (!tracking) {
      if (isGenerating() || readPercent() !== null) { startTracking(); return; }
      rescueCheck();
      return;
    }
    if (!isImageJob) return;               // wait for commitment
    const img = newAssistantImage();
    if (img) {
      img.complete ? finishTracking(img)
                   : img.addEventListener("load", () => finishTracking(img), { once:true });
      return;
    }
    if (!isGenerating() && readPercent() === null && Date.now() - startedAt > 4000) standDown();
  }

  const watcher = new MutationObserver(onMutations);

  function startWatching() {
    watcher.observe(document.querySelector("main") || document.body,
      { childList:true, subtree:true, characterData:true, attributes:true, attributeFilter:["src"] });
    markKnownImages();
  }
  startWatching();
  setTimeout(startWatching, 3000);

  // Idle poll. Backs off to 3s when the tab is hidden and pauses
  // entirely when the page has been idle, so it costs almost nothing.
  let idleTimer = null;
  function scheduleIdlePoll() {
    clearTimeout(idleTimer);
    const gap = document.hidden ? 3000 : 1200;
    idleTimer = setTimeout(() => {
      if (!tracking) {
        if (readPercent() !== null) startTracking();
        else rescueCheck();
      }
      scheduleIdlePoll();
    }, gap);
  }
  scheduleIdlePoll();

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && !tracking) document.title = origTitle;
    // reset caches on return so nothing stale is used
    _pctCache = { at: 0, val: null };
    _genCache = { at: 0, val: false };
    _imgCache = { at: 0, list: [] };
  });

  // ======================================================================
  // Open / close / drag / paste detection
  // ======================================================================

  const openPanel  = () => {
    panel.classList.add("psnap-open");
    hideBubble();
    render();
    renderUpdateBanner();
    refreshCanvaTabs();
    try { chrome.runtime.sendMessage({ type:"psnap-clear-badge" }); } catch(_) {}
  };
  const closePanel = () => panel.classList.remove("psnap-open");
  const togglePanel = () => panel.classList.contains("psnap-open") ? closePanel() : openPanel();

  fab.addEventListener("click", togglePanel);
  $("#psnap-close").addEventListener("click", closePanel);
  $("#psnap-copy").addEventListener("click", () => {
    navigator.clipboard.writeText(buildPrompt()); hint(T().hintCopied, true);
  });
  $("#psnap-insert").addEventListener("click", insertPrompt);
  $("#psnap-send").addEventListener("click", sendPrompt);
  $("#psnap-reset").addEventListener("click", (e) => doReset(e.shiftKey));

  presetSel.addEventListener("change", () => { state.preset = Number(presetSel.value); buildVars(); render(); save(); });
  qualSel .addEventListener("change", () => { state.quality = qualSel.value; render(); save(); });
  styleSel.addEventListener("change", () => { state.style   = styleSel.value; render(); save(); });

  // Pressing Enter in the composer counts as a send, so arm the tracker
  // even when the prompt wasn't inserted by us.
  document.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
      const c = findComposer();
      if (c && (e.target === c || c.contains(e.target))) armTracker();
    }
  }, true);

  document.addEventListener("keydown", e => {
    if (e.ctrlKey && e.shiftKey && e.code === "Space") { e.preventDefault(); togglePanel(); }
    if (e.ctrlKey && e.key === "Enter" && panel.classList.contains("psnap-open")) {
      e.preventDefault(); sendPrompt();
    }
    if (e.key === "Escape") { if (panel.classList.contains("psnap-open")) closePanel(); hideBubble(); }
  });

  (function drag() {
    const head = $("#psnap-head");
    let sx, sy, sl, st, on = false;
    head.addEventListener("mousedown", e => {
      if (e.target.closest("button")) return;
      const r = panel.getBoundingClientRect();
      Object.assign(panel.style, { left:r.left+"px", top:r.top+"px", right:"auto", bottom:"auto" });
      sx=e.clientX; sy=e.clientY; sl=r.left; st=r.top; on=true; e.preventDefault();
    });
    document.addEventListener("mousemove", e => {
      if (!on) return;
      panel.style.left = Math.max(0, sl + e.clientX - sx) + "px";
      panel.style.top  = Math.max(0, st + e.clientY - sy) + "px";
    });
    document.addEventListener("mouseup", () => { on = false; });
  })();

  function sawImage() {
    if (panel.classList.contains("psnap-open")) { hint(T().hintDetected, true); return; }
    showBubble();
  }
  document.addEventListener("paste", e => {
    const items = e.clipboardData && e.clipboardData.items; if (!items) return;
    for (const it of items) if (it.type && it.type.startsWith("image/")) { sawImage(); break; }
  }, true);
  document.addEventListener("drop", e => {
    const f = e.dataTransfer && e.dataTransfer.files;
    if (f && [...f].some(x => x.type.startsWith("image/"))) sawImage();
  }, true);
  // file picker route
  document.addEventListener("change", e => {
    const t = e.target;
    if (t && t.type === "file" && t.files && [...t.files].some(f => f.type.startsWith("image/"))) sawImage();
  }, true);

  // ======================================================================
  // Persistence
  // ======================================================================

  const save       = () => { try { chrome.storage.local.set({ psnapState: state }); } catch(_){} };
  const saveCustom = () => { try { chrome.storage.local.set({ psnapCustom: custom }); } catch(_){} };

  function boot() {
    const apply = (r = {}) => {
      if (Array.isArray(r.psnapPresets) && r.psnapPresets.length) presets = r.psnapPresets;
      if (r.psnapCustom && typeof r.psnapCustom === "object") custom = r.psnapCustom;
      if (r.psnapState) state = Object.assign(DEFAULT_STATE(), r.psnapState);
      if (r.psnapLang === "km" || r.psnapLang === "en") lang = r.psnapLang;
      if (typeof r.psnapSound === "boolean") soundOn = r.psnapSound;
      if (["full","classic","off"].includes(r.psnapCel))   celebration = r.psnapCel;
      if (["dark","light","auto"].includes(r.psnapTheme))  theme = r.psnapTheme;
      if (["full","reduced","minimal","off"].includes(r.psnapAnim)) anim = r.psnapAnim;
      applyAnim();
      if (typeof r.psnapFeed === "string") feedUrl = r.psnapFeed;
      if (r.psnapUpdate) updateState = r.psnapUpdate;
      applyTheme();
      renderUpdateBanner();
      paintCanva();
      applyLanguage();
    };
    try { chrome.storage.local.get(
        ["psnapState","psnapPresets","psnapCustom","psnapLang",
         "psnapSound","psnapCel","psnapTheme","psnapFeed","psnapUpdate","psnapAnim"], apply); }
    catch(_) { apply(); }
  }
  boot();
})();
