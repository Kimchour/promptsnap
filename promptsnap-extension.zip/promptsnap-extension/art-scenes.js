/* PromptSnap — preview scenes
 * The things the before → after previews show (art.js draws them and
 * applies the effects). Each scene draws itself in a 160×100 box with
 * colours from the palette it is given, so every effect and time of day
 * works on all of them. See art.js for the contract and the portrait.
 */

/* ---- group ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Group: three friends, head-and-shoulders, in a park.
     Options: eyesClosed (true) — the LEFT person blinks (closed lids).
     extra: a waving passer-by peeking in at the left edge. */
  A.scene("group", (P, o, h) => {
    o = o || {};
    const shut = o.eyesClosed === true;
    // a line-art pass only finds strong light/dark edges, and the shirts are as light as the
    // hills behind them: under that style each figure gets a thin light rim so it reads as a line
    const ink = o.style === "lineart";

    /* ---------- background: park with trees, hedge, lawn ---------- */
    const tree = (x, y, r) =>
      `<rect x="${x - 1.8}" y="${y}" width="3.6" height="${78 - y}" rx="1.6" fill="${P.wood2}"/>` +
      `<circle cx="${x}" cy="${y}" r="${r}" fill="${P.near}"/>` +
      `<circle cx="${x - r * .32}" cy="${y - r * .3}" r="${r * .62}" fill="${P.mid}"/>`;
    // a string of party lights across the top
    const bulbs = [8, 22, 36, 50, 64, 80, 96, 110, 124, 138, 152];
    const sag = (x) => 9 + 9 * Math.sin(Math.PI * x / 160);
    const lights =
      `<path d="M0 8 Q80 28 160 8" stroke="${P.metal3}" stroke-width=".5" fill="none" opacity=".8"/>` +
      bulbs.map((x, i) => {
        const y = sag(x) + 1.4, c = [P.accent, P.sun, P.accent2, P.light][i % 4];
        return (P.night ? `<circle cx="${x}" cy="${y}" r="3.2" fill="${P.lamp}" opacity=".22"/>` : "") +
               `<ellipse cx="${x}" cy="${y}" rx="1.3" ry="1.7" fill="${P.night ? P.lamp : c}"/>`;
      }).join("");
    const bg =
      `${h.sky(P)}${h.stars(P)}${h.sunOrMoon(P, 140, 22, 6)}${h.cloud(P, 30, 24, .7)}${h.cloud(P, 104, 22, .5)}` +
      `<path d="M0 60 Q12 50 24 55 Q36 46 50 53 Q64 45 78 52 Q92 44 106 52 Q120 46 132 53 Q146 46 160 52 V100 H0Z" fill="${P.far}"/>` +
      tree(12, 46, 15) + tree(150, 44, 15) +
      `<path d="M0 74 Q20 68 40 72 T80 71 T120 72 T160 70 V100 H0Z" fill="${P.mid}"/>` +
      `<path d="M0 84 Q80 77 160 84 V100 H0Z" fill="${P.ground}"/>` +
      lights;

    /* ---------- one head-and-shoulders person, face centred at 0,0 ---------- */
    const person = (x, y, s, c) => {
      const sk = c.skin, hr = c.hair;
      // silhouette pieces (fill added where they are drawn)
      const back = c.style === "long" ? `<path d="M-14.5 -1 C-16 -21 16 -21 14.5 -1 C15.5 10 15 18 13 23 L-13 23 C-15 18 -15.5 10 -14.5 -1Z"`
                 : c.style === "bun" ? `<circle cx="1" cy="-16.5" r="6.2"` : "";
      const torso = `<path d="M-30 66 C-29 37 -17 25 0 25 C17 25 29 37 30 66Z"`;
      const skull = `<path d="M-14.2 1.5a2.4 3.4 0 1 0 4.8 0a2.4 3.4 0 1 0 -4.8 0ZM9.4 1.5a2.4 3.4 0 1 0 4.8 0a2.4 3.4 0 1 0 -4.8 0ZM-12 0a12 14.5 0 1 0 24 0a12 14.5 0 1 0 -24 0Z"`;
      let g = `<g transform="translate(${x} ${y}) scale(${s})">`;
      if (ink) g += `<g fill="${P.light}" stroke="${P.light}" stroke-width="${+(1.6 / s).toFixed(2)}" stroke-linejoin="round">${back ? back + "/>" : ""}${torso}/>${skull}/></g>`;
      // hair that falls behind the head
      if (back) g += `${back} fill="${hr}"/>`;
      // shoulders + a darker far side
      g += `${torso} fill="${c.cloth}"/>`;
      g += `<path d="M13 26.5 C24 31 29.5 42 30 66 H21 C21.5 46 19 33 13 26.5Z" fill="${P.shade}"/>`;
      // neck with a shadow under the chin
      g += `<path d="M-5.5 8 H5.5 V24 Q0 28 -5.5 24Z" fill="${sk}"/><path d="M-5.5 9 H5.5 V14 Q0 17.5 -5.5 14Z" fill="${P.shade}"/>`;
      // neckline
      if (c.neck === "v") g += `<path d="M-7 25.5 L0 36 L7 25.5 Q0 29 -7 25.5Z" fill="${P.light}" opacity=".92"/><path d="M0 36 V66" stroke="${c.cloth2}" stroke-width="1.1"/>`;
      if (c.neck === "round") g += `<path d="M-7.5 25.3 Q0 33 7.5 25.3" stroke="${c.cloth2}" stroke-width="1.6" fill="none" stroke-linecap="round"/>`;
      if (c.neck === "scarf") g += `<path d="M-9 24 Q0 31 9 24 L10 28 Q0 36 -10 28Z" fill="${c.cloth2}"/><path d="M3 31 L6 44 L1 44Z" fill="${c.cloth2}"/>`;
      // ears + head
      g += `${skull} fill="${sk}"/>`;
      // hair on top
      if (c.style === "long")
        g += `<path d="M-12.8 -1 C-13.5 -17 12.5 -18.5 13 -3 C9 -9 1 -11.5 -5 -8.5 C-8.5 -6.5 -11.5 -4 -12.8 -1Z" fill="${hr}"/>`;
      else if (c.style === "short")
        g += `<path d="M-12.6 -1.5 C-14 -18 11 -21.5 12.9 -4.5 C11.8 -8.6 8.6 -10.4 4.6 -10 C-.6 -12.6 -7.4 -10.8 -10.2 -6.6 C-11.6 -5 -12.3 -3.4 -12.6 -1.5Z" fill="${hr}"/>` +
             `<path d="M-12.4 -3 L-11.6 4 L-10.6 -2Z" fill="${hr}"/><path d="M12.4 -3 L11.6 4 L10.6 -2Z" fill="${hr}"/>`;
      else
        g += `<path d="M-12.6 0 C-14 -17.5 13.6 -17.5 12.6 0 C11 -7 6 -10.5 0 -10.5 C-6 -10.5 -11 -7 -12.6 0Z" fill="${hr}"/>`;
      // a soft shine on the hair (also keeps dark hair readable at night)
      g += `<path d="M-8 -9.5 Q-2 -13.6 5 -11.6" stroke="${P.light}" stroke-width="1.6" stroke-linecap="round" fill="none" opacity="${P.night ? .22 : .2}"/>`;
      if (c.style === "bun") g += `<path d="M-2.4 -19 Q0 -21.6 3 -21" stroke="${P.light}" stroke-width="1.3" stroke-linecap="round" fill="none" opacity=".22"/>`;
      // brows
      g += `<g stroke="${hr}" stroke-width="1.1" stroke-linecap="round" fill="none" opacity=".85"><path d="M-7.2 -3.6 Q-5 -4.8 -2.8 -3.8"/><path d="M2.8 -3.8 Q5 -4.8 7.2 -3.6"/></g>`;
      // eyes: open, or gently closed lids
      g += c.shut
        ? `<g fill="none" stroke="${P.ink}" stroke-width="1.6" stroke-linecap="round"><path d="M-8 .2 Q-5 4 -2 .2"/><path d="M2 .2 Q5 4 8 .2"/></g>`
        : `<g fill="${P.ink}"><ellipse cx="-5" cy="1" rx="1.55" ry="1.95"/><ellipse cx="5" cy="1" rx="1.55" ry="1.95"/></g>`;
      // smile + cheeks
      g += `<path d="M-4.3 7.4 Q0 10.8 4.3 7.4" stroke="${P.lip}" stroke-width="1.5" fill="none" stroke-linecap="round"/>`;
      g += `<g fill="${P.accent}" opacity=".22"><circle cx="-8" cy="5.4" r="2.6"/><circle cx="8" cy="5.4" r="2.6"/></g>`;
      return g + `</g>`;
    };

    const left = person(43, 49, .95, { skin: P.skin, hair: P.wood2, style: "long", cloth: P.cloth3, cloth2: P.wood2, neck: "round", shut });
    const right = person(117, 49, .95, { skin: P.skin2, hair: P.ink, style: "bun", cloth: P.cloth4, cloth2: P.cloth2, neck: "scarf" });
    const centre = person(80, 45, 1.12, { skin: P.skin, hair: P.hair, style: "short", cloth: P.cloth, cloth2: P.cloth2, neck: "v" });
    // the centre person stands a step forward: a soft shadow falls on the other two
    const drop = `<g transform="translate(80 45) scale(1.12)" fill="${P.shade}"><path d="M-33.5 66 C-33 40 -22 29 -10 27 H10 C22 29 33 40 33.5 66Z"/></g>`;
    const subject = `<g>${left}${right}${drop}${centre}</g>`;

    /* ---------- extra: a passer-by waving into the shot at the left edge ---------- */
    const extra =
      `<g transform="translate(11 41) scale(.64)">` +
      // raised waving arm
      `<path d="M14 26 C20 14 23 0 25 -14" stroke="${P.cloth2}" stroke-width="6" stroke-linecap="round" fill="none"/>` +
      `<ellipse cx="25.5" cy="-17" rx="4" ry="4.6" fill="${P.skin2}"/>` +
      // hoodie (darker far side) with its hood bunched behind the neck
      `<path d="M-30 70 C-29 37 -17 25 0 25 C17 25 29 37 30 70Z" fill="${P.cloth2}"/>` +
      `<path d="M13 26.5 C24 31 29.5 42 30 70 H21 C21.5 46 19 33 13 26.5Z" fill="${P.shade}"/>` +
      `<path d="M-10 26 Q0 34 10 26 Q0 22 -10 26Z" fill="${P.metal3}"/>` +
      `<path d="M-5.5 8 H5.5 V24 Q0 28 -5.5 24Z" fill="${P.skin2}"/>` +
      `<ellipse cx="0" cy="0" rx="12" ry="14.5" fill="${P.skin2}"/>` +
      // cap with a peak
      `<path d="M-13 -2 C-14 -18 14 -18 13 -2Z M-1 -4 H21 Q22 -1 18 0 H-1Z" fill="${P.cloth3}"/>` +
      `<g fill="${P.ink}"><ellipse cx="-4.5" cy="2.5" rx="1.7" ry="2.1"/><ellipse cx="5" cy="2.5" rx="1.7" ry="2.1"/></g>` +
      `<ellipse cx="0" cy="9" rx="2.4" ry="2.8" fill="${P.ink}" opacity=".8"/>` +
      `</g>`;

    return { bg, subject, extra, face: { x: 80, y: 45, r: 17 } };
  });
})();

/* ---- pet ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Pet: a happy corgi-like dog sitting on a garden lawn, three-quarter view.
     extra: a red toy ball on the grass to the left. */
  A.scene("pet", (P, o, h) => {
    o = o || {};

    /* ---------- background: garden with a picket fence ---------- */
    // all pickets in ONE path; a soft grey-white so the dog's cream chest stays separate
    let pk = "";
    for (let x = -3; x < 164; x += 10) pk += `M${x} 72 V56 L${x + 3} 52.5 L${x + 6} 56 V72Z`;
    // circles as subpaths, so many dots of one colour are a single <path>
    const dots = (pts, r) => pts.map(([x, y]) => `M${x - r} ${y}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0Z`).join("");
    // flower clumps along the fence: leaves in one path, blossoms per colour
    const clumps = [[9, 71], [21, 72], [31, 70], [125, 71], [137, 72], [149, 70]];
    const bloom = (pts, c) => `<path d="${dots(pts.map(([x, y]) => [x, y - 1.4]), 1.6)}" fill="${c}"/>`;
    const flies = [[22, 46], [40, 38], [126, 40], [146, 50], [112, 30]];
    const fireflies = P.night
      ? `<g fill="${P.lamp}"><path d="${dots(flies, 2.6)}" opacity=".22"/><path d="${dots(flies, .9)}"/></g>` : "";
    const bg =
      `${h.sky(P)}${h.stars(P)}${h.sunOrMoon(P, 130, 18, 7)}${h.cloud(P, 34, 18, .8)}${h.cloud(P, 92, 12, .5)}` +
      `<path d="M0 54 Q30 40 62 48 T120 44 T160 46 V100 H0Z" fill="${P.far}"/>` +
      // bushes behind the fence
      `<g fill="${P.mid}"><circle cx="14" cy="52" r="11"/><circle cx="32" cy="55" r="9"/><circle cx="128" cy="53" r="10"/><circle cx="148" cy="50" r="12"/></g>` +
      // fence rails + pickets
      `<path d="M0 58.5h160v2.6H0ZM0 66h160v2.6H0Z" fill="${P.wall2}"/>` +
      `<path d="${pk}" fill="${P.wall2}"/>` +
      // lawn
      `<path d="M0 72 H160 V100 H0Z" fill="${P.ground}"/>` +
      `<path d="M0 72 H160 V74.6 Q80 77.4 0 74.6Z" fill="${P.shade}"/>` +
      `<path d="${dots(clumps, 3.4)}" fill="${P.mid}"/>` +
      bloom([[9, 71], [125, 71]], P.accent) + bloom([[21, 72], [149, 70]], P.sun) + bloom([[31, 70], [137, 72]], P.light) +
      `<path d="M14 92 l2 -5 l2 5z M134 94 l2 -6 l2 6z M148 86 l1.6 -4 l1.6 4z M28 98 l1.6 -4 l1.6 4z" fill="${P.mid}" opacity=".8"/>` +
      fireflies;

    /* ---------- subject: the dog ---------- */
    const fur = P.skin2, fur2 = P.wood, fur3 = P.wood2, cream = P.paper;
    // The big silhouette shapes, kept apart so a line-art pass can ink them: that filter only
    // finds strong light/dark edges, and the tan fur sits on a lawn of the same lightness.
    const tail = `<path d="M104 78 C112 76 116 68 115 60 C114 56 118 54 120 57 C123 64 119 78 108 82Z" fill="${fur2}"/>`;
    const body = `<path d="M64 87 C60 70 64 53 77 49 C91 45 106 54 109 70 C111 81 105 88 96 88 H66Z" fill="${fur}"/>`;
    const haunch = `<ellipse cx="99" cy="76" rx="14" ry="12.5" fill="${fur}"/>`;
    const farLeg = `<rect x="77.5" y="68" width="7.4" height="20" rx="3.4" fill="${fur2}"/>`;
    const nearLeg = `<rect x="66.5" y="68" width="8" height="20.5" rx="3.6" fill="${fur}"/>`;
    const ears = `<path d="M57.5 33 L58.5 15.5 Q59.5 12 62.6 13.6 L72 27Z M74 26.5 L85.5 12.6 Q88.4 10.6 89.4 14.2 L88.6 33Z" fill="${fur}"/>`;
    const head = `<ellipse cx="73" cy="37" rx="15" ry="12.4" fill="${fur}"/>`;
    const muzzle = `<ellipse cx="66" cy="43" rx="9" ry="6.6" fill="${cream}"/>`;
    const ink = o.style === "lineart";
    const contour = (shapes) => ink ? `<g stroke="${P.light}" stroke-width="1.6" stroke-linejoin="round">${shapes}</g>` : "";
    const subject =
      `<g transform="translate(5 0)">` +
      h.shadow(88, 89.5, 30, 4.2, .2) +
      contour(tail + body + haunch + farLeg + nearLeg + ears + head + muzzle) +
      // tail (fluffy, behind)
      tail +
      `<path d="M115.4 60.6 C115 56.4 118.4 54.6 120 57.4 C121.4 60.6 121 64 119.6 67 C118.6 64.6 116.6 62.4 115.4 60.6Z" fill="${cream}" opacity=".9"/>` +
      // body + haunch (sitting back leg)
      body + haunch +
      `<path d="M86 79 C88 88 100 90 110 84 C110 88 104 89 98 89 H88Z" fill="${fur2}" opacity=".55"/>` +
      `<path d="M92 66 C98 63 106 66 109 72" stroke="${fur2}" stroke-width="1.4" fill="none" stroke-linecap="round" opacity=".7"/>` +
      `<path d="M88 88.6 C88 84.6 92 84 96.6 84.4 C100.6 84.8 101.4 88.6 99 88.6Z" fill="${cream}"/>` +
      `<path d="M94.6 88.4 v-2 M97.4 88.4 v-2" stroke="${P.wall2}" stroke-width=".6" stroke-linecap="round"/>` +
      // cream chest bib
      `<path d="M67 50 C61 58 61 73 66 85 H80 C82 72 84 60 82 51Z" fill="${cream}"/>` +
      `<path d="M64 51 Q73 58 84 51 L83.4 56 Q73 62 64.6 56Z" fill="${P.shade}"/>` +
      `<path d="M80.4 54 C82.6 62 82 74 79.6 85 H82 C84.6 74 85 62 82.4 52Z" fill="${fur2}" opacity=".35"/>` +
      // front legs (near + far) with cream paws
      farLeg +
      `<rect x="78" y="78" width="6.6" height="10" rx="3" fill="${cream}"/>` +
      nearLeg +
      `<rect x="66.5" y="77" width="8" height="11.5" rx="3.6" fill="${cream}"/>` +
      `<path d="M69 88 v-2.4 M72 88 v-2.4" stroke="${P.wall2}" stroke-width=".7" stroke-linecap="round"/>` +
      // collar + tag
      `<path d="M63 50.5 Q74 57 86 49.5" stroke="${P.cloth3}" stroke-width="3.2" fill="none" stroke-linecap="round"/>` +
      `<circle cx="72.5" cy="56.8" r="2.2" fill="${P.sun}"/><circle cx="72.5" cy="56.8" r="1" fill="${fur3}" opacity=".35"/>` +
      // ears (big and upright)
      ears +
      `<path d="M60 29 L60.6 18.4 Q61.2 16.4 63 17.4 L68.6 26Z M77.4 26.6 L85.6 16.6 Q87.2 15.4 87.6 17.6 L87 30Z" fill="${fur3}" opacity=".55"/>` +
      // head
      head +
      `<path d="M80 26 C88 28 90 38 86 46 C84 48 80 49 78 48 C83 42 84 32 80 26Z" fill="${fur2}" opacity=".45"/>` +
      // cream blaze + muzzle
      `<path d="M69.5 26 C67 30 66 35 66.5 38 L73 38 C72.4 34 72 30 72 26Z" fill="${cream}"/>` +
      muzzle +
      // tongue, mouth, nose
      `<path d="M63.4 46 Q63.4 52.6 66.8 52.6 Q70 52.6 69.6 46Z" fill="${P.lip}"/>` +
      `<path d="M66.6 47 V50.4" stroke="${fur3}" stroke-width=".6" opacity=".5"/>` +
      `<path d="M58.6 43.6 Q62 47.4 66.6 46 Q70.4 47.4 73.4 44.4" stroke="${P.ink}" stroke-width="1.1" fill="none" stroke-linecap="round"/>` +
      `<path d="M62.4 41 V45.6" stroke="${P.ink}" stroke-width="1" stroke-linecap="round"/>` +
      `<ellipse cx="61.6" cy="40" rx="3.4" ry="2.5" fill="${P.ink}"/><ellipse cx="60.6" cy="39.2" rx="1.1" ry=".6" fill="${P.light}" opacity=".7"/>` +
      // eyes with a sparkle
      `<g fill="${P.ink}"><ellipse cx="65.2" cy="33.6" rx="2" ry="2.4"/><ellipse cx="78.4" cy="33.6" rx="2.2" ry="2.6"/></g>` +
      `<g fill="${P.light}"><circle cx="65.9" cy="32.7" r=".75"/><circle cx="79.2" cy="32.6" r=".8"/></g>` +
      `<g fill="${P.accent}" opacity=".2"><circle cx="81" cy="41" r="3"/></g>` +
      `</g>`;

    /* ---------- extra: a red toy ball on the grass ---------- */
    const extra =
      `<g transform="translate(44 83) scale(1.12)">${h.shadow(0, 6.2, 8, 1.8, .2)}` +
      contour(`<circle cx="0" cy="0" r="6.4" fill="${P.cloth3}"/>`) +
      `<circle cx="0" cy="0" r="6.4" fill="${P.cloth3}"/>` +
      `<path d="M-5.6 -2.6 Q0 1.6 5.8 -2.4" stroke="${P.light}" stroke-width="1.5" fill="none" opacity=".85"/>` +
      `<path d="M0 6.4 A6.4 6.4 0 0 0 6.4 0 A6.4 6.4 0 0 1 -3.8 5.1Z" fill="${P.shade}"/>` +
      `<circle cx="-2.4" cy="-3.2" r="1.6" fill="${P.light}" opacity=".45"/>` +
      `</g>`;

    return { bg, subject, extra, face: { x: 77, y: 38, r: 15 } };
  });
})();

/* ---- podium ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Podium: a speaker at a lectern with two microphones, press-conference style.
     Option court (true): a courtroom — wood-panelled wall, judge's bench, gavel,
     and the person is a judge in robes behind the bench.
     extra: an aide standing to the left holding a folder. */
  A.scene("podium", (P, o, h) => {
    o = o || {};
    const court = o.court === true;
    // a line-art pass only finds strong light/dark edges; under that style the figures and
    // furniture get a thin light rim (drawn beneath them) so their outlines come through
    const ink = o.style === "lineart";
    const rim = (shapes, w = 1.6) => ink ? `<g fill="${P.light}" stroke="${P.light}" stroke-width="${w}" stroke-linejoin="round">${shapes}</g>` : "";
    // people and furniture sit a little closer to camera than the wall
    const Z = `translate(80 94) scale(1.08) translate(-80 -94)`;

    /* ---------- shared pieces ---------- */
    // a generic flag: one colour, a fold, and a ring emblem (never a real nation's flag)
    const flag = (x, c1, c2) =>
      `<rect x="${x - .8}" y="8" width="1.6" height="78" rx=".8" fill="${P.metal2}"/>` +
      `<circle cx="${x}" cy="7.4" r="1.8" fill="${P.sun}"/>` +
      `<rect x="${x - 2.6}" y="84" width="5.2" height="3" rx="1" fill="${P.metal3}"/>` +
      `<path d="M${x + .8} 11 H${x + 12} C${x + 13.5} 24 ${x + 11.5} 38 ${x + 12.5} 48 C${x + 9} 51 ${x + 4} 50 ${x + .8} 47Z" fill="${c1}"/>` +
      `<path d="M${x + 7.6} 11 H${x + 12} C${x + 13.5} 24 ${x + 11.5} 38 ${x + 12.5} 48 C${x + 11} 49.4 ${x + 9.4} 50 ${x + 8} 50 C${x + 9} 38 ${x + 8.6} 24 ${x + 7.6} 11Z" fill="${c2}" opacity=".5"/>` +
      `<circle cx="${x + 6.6}" cy="27" r="3.4" fill="none" stroke="${P.sun}" stroke-width="1.3"/>` +
      `<circle cx="${x + 6.6}" cy="27" r="1.1" fill="${P.sun}"/>`;
    const head = (x, y, s, c) => {
      const skull = `<path d="M-13.9 1.5a2.3 3.3 0 1 0 4.6 0a2.3 3.3 0 1 0 -4.6 0ZM9.3 1.5a2.3 3.3 0 1 0 4.6 0a2.3 3.3 0 1 0 -4.6 0ZM-12 0a12 14.5 0 1 0 24 0a12 14.5 0 1 0 -24 0Z"`;
      const crown = `<path d="M-12.6 -1 C-14 -18 11.4 -21 12.9 -4 C11.6 -8.8 8 -10.6 3.6 -10.2 C-1.4 -12 -7.6 -10.6 -10.4 -6.4 C-11.8 -4.8 -12.4 -3 -12.6 -1Z"`;
      let g = `<g transform="translate(${x} ${y}) scale(${s})">`;
      g += rim(`${skull}/>${crown}/>`, +(1.6 / s).toFixed(2));
      g += `<path d="M-5 8 H5 V22 Q0 26 -5 22Z" fill="${P.skin}"/><path d="M-5 9 H5 V13.6 Q0 17 -5 13.6Z" fill="${P.shade}"/>`;
      g += `${skull} fill="${P.skin}"/>`;
      g += `${crown} fill="${c.hair}"/>`;
      g += `<path d="M-12.4 -3 L-11.6 4 L-10.6 -2Z M12.4 -3 L11.6 4 L10.6 -2Z" fill="${c.hair}"/>`;
      g += `<path d="M-8 -9.6 Q-2 -13.8 5 -11.8" stroke="${P.light}" stroke-width="1.6" stroke-linecap="round" fill="none" opacity=".2"/>`;
      g += `<g stroke="${c.brow || c.hair}" stroke-width="1.1" stroke-linecap="round" fill="none" opacity=".85"><path d="M-7.2 -3.6 Q-5 -4.8 -2.8 -3.8"/><path d="M2.8 -3.8 Q5 -4.8 7.2 -3.6"/></g>`;
      g += `<g fill="${P.ink}"><ellipse cx="-5" cy="1" rx="1.55" ry="1.95"/><ellipse cx="5" cy="1" rx="1.55" ry="1.95"/></g>`;
      g += c.talk
        ? `<path d="M-3.6 7.2 Q0 12.4 3.6 7.2Z" fill="${P.lip}"/>`
        : `<path d="M-4.2 7.6 Q0 10.4 4.2 7.6" stroke="${P.lip}" stroke-width="1.5" fill="none" stroke-linecap="round"/>`;
      g += `<g fill="${P.accent}" opacity=".2"><circle cx="-8" cy="5.4" r="2.5"/><circle cx="8" cy="5.4" r="2.5"/></g>`;
      return g + `</g>`;
    };
    const mic = (x1, y1, x2, y2, cx, cy) =>
      `<path d="M${x1} ${y1} Q${cx} ${cy} ${x2} ${y2}" stroke="${P.metal3}" stroke-width="1.2" fill="none" stroke-linecap="round"/>` +
      `<rect x="${x2 - 2.1}" y="${y2 - 5.6}" width="4.2" height="6.4" rx="2.1" fill="${P.ink}"/>` +
      `<rect x="${x2 - 2.1}" y="${y2 - 1}" width="4.2" height="1.2" fill="${P.metal2}"/>`;

    let bg, subject;
    if (!court) {
      /* ---------- press room ---------- */
      let marks = "";
      for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) {
        const x = 46 + c * 14 + (r % 2) * 7, y = 25 + r * 11;
        if (x > 116) continue;
        marks += `M${x - 2.6} ${y}a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0ZM${x - 1.2} ${y}a1.2 1.2 0 1 1 2.4 0a1.2 1.2 0 1 1 -2.4 0Z`;
      }
      const spots = [38, 80, 122].map((x) =>
        `<rect x="${x - 3}" y="0" width="6" height="3.4" rx="1.2" fill="${P.metal3}"/>` +
        (P.night ? `<path d="M${x - 2.4} 3.4 L${x - 14} 82 H${x + 14} L${x + 2.4} 3.4Z" fill="${P.lamp}" opacity=".1"/><ellipse cx="${x}" cy="3.8" rx="3.4" ry="1.4" fill="${P.lamp}"/>` : `<ellipse cx="${x}" cy="3.6" rx="2.6" ry="1" fill="${P.light}" opacity=".8"/>`)).join("");
      bg =
        `<rect width="160" height="100" fill="${P.wall}"/>` +
        `<rect y="0" width="160" height="6" fill="${P.wall2}"/>` +
        // backdrop panel with a repeating logo pattern (no text)
        `<rect x="38" y="10" width="84" height="74" rx="6" fill="${P.cloth2}"/>` +
        `<rect x="38" y="10" width="84" height="7" rx="3.5" fill="${P.cloth}"/>` +
        `<path d="${marks}" fill="${P.light}" fill-rule="evenodd" opacity=".16"/>` +
        (P.night ? `<ellipse cx="80" cy="46" rx="40" ry="34" fill="${P.lamp}" opacity=".1"/>` : "") +
        flag(8, P.cloth3, P.wood2) + flag(140, P.cloth3, P.wood2) +
        // stage
        `<rect y="82" width="160" height="18" fill="${P.floor}"/>` +
        `<rect y="82" width="160" height="1.6" fill="${P.shade}"/>` +
        `<rect y="95" width="160" height="5" fill="${P.wall2}"/>` +
        `<rect y="95" width="160" height="1" fill="${P.shade}"/>` +
        (P.night ? `<ellipse cx="80" cy="89" rx="44" ry="6" fill="${P.lamp}" opacity=".14"/>` : "") +
        spots;

      const suit = P.metal3, suit2 = P.cloth2;
      subject =
        `<g transform="${Z}">` +
        h.shadow(80, 93, 24, 2.6, .25) +
        rim(`<path d="M58 67 C56 55 65 48 80 48 C95 48 104 55 102 67Z"/><path d="M62 66 H98 L95 94 H65Z M58 61.6 H102 L100 67.6 H60Z"/>`) +
        // body in a suit
        `<path d="M58 67 C56 55 65 48 80 48 C95 48 104 55 102 67Z" fill="${suit}"/>` +
        `<path d="M93 49.4 C100 51.4 103.4 57 102 67 H96 C97 59 96 53 93 49.4Z" fill="${P.shade}"/>` +
        `<path d="M72.6 48.6 L80 62 L87.4 48.6 Q80 51 72.6 48.6Z" fill="${P.light}"/>` +
        `<path d="M78.7 51.2 L80 49.8 L81.3 51.2 L80.9 53 L82.2 61 L80 63.6 L77.8 61 L79.1 53Z" fill="${P.cloth3}"/>` +
        `<path d="M72.6 48.6 L80 62 L76.4 64.4 L69.6 50.6Z" fill="${suit2}" opacity=".55"/>` +
        `<path d="M87.4 48.6 L80 62 L83.6 64.4 L90.4 50.6Z" fill="${suit2}" opacity=".55"/>` +
        head(80, 33, .95, { hair: P.hair, talk: true }) +
        // lectern
        `<path d="M62 66 H98 L95 94 H65Z" fill="${P.wood2}"/>` +
        `<path d="M86 66 H98 L95 94 H87Z" fill="${P.shade}"/>` +
        `<path d="M58 61.6 H102 L100 67.6 H60Z" fill="${P.wood}"/>` +
        `<path d="M58 61.6 H102 L101.6 63 H58.4Z" fill="${P.light}" opacity=".25"/>` +
        // hands on the lectern
        `<ellipse cx="66.4" cy="61.8" rx="3.6" ry="2.4" fill="${P.skin}"/><ellipse cx="93.6" cy="61.8" rx="3.6" ry="2.4" fill="${P.skin}"/>` +
        // emblem on the lectern front (rings, no text)
        `<circle cx="80" cy="78" r="6.4" fill="${P.sun}" opacity=".9"/><circle cx="80" cy="78" r="4.6" fill="${P.wood2}"/><circle cx="80" cy="78" r="2.6" fill="${P.sun}" opacity=".9"/>` +
        // two microphones
        mic(77, 62, 74, 52.6, 75, 58) + mic(83, 62, 86, 52.6, 85, 58) +
        `</g>`;
    } else {
      /* ---------- courtroom ---------- */
      const panels = [];
      for (let c = 0; c < 6; c++) {
        const x = 3 + c * 26.2;
        panels.push(`<rect x="${x}" y="12" width="22" height="30" rx="2" fill="${P.wood2}" opacity=".28"/><rect x="${x + 2}" y="14" width="18" height="26" rx="1.4" fill="${P.light}" opacity=".07"/>` +
                    `<rect x="${x}" y="46" width="22" height="30" rx="2" fill="${P.wood2}" opacity=".28"/><rect x="${x + 2}" y="48" width="18" height="26" rx="1.4" fill="${P.light}" opacity=".07"/>`);
      }
      const sconce = (x) =>
        (P.night ? `<circle cx="${x}" cy="28" r="11" fill="${P.lamp}" opacity=".16"/><circle cx="${x}" cy="28" r="5.5" fill="${P.lamp}" opacity=".28"/>` : "") +
        `<rect x="${x - 1}" y="29" width="2" height="5" fill="${P.metal3}"/>` +
        `<path d="M${x - 3.6} 30 Q${x} 23 ${x + 3.6} 30Z" fill="${P.night ? P.lamp : P.paper}"/>`;
      bg =
        `<rect width="160" height="100" fill="${P.wood}"/>` +
        panels.join("") +
        `<rect y="0" width="160" height="7" fill="${P.wood2}"/><rect y="7" width="160" height="1.4" fill="${P.light}" opacity=".18"/>` +
        `<rect y="78" width="160" height="4" fill="${P.wood2}"/>` +
        // a wash of the room's light colour so time-of-day palettes still read on the wood
        `<rect width="160" height="82" fill="${P.wall}" opacity="${P.night ? .22 : .16}"/>` +
        sconce(46) + sconce(114) +
        flag(4, P.cloth, P.cloth2) + flag(144, P.cloth, P.cloth2) +
        `<rect y="82" width="160" height="18" fill="${P.floor}"/>` +
        `<rect y="82" width="160" height="1.6" fill="${P.shade}"/>` +
        // the judge's high-backed leather chair: wide, square-topped, framed in wood
        // (neutral black overlays keep the leather dark in every palette)
        `<g transform="${Z}">` +
        `<rect x="55" y="13" width="50" height="51" rx="7" fill="${P.wood2}"/>` +
        `<rect x="57.4" y="15.4" width="45.2" height="48" rx="5.4" fill="${P.cloth4}"/>` +
        `<rect x="57.4" y="15.4" width="45.2" height="48" rx="5.4" fill="#000" opacity=".42"/>` +
        `<rect x="57.4" y="15.4" width="45.2" height="4" rx="2" fill="${P.light}" opacity=".12"/>` +
        `<g fill="#000" opacity=".28"><circle cx="63" cy="23" r=".9"/><circle cx="71.5" cy="21.6" r=".9"/><circle cx="80" cy="21.2" r=".9"/><circle cx="88.5" cy="21.6" r=".9"/><circle cx="97" cy="23" r=".9"/>` +
        `<circle cx="63" cy="32" r=".9"/><circle cx="97" cy="32" r=".9"/><circle cx="63" cy="41" r=".9"/><circle cx="97" cy="41" r=".9"/></g></g>`;

      subject =
        `<g transform="${Z}">` +
        h.shadow(80, 95, 41, 3, .25) +
        rim(`<path d="M52 72 C53 55 65 47 80 47 C95 47 107 55 108 72Z M42 64 H118 V96 H42Z"/><rect x="39" y="60" width="82" height="5.6" rx="1.6"/>`) +
        // judge in black robes
        `<path d="M52 72 C53 55 65 47 80 47 C95 47 107 55 108 72Z" fill="${P.ink}"/>` +
        `<path d="M66 50 C70 56 72 62 71 72 M94 50 C90 56 88 62 89 72" stroke="${P.metal3}" stroke-width=".9" fill="none" opacity=".45"/>` +
        `<path d="M73.6 47.8 Q80 52 86.4 47.8 L84 51.4 Q80 53.6 76 51.4Z" fill="${P.light}"/>` +
        `<path d="M78.2 51.8 H79.6 V58 H78.2Z M80.4 51.8 H81.8 V58 H80.4Z" fill="${P.light}"/>` +
        head(80, 33, .95, { hair: P.metal2, brow: P.metal3 }) +
        // bench
        `<path d="M42 64 H118 V96 H42Z" fill="${P.wood2}"/>` +
        `<path d="M42 64 H118 V96 H42Z" fill="${P.shade}"/>` +
        `<path d="M48 71h18v20h-18ZM71 71h18v20h-18ZM94 71h18v20h-18Z" fill="${P.wood}" opacity=".45"/>` +
        `<circle cx="80" cy="81" r="6" fill="${P.sun}" opacity=".9"/><circle cx="80" cy="81" r="4.3" fill="${P.wood2}"/><circle cx="80" cy="81" r="2.4" fill="${P.sun}" opacity=".9"/>` +
        `<rect x="39" y="60" width="82" height="5.6" rx="1.6" fill="${P.wood}"/>` +
        `<rect x="39" y="60" width="82" height="1.4" rx=".7" fill="${P.light}" opacity=".25"/>` +
        // judge's hands
        `<ellipse cx="72" cy="60.4" rx="3.6" ry="2.4" fill="${P.skin}"/><ellipse cx="88" cy="60.4" rx="3.6" ry="2.4" fill="${P.skin}"/>` +
        // gavel + sound block
        `<g transform="translate(108 60) scale(1.3) translate(-108 -60)">` +
        `<ellipse cx="108" cy="59.6" rx="6.6" ry="2" fill="${P.wood2}"/>` +
        `<rect x="101.4" y="57" width="13.2" height="2.6" rx="1.2" fill="${P.wood2}"/>` +
        `<path d="M110 52.6 L121 58.2" stroke="${P.wood}" stroke-width="1.8" stroke-linecap="round"/>` +
        `<g transform="rotate(27 108 52)"><rect x="102.6" y="48.8" width="10.8" height="6.4" rx="2" fill="${P.wood2}"/><rect x="104.4" y="48.8" width="1.4" height="6.4" fill="${P.sun}" opacity=".8"/><rect x="110.2" y="48.8" width="1.4" height="6.4" fill="${P.sun}" opacity=".8"/></g></g>` +
        mic(60, 60.2, 61, 51, 58.4, 55) +
        `</g>`;
    }

    /* ---------- extra: an aide standing to the left with a folder ---------- */
    const ax = court ? 27 : 31;
    const extra =
      `<g transform="translate(${ax} 94) scale(1.08) translate(${-ax} -94)">` + h.shadow(ax, 94, 10, 2, .22) +
      `<path d="M${ax - 5} 76 H${ax - 1} V93 H${ax - 5}Z M${ax + 1} 76 H${ax + 5} V93 H${ax + 1}Z" fill="${P.ink}" opacity=".85"/>` +
      `<path d="M${ax - 6.5} 94 H${ax - .4} V92 H${ax - 5}Z M${ax + .4} 94 H${ax + 6.5} L${ax + 5} 92 H${ax + .4}Z" fill="${P.ink}"/>` +
      `<path d="M${ax - 10} 80 C${ax - 10} 60 ${ax - 6} 52 ${ax} 52 C${ax + 6} 52 ${ax + 10} 60 ${ax + 10} 80Z" fill="${P.cloth4}"/>` +
      `<path d="M${ax - 2.6} 52.4 L${ax} 58 L${ax + 2.6} 52.4Z" fill="${P.light}"/>` +
      `<rect x="${ax - 2.4}" y="44" width="4.8" height="9" rx="2" fill="${P.skin2}"/>` +
      `<ellipse cx="${ax}" cy="41" rx="6.6" ry="7.8" fill="${P.skin2}"/>` +
      `<path d="M${ax - 7} 40 C${ax - 7.4} 30 ${ax + 7.4} 30 ${ax + 7} 40 C${ax + 5} 35.6 ${ax - 3} 34 ${ax - 7} 40Z" fill="${P.hair}"/>` +
      `<path d="M${ax - 7} 40 C${ax - 8} 44 ${ax - 7.6} 47 ${ax - 6} 49 L${ax - 5.4} 40Z M${ax + 7} 40 C${ax + 8} 44 ${ax + 7.6} 47 ${ax + 6} 49 L${ax + 5.4} 40Z" fill="${P.hair}"/>` +
      `<g fill="${P.ink}"><circle cx="${ax - 2.6}" cy="41.6" r="1"/><circle cx="${ax + 2.6}" cy="41.6" r="1"/></g>` +
      `<path d="M${ax - 2} 45.2 Q${ax} 46.6 ${ax + 2} 45.2" stroke="${P.lip}" stroke-width="1" fill="none" stroke-linecap="round"/>` +
      // folder held in front
      `<rect x="${ax - 7}" y="62" width="11" height="14" rx="1.4" fill="${P.paper}" transform="rotate(-8 ${ax} 69)"/>` +
      `<rect x="${ax - 7}" y="62" width="2.2" height="14" rx="1" fill="${P.cloth3}" transform="rotate(-8 ${ax} 69)"/>` +
      `<ellipse cx="${ax + 3.6}" cy="70" rx="2.4" ry="2" fill="${P.skin2}"/>` +
      `</g>`;

    return { bg, subject, extra, face: { x: 80, y: 28, r: 15 } };
  });
})();

/* ---- landscape ---- */
/* PromptSnap preview scene: "landscape"
 * Mountains, a lake with their reflection, pines and a meadow. The subject is
 * a small lakeside log cabin with one pine beside it; the removable extra sits
 * on the left of the picture: a power line (a lattice pylon in the foreground
 * and a smaller one on the far shore) or, with o.hiker, two hikers.
 * Options: hiker (true = the extra is two hikers instead of the power line). */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  const f = (v) => Math.round(v * 10) / 10;
  // many small circles as ONE path: [[x, y, r], …]
  const dots = (list) => list.map(([x, y, r]) => `M${f(x - r)} ${y}a${r} ${r} 0 1 0 ${f(2 * r)} 0a${r} ${r} 0 1 0 ${f(-2 * r)} 0`).join("");

  // pines are collected into shared "layers": one <path> per tone for a whole
  // row of trees, so a forest costs a handful of elements
  const layer = () => ({ trunk: "", body: "", shade: "", rim: "", snow: "" });
  const pine = (L, x, base, ht) => {
    const w = ht * 0.42, t = ht * 0.16;
    L.trunk += `M${f(x - t * 0.18)} ${f(base - t)}h${f(t * 0.36)}v${f(t)}h${f(-t * 0.36)}z`;
    for (const [a, b, k] of [[0, 0.58, 1], [0.24, 0.82, 0.8], [0.46, 1, 0.58]]) {
      const top = f(base - t - ht * (1 - a) * 0.86), bot = f(base - t - ht * (1 - b) * 0.86 + ht * 0.06);
      const hw = w * k * 0.5, mid = f(top + (bot - top) * 0.42), R = f(x + hw), Lx = f(x - hw), t1 = f(top + 1);
      L.body += `M${x} ${top}Q${x + 1} ${t1} ${R} ${bot}Q${x} ${f(bot + 2)} ${Lx} ${bot}Q${x - 1} ${t1} ${x} ${top}Z`;
      L.shade += `M${x} ${top}Q${x + 1} ${t1} ${R} ${bot}Q${f(x + hw * 0.5)} ${f(bot + 1.4)} ${x} ${f(bot + 1.6)}Z`;
      L.rim += `M${x} ${top}Q${x - 1} ${t1} ${Lx} ${bot}Q${f(x - hw * 0.7)} ${f(bot + 0.9)} ${f(x - hw * 0.45)} ${f(bot + 1.2)}Q${f(x - hw * 0.4)} ${mid} ${x} ${top}Z`;
      L.snow += `M${x} ${top}Q${x + 1} ${t1} ${f(x + hw * 0.42)} ${mid}Q${x} ${f(top + (bot - top) * 0.3)} ${f(x - hw * 0.42)} ${mid}Q${x - 1} ${t1} ${x} ${top}Z`;
    }
  };
  // s: { body, dark, shade, rim, rimA, snow } — the colours / opacities of a layer
  const drawLayer = (L, P, s) =>
    `<path d="${L.trunk}" fill="${P.wood2}"/><path d="${L.body}" fill="${s.body}"/>` +
    (s.dark ? `<path d="${L.body}" fill="${P.ink}" opacity="${s.dark}"/>` : "") +
    `<path d="${L.shade}" fill="${P.ink}" opacity="${s.shade}"/>` +
    (s.rim ? `<path d="${L.rim}" fill="${s.rim}" opacity="${s.rimA}"/>` : "") +
    (s.snow ? `<path d="${L.snow}" fill="${s.snow}"/>` : "");

  // a lattice power pylon: path data and its four arm tips [x, y]
  const pylon = (x, base, ht) => {
    const top = base - ht, w = ht * 0.12, tw = ht * 0.025;
    const legL = (y) => f(x - w + (w - tw) * (base - y) / ht), legR = (y) => f(x + w - (w - tw) * (base - y) / ht);
    let d = `M${f(x - w)} ${base}L${f(x - tw)} ${f(top)}M${f(x + w)} ${base}L${f(x + tw)} ${f(top)}`;
    for (let i = 0; i < 6; i++) {
      const y1 = f(base - ht * 0.9 * i / 6), y2 = f(base - ht * 0.9 * (i + 1) / 6);
      d += `M${legL(y1)} ${y1}L${legR(y2)} ${y2}M${legR(y1)} ${y1}L${legL(y2)} ${y2}`;
    }
    const a1 = f(top + ht * 0.12), a2 = f(top + ht * 0.3), r1 = ht * 0.22, r2 = ht * 0.16;
    d += `M${f(x - r1)} ${a1}H${f(x + r1)}M${f(x - r2)} ${a2}H${f(x + r2)}` +
         `M${f(x - r1)} ${a1}L${f(x - tw)} ${f(a1 - ht * 0.06)}M${f(x + r1)} ${a1}L${f(x + tw)} ${f(a1 - ht * 0.06)}`;
    return { d, tips: [[x - r1, a1], [x + r1, a1], [x - r2, a2], [x + r2, a2]] };
  };

  // a hiker with a backpack and a walking pole, standing at (x, base), facing right
  const hiker = (x, base, s, P) =>
    `<g transform="translate(${x} ${base}) scale(${s})">` +
    `<ellipse cx="0" cy="0" rx="6" ry="1.4" fill="#000" opacity=".2"/>` +
    `<path d="M-2.4 -10L-3.6 -.4M2.2 -10L3.6 -.4" stroke="${P.cloth2}" stroke-width="2.6" stroke-linecap="round"/>` +
    `<rect x="-7.6" y="-22" width="5.6" height="10" rx="2.2" fill="${P.cloth4}"/>` +
    `<rect x="-4.6" y="-21.6" width="9.4" height="12.6" rx="4" fill="${P.cloth3}"/>` +
    `<path d="M4 -17L7.6 -.4" stroke="${P.metal3}" stroke-width="1" stroke-linecap="round"/>` +
    `<circle cx=".6" cy="-25.4" r="3.4" fill="${P.skin}"/>` +
    `<path d="M-3 -26Q.6 -31 4.2 -26Z" fill="${P.cloth2}"/>` +
    `</g>`;

  A.scene("landscape", (P, o, h) => {
    o = o || {};
    const winter = P.id === "winter", night = !!P.night;

    /* ---------------- background ---------------- */
    const peaks = `M-4 59L12 38Q16 33 20 37L30 45L46 23Q51 16 56 22L72 41L86 32Q90 28 94 32L108 26Q113 20 118 26L138 44L148 39Q152 36 156 39L166 46V59Z`;
    const shadeFaces = `M16 35Q18 34 20 37L30 45L22 59L14 59ZM51 17Q54 18 56 22L72 41L62 59L48 59ZM113 21Q116 23 118 26L138 44L126 59L112 59ZM90 29Q92 30 94 32L100 29L96 59L90 59Z`;
    const caps = `M46 23Q51 16 56 22L60.5 27.5Q57 26 55 29Q52 26.5 49.5 29Q47 26.5 42.5 28Z` +
                 `M108 26Q113 20 118 26L122.5 30.2Q119 29 117 31.5Q114 29.5 111.5 31.5Q109 29.5 104.5 30.8Z` +
                 `M12 38Q16 33 20 37L23 39.5Q20 39 18.5 41Q16 39.5 14 41Q12 40 9.5 41.2Z` +
                 `M86 32Q90 28 94 32L96.5 34Q93.5 33.6 92 35.4Q90 34 88 35.5Q86 34.2 83.5 35.2Z`;
    const hillPath = `M0 59L0 53Q18 48 36 53Q52 57 70 54Q86 51 100 55Q124 49 142 53Q152 55 160 52V59Z`;
    const range = `<path d="${peaks}" fill="${P.far}"/><path d="${shadeFaces}" fill="#000" opacity="${night ? .22 : .1}"/>` +
                  `<path d="${caps}" fill="${P.light}" opacity="${night ? .6 : .95}"/>`;
    // far shore: low hills and a ragged line of tiny pines
    let shoreTrees = "";
    [2, 7, 11, 16, 22, 27, 33, 38, 44, 50, 57, 63, 69, 75, 120, 126, 131, 137, 142, 148, 153, 158].forEach((x, i) => {
      shoreTrees += `M${x} ${58.5 - (5 + ((i * 7) % 5))}L${f(x + 2.4)} 59H${f(x - 2.4)}Z`;
    });
    const treeTone = winter ? P.far : P.near;
    const hills = `<path d="${hillPath}" fill="${P.mid}"/><path d="${shoreTrees}" fill="${treeTone}"/>`;
    const lakeTop = 58.6;
    const lake =
      `<rect y="${lakeTop}" width="160" height="24" fill="${P.water}"/>` +
      // reflection of hills and mountains, flipped about the waterline
      `<g transform="translate(0 ${lakeTop * 2}) scale(1 -1)" opacity="${night ? .5 : .38}">` +
        `<path d="${peaks}" fill="${P.far}"/><path d="${caps}" fill="${P.light}" opacity=".6"/>` +
        `<path d="${hillPath}" fill="${P.mid}"/>` +
      `</g>` +
      `<rect y="${lakeTop}" width="160" height="1.2" fill="${P.light}" opacity=".35"/>` +
      // ripples, and the sun / moon glitter on the water below it
      `<path d="M14 64h16v.8H14zM52 67h18v.8H52zM98 63h12v.8H98zM32 69.4h12v.8H32z" fill="${P.light}" opacity="${night ? .3 : .55}"/>` +
      `<path d="M122 61h12v1.1H122zM124.5 64h7v1H124.5zM126 67h4v.9H126z" fill="${P.sun}" opacity="${night ? .6 : .75}"/>`;
    const meadow =
      `<path d="M0 73Q30 68 62 71Q100 75 128 70Q146 67 160 69V100H0Z" fill="${P.ground}"/>` +
      `<path d="M0 73Q30 68 62 71Q100 75 128 70Q146 67 160 69V71.4Q146 69.4 128 72.4Q100 77 62 73.2Q30 70.4 0 75Z" fill="#000" opacity=".06"/>` +
      `<path d="M0 90Q34 83 74 88Q118 93 160 85V100H0Z" fill="${P.mid}"/>` +
      `<path d="M0 96Q40 92 80 96T160 94V100H0Z" fill="${P.near}" opacity=".7"/>` +
      // a light trail winding up to the cabin door
      `<path d="M50 100Q54 92 62 88Q68 85 64 83L69 83Q75 86 71 90Q64 95 67 100Z" fill="${P.light}" opacity="${night ? .1 : .32}"/>` +
      // meadow flowers (not in snow)
      (winter ? "" :
        `<path d="${dots([[20, 84, .9], [40, 80, .8], [118, 88, .9], [144, 80, .8], [30, 92, 1]])}" fill="${P.sun}"/>` +
        `<path d="${dots([[26, 81, .8], [44, 87, .9], [132, 88, 1], [152, 83, .8], [12, 88, .9]])}" fill="${P.light}" opacity=".85"/>` +
        `<path d="${dots([[36, 89, .9], [128, 81, .8], [146, 92, 1]])}" fill="${P.accent}" opacity="${night ? .5 : .9}"/>`);
    // background pines in two depth rows, the farther row first
    const back = layer(), front = layer();
    pine(back, 7, 78, 30); pine(back, 32, 76, 24); pine(back, 142, 76, 26);
    pine(front, 19, 80, 38); pine(front, 153, 80, 34);
    const ps = { body: treeTone, shade: winter ? 0.3 : 0.24, snow: winter ? P.light : "", rim: night ? P.light : "", rimA: .1 };
    const bgPines = drawLayer(back, P, ps) + drawLayer(front, P, ps);
    // chimney smoke lives in the background so the cut-out stays clean
    const smoke = `<path d="${dots([[95.6, 31.5, 2.6], [99.4, 26.6, 3.3], [104.2, 21, 4]])}" fill="${P.cloud}" opacity="${night ? .25 : .75}"/>`;
    // warm light spilling onto the grass at night
    const spill = night ? `<ellipse cx="88" cy="85.6" rx="26" ry="3.6" fill="${P.lamp}" opacity=".09"/><ellipse cx="86" cy="85" rx="14" ry="2.2" fill="${P.lamp}" opacity=".14"/>` : "";
    const bg = `${h.sky(P)}${h.stars(P)}${h.sunOrMoon(P, 128, 17, 6.5)}${h.cloud(P, 34, 14, .75)}${h.cloud(P, 150, 31, .45)}` +
               range + hills + lake + meadow + spill + bgPines + smoke;

    /* ---------------- subject: cabin + pine ---------------- */
    const roof = P.cloth3, wall = P.wood, wall2 = P.wood2;
    const glow = night
      ? `<circle cx="90" cy="71" r="13" fill="${P.lamp}" opacity=".14"/><circle cx="90" cy="71" r="7.5" fill="${P.lamp}" opacity=".2"/>` +
        `<circle cx="69" cy="60.5" r="5" fill="${P.lamp}" opacity=".18"/><circle cx="75" cy="69.6" r="3.6" fill="${P.lamp}" opacity=".3"/>`
      : "";
    let logs = "";
    for (let y = 66.5; y < 82; y += 3.2) logs += `M60.6 ${f(y)}H77.4M78.6 ${f(y)}H99.4`;
    const cabin =
      `<g transform="translate(80 82.5) scale(1.22) translate(-80 -82.5)">` +
      `<ellipse cx="81" cy="82.7" rx="25" ry="2.4" fill="#000" opacity=".22"/>` +
      glow +
      // chimney
      `<rect x="89.6" y="45" width="5.4" height="12" rx="1" fill="${P.metal3}"/>` +
      `<rect x="89" y="44" width="6.6" height="2.2" rx="1" fill="${P.metal2}"/>` +
      // side wall (a touch darker) and the front gable wall
      `<rect x="78" y="63" width="22" height="19.5" fill="${wall}"/>` +
      `<rect x="78" y="63" width="22" height="19.5" fill="#000" opacity=".1"/>` +
      `<path d="M60 82.5V63.5L69 53.5L78 63.5V82.5Z" fill="${wall}"/>` +
      `<path d="${logs}" stroke="${wall2}" stroke-width=".7" opacity=".55"/>` +
      // corner posts, door and window sill in the darker wood
      `<path d="M77.2 62h1.8v20.5h-1.8zM99 63h1.6v19.5H99zM59.2 63h1.6v19.5h-1.6zM65.2 70h5.6q1.2 0 1.2 1.2V82.5H64V71.2q0-1.2 1.2-1.2zM83.4 75h13.2v1H83.4z" fill="${wall2}"/>` +
      // roof: long slope + gable edge
      `<path d="M69 52L96 52L104 64.6L78.6 64.6Z" fill="${roof}"/>` +
      `<path d="M78.6 64.6L104 64.6L102.6 62.4L77.4 62.4Z" fill="#000" opacity=".15"/>` +
      `<path d="M57.4 65.4L69 51.4L80.4 65.4" stroke="${roof}" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<path d="M69 51.4L96 51.4" stroke="#fff" stroke-width=".8" opacity=".35" stroke-linecap="round"/>` +
      // snow on the roof, the gable edge and the chimney in winter
      (winter ? `<path d="M69 50.8L96 50.8L100.2 57.4Q98 58.4 96.4 57.2Q93.6 58.8 91 57.2Q88 58.8 85.2 57.2Q82.2 58.6 79.6 57Q77 58.4 75 57.2L71.4 54Z" fill="${P.light}"/>` +
                `<path d="M58.2 64.6L69 51.6L79.6 64.6" stroke="${P.light}" stroke-width="1.3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` +
                `<rect x="88.8" y="42.8" width="7" height="2" rx="1" fill="${P.light}"/>` : "") +
      // windows (P.glass lights up at night) with a flower box
      `<rect x="84" y="67" width="12" height="8" rx="1" fill="${P.light}"/>` +
      `<rect x="85" y="68" width="10" height="6" rx=".6" fill="${P.glass}"/>` +
      `<path d="M90 68V74M85 71H95" stroke="${P.light}" stroke-width=".9"/>` +
      `<path d="${dots([[86, 74.2, 1.1], [89, 74, 1.2], [94, 74.2, 1.1]])}" fill="${P.cloth3}"/>` +
      `<circle cx="69" cy="60.5" r="2.6" fill="${P.light}"/><circle cx="69" cy="60.5" r="1.9" fill="${P.glass}"/>` +
      // door panel, knob, porch lamp, step
      `<rect x="65.2" y="71.4" width="5.6" height="4.4" rx=".6" fill="#000" opacity=".12"/>` +
      `<circle cx="70.4" cy="77" r=".7" fill="${P.sun}"/>` +
      `<rect x="74.2" y="68.6" width="1.8" height="2.4" rx=".6" fill="${night ? P.lamp : P.metal3}"/>` +
      `<rect x="62.6" y="82" width="10.8" height="1.6" rx=".6" fill="${P.metal3}"/>` +
      `</g>`;
    const mine = layer();
    pine(mine, 120, 83, 46);
    const myPine =
      `<ellipse cx="120" cy="83" rx="9" ry="1.8" fill="#000" opacity=".22"/>` +
      drawLayer(mine, P, { body: winter ? P.cloth4 : P.near, dark: winter ? .42 : 0, shade: winter ? .3 : .22,
                           snow: winter ? P.light : "", rim: night ? P.light : "", rimA: .16 });
    const subject = `<g>${cabin}${myPine}</g>`;

    /* ---------------- extra: on the left, clear of the cabin ---------------- */
    let extra;
    if (o.hiker) {
      // two hikers on the meadow, walking toward the cabin
      extra = hiker(16, 94, 1.12, P) + hiker(34, 91, .92, P);
    } else {
      // a power line: a pylon in the foreground and a smaller one on the far
      // shore; the cables run between them, on toward the viewer (off the left
      // edge) and away behind the cabin, which hides them
      const col = night ? P.metal : P.ink;
      const near = pylon(22, 80, 60), far = pylon(47, 58.4, 19);
      const c = (x1, y1, x2, y2, sag) => `M${f(x1)} ${f(y1)}Q${f((x1 + x2) / 2)} ${f(Math.max(y1, y2) + sag)} ${f(x2)} ${f(y2)}`;
      let cables = "";
      near.tips.forEach(([x1, y1], i) => {
        const [x2, y2] = far.tips[i];
        cables += c(x1, y1, x2, y2, 2.4) + c(x2, y2, x2 + (x2 - x1) * .6, y2 + (y2 - y1) * .6, .6);
      });
      cables += c(near.tips[0][0], near.tips[0][1], -2, near.tips[0][1] - 3, 4) + c(near.tips[2][0], near.tips[2][1], -2, near.tips[2][1] - 2, 4);
      extra = `<g opacity="${night ? .9 : .75}" fill="none" stroke="${col}" stroke-linecap="round" stroke-linejoin="round">` +
              `<path d="${cables}" stroke-width=".5"/><path d="${near.d}" stroke-width="1.1"/><path d="${far.d}" stroke-width=".7"/></g>`;
    }

    return { bg, subject, extra, face: { x: 86, y: 52, r: 22 } };
  });
})();

/* ---- city ---- */
/* PromptSnap preview scene: "city"
 * A street in one-point perspective: buildings on both sides with rows of
 * windows (P.glass, so they light up at night), shopfronts with awnings,
 * street lamps that glow at night, and a clock-tower landmark at the end of
 * the street. bg = sky, far skyline, road and pavements; subject = the
 * buildings, the tower and the street furniture; extra = a car parked at the
 * left kerb (on the left, so remove-object shows it on the "before" half).
 *
 * Size: same-tone shapes of every building share ONE <path> (all windows,
 * all cornices, all seams…), shaded faces use palette colours mixed toward
 * black instead of extra overlay shapes, and windows that are off-canvas or
 * hidden behind the tower are not drawn. */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  // numbers with one decimal and no leading zero (".5"); j() joins them with
  // a space only where needed ("3.2-.4"), which keeps the markup small
  const r1 = (v) => Math.round(v * 10) / 10;
  const f = (v) => String(r1(v)).replace(/^(-?)0\./, "$1.");
  const j = (...a) => a.map((v, i) => { const s = f(v); return i && s[0] !== "-" ? " " + s : s; }).join("");
  const VX = 80, VY = 50, GROUND = 92;              // vanishing point; ground height at the near plane
  const X = (side, lat, z) => VX + side * lat / z;  // lateral distance → screen x at depth z
  const Y = (hh, z) => VY + (hh - VY) / z;          // near-plane height → screen y at depth z
  // path data: a polygon [[x, y], …], an ellipse, a rect
  const poly = (a) => {
    const p = a.map(([x, y]) => [r1(x), r1(y)]);
    return `M${j(...p[0])}l` + p.slice(1).map(([x, y], i) => j(x - p[i][0], y - p[i][1])).join(" ").replace(/ -/g, "-") + "z";
  };
  const ell = (cx, cy, rx, ry) => `M${j(cx - rx, cy)}a${j(rx, ry)} 0 1 0 ${j(2 * rx)} 0a${j(rx, ry)} 0 1 0 ${j(-2 * rx)} 0`;
  const rct = (x, y, w, hh) => `M${j(x, y)}h${f(w)}v${f(hh)}h${f(-w)}z`;
  // a quad on a wall that runs along the street (constant lateral distance), in relative steps
  const wq = (side, lat, z1, z2, h1, h2) => {
    const xa = r1(X(side, lat, z1)), xb = r1(X(side, lat, z2));
    const a1 = r1(Y(h1, z1)), b1 = r1(Y(h1, z2)), b2 = r1(Y(h2, z2)), a2 = r1(Y(h2, z1));
    return `M${j(xa, a1)}l${j(xb - xa, b1 - a1)}v${f(b2 - b1)}l${j(xa - xb, a2 - b2)}z`;
  };
  // a quad on the ground between two lateral offsets
  const gq = (l1, l2, z1, z2) => {
    const y1 = f(Y(GROUND, z1)), y2 = f(Y(GROUND, z2));
    return `M${f(VX + l1 / z1)} ${y1}H${f(VX + l2 / z1)}L${f(VX + l2 / z2)} ${y2}H${f(VX + l1 / z2)}Z`;
  };
  // mix two palette colours (#rrggbb); anything else is returned unchanged
  const mix = (a, b, t) => {
    if (!/^#[0-9a-f]{6}$/i.test(a || "") || !/^#[0-9a-f]{6}$/i.test(b || "")) return a;
    let s = "#";
    for (let i = 1; i < 7; i += 2) s += Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - t) + parseInt(b.slice(i, i + 2), 16) * t).toString(16).padStart(2, "0");
    return s;
  };
  const dark = (c, t) => mix(c, "#000000", t);
  // closed subpaths only: every later "M x y" becomes a short move relative to
  // the previous start ("m5.2-.3"; after "z" the pen is back at that start)
  const rel = (d) => {
    let px = null, py = 0;
    return d.replace(/M(-?\d*\.?\d+) ?(-?\d*\.?\d+)/g, (m, a, b) => {
      const out = px === null ? m : "m" + j(a - px, b - py);
      px = +a; py = +b;
      return out;
    });
  };
  const path = (d, attrs) => d ? `<path d="${rel(d)}" ${attrs}/>` : "";

  A.scene("city", (P, o, h) => {
    o = o || {};
    const night = !!P.night, winter = P.id === "winter";
    const WALL = 80, KERB = 46, END = 5, zNear = 0.78, zc = 6.2;

    /* ---------------- background: sky, skyline, road ---------------- */
    const sky = `${h.sky(P)}${h.stars(P)}${h.sunOrMoon(P, 106, 13, 5.5)}${h.cloud(P, 58, 12, .6)}`;
    // distant skyline beyond the end of the street
    let sk = "";
    for (const [x, t, w] of [[24, 30, 12], [36, 22, 10], [46, 34, 12], [58, 18, 9], [67, 28, 8], [93, 24, 9], [102, 26, 8], [110, 30, 12], [122, 20, 10], [132, 32, 14]])
      sk += `M${x} ${t}h${w}V60h${-w}z`;
    // cross-street facades facing us at the end of the street; only the
    // windows in the gaps beside the tower can be seen
    const yb = Y(GROUND, zc);
    let cross = "", crossWin = "";
    for (const [x, t, w] of [[50, 36, 12], [62, 40, 10], [96, 38, 11], [107, 34, 12]]) {
      cross += `M${x} ${t}h${w}V${f(yb)}h${-w}z`;
      for (let wy = t + 3; wy < yb - 3; wy += 4.2)
        for (let wx = x + 1.6; wx < x + w - 2; wx += 3.2)
          if ((wx > 63.5 && wx < 67.5) || (wx > 91.5 && wx < 95)) crossWin += rct(wx, wy, 1.6, 2);
    }
    // road, kerbs, pavements, lane markings, zebra crossing
    let dashes = "", zebra = "";
    for (let z = 0.8; z < END; z *= 1.45) dashes += gq(-1.4, 1.4, z, z * 1.2);
    for (let l = -KERB + 5; l < KERB - 4; l += 8) zebra += gq(l, l + 4.4, 0.85, 0.99);
    // street lamps: [side, depth]; their light pools on the pavement at night
    const lamps = [[-1, 4], [-1, 2.5], [1, 2.5], [1, 1.22], [-1, 1.05]]; // the left ones clear of the parked car
    let pools = "";
    if (night) for (const [s, z] of lamps) pools += ell(X(s, KERB + 6, z), Y(GROUND, z), 16 / z, 4 / z);
    const road =
      path(gq(-WALL * 2, WALL * 2, zNear, zc), `fill="${winter ? P.ground : P.floor}"`) +
      path(gq(-KERB, KERB, zNear, zc), `fill="${P.road}"`) +
      path(gq(-KERB - 2.4, -KERB, zNear, END) + gq(KERB, KERB + 2.4, zNear, END), `fill="${P.metal2}"`) +
      path(dashes, `fill="${P.line}" opacity=".9"`) +
      path(zebra, `fill="${P.line}" opacity="${night ? .55 : .85}"`) +
      path(gq(-KERB + 4, -KERB + 5, zNear, END) + gq(KERB - 5, KERB - 4, zNear, END), `fill="${P.line}" opacity=".45"`) +
      path(pools, `fill="${P.lamp}" opacity=".18"`);
    const bg = sky + path(sk, `fill="${P.far}" opacity="${night ? .8 : .55}"`) +
               path(cross, `fill="${P.far}"`) + path(crossWin, `fill="${P.glass}" opacity="${night ? .8 : .45}"`) + road;

    /* ---------------- subject: buildings, tower, street furniture ---------------- */
    // shared layers for every building (drawn after all facades: windows,
    // cornices and shopfronts of one facade never overlap another building)
    const L = { cornS: "", cornL: "", seam: "", win: "", dim: "", ledge: "", shop: "", shopB: "" };
    let walls = "", awnings = "";
    const build = (side, list) => {
      // far → near so nearer buildings overlap farther ones
      for (let i = list.length - 1; i >= 0; i--) {
        const b = list[i], z1 = b.z1, z2 = b.z2, top = b.top;
        const col = b.tint ? mix(b.col, P.wall, b.tint) : b.col;
        // the end face toward us (only seen above a shorter neighbour), then the street facade
        const xe = f(X(side, WALL, z1)), xo = f(X(side, WALL + 90, z1));
        walls += `<path d="M${xe} ${f(Y(top, z1))}H${xo}V${f(Y(GROUND, z1))}H${xe}Z" fill="${dark(col, .16)}"/>` +
                 `<path d="${wq(side, WALL, z1, z2, top, GROUND)}" fill="${col}"/>`;
        L.cornS += wq(side, WALL, z1, z2, top, top + 3);
        L.cornL += wq(side, WALL, z1, z2, top + 3, top + 4);
        L.seam += wq(side, WALL, z1, z1 + 0.012 * z1, top, GROUND);
        // windows: floors every 13 units, columns spread evenly in depth
        const span = Math.abs(X(side, WALL, z1) - X(side, WALL, z2));
        const n = Math.max(1, Math.min(6, Math.round(span / 6)));
        // (each floor has one continuous ledge under its windows)
        let fl = 0;
        for (let hh = 62; hh > top + 9; hh -= 13, fl++) {
          if (Y(hh + 1.2, z2) < 0) continue;                       // above the canvas
          if (z1 < 1.5) L.ledge += wq(side, WALL, z1, z2, hh, hh + 1.2);
          for (let k = 0; k < n; k++) {
            const a = z1 + (z2 - z1) * (k + 0.22) / n, c = z1 + (z2 - z1) * (k + 0.78) / n;
            const xa = X(side, WALL, a), xc = X(side, WALL, c);
            if (Y(hh, c) < 0 || Math.max(xa, xc) < 0 || Math.min(xa, xc) > 160) continue; // off the canvas
            const lit = !night || (k * 3 + fl * 2 + i) % 5 !== 0;
            if (lit) L.win += wq(side, WALL, a, c, hh - 8, hh); else L.dim += wq(side, WALL, a, c, hh - 8, hh);
          }
        }
        // shopfront: wide glass + an awning sloping out over the pavement
        const za = z1 + (z2 - z1) * .1, zb = z2 - (z2 - z1) * .1, wa = z1 + (z2 - z1) * .06, wb = z2 - (z2 - z1) * .06;
        const awn = (l1, h1, l2, h2) => poly([[X(side, l1, wa), Y(h1, wa)], [X(side, l1, wb), Y(h1, wb)], [X(side, l2, wb), Y(h2, wb)], [X(side, l2, wa), Y(h2, wa)]]);
        L.shop += wq(side, WALL, za, zb, 76, 90);
        L.shopB += wq(side, WALL, za, zb, 76, 79);
        awnings += `<path d="${awn(WALL, 70, WALL - 8, 77)}" fill="${b.awn}"/>` +
                   (winter ? `<path d="${awn(WALL, 70, WALL - 8, 75.4)}" fill="${P.light}"/>` : "") +
                   `<path d="${awn(WALL - 8, 77, WALL - 8, 79.4)}" fill="${dark(b.awn, .2)}"/>`;
      }
    };
    build(-1, [
      { z1: 0.55, z2: 1.32, top: -70, col: P.wood, awn: P.cloth4 },
      { z1: 1.32, z2: 2.08, top: -8, col: P.wall, awn: P.cloth3 },
      { z1: 2.08, z2: 3.15, top: 14, col: P.metal2, awn: P.cloth },
      { z1: 3.15, z2: END, top: -18, col: P.wall2, awn: P.cloth4 }
    ]);
    build(1, [
      { z1: 0.55, z2: 1.18, top: -34, col: P.wall2, awn: P.cloth },
      { z1: 1.18, z2: 1.95, top: -64, col: P.cloth3, awn: P.cloth4, tint: .15 },
      { z1: 1.95, z2: 3.05, top: 8, col: P.wall, awn: P.cloth3 },
      { z1: 3.05, z2: END, top: -10, col: P.wood, awn: P.cloth }
    ]);
    const buildings = walls +
      path(L.cornS, `fill="#000" opacity=".14"`) + path(L.cornL, `fill="${P.light}" opacity=".35"`) +
      path(L.win, `fill="${P.glass}"`) + path(L.dim, `fill="${P.glass2}" opacity=".35"`) +
      path(L.ledge, `fill="#000" opacity=".16"`) +
      path(L.shop, `fill="${P.glass}"`) + path(L.shopB, `fill="${P.glass2}" opacity=".7"`) +
      awnings + path(L.seam, `fill="#000" opacity=".2"`);

    // clock tower at the end of the street (no digits: four dots and two hands)
    const tx = 80, tb = Y(GROUND, zc) + 0.4, cy = 30, clr = 8;
    const arch = (x, y, w, hh) => `M${f(x)} ${f(y + hh)}V${f(y + w / 2)}a${w / 2} ${w / 2} 0 0 1 ${w} 0V${f(y + hh)}z`;
    const tower =
      `<rect x="${tx - 12}" y="${cy - 10}" width="24" height="20" rx="1" fill="${P.wall}"/>` +
      // base, shaft, cornices of the clock stage and the belfry in one tone
      path(rct(tx - 12, tb - 4, 24, 4) + rct(tx - 10, 40, 20, tb - 43.6) + rct(tx - 13.4, cy - 11.6, 26.8, 2.8) +
           rct(tx - 13.4, cy + 9, 26.8, 2.4) + rct(tx - 9, cy - 18.6, 18, 7.2), `fill="${P.wall2}"`) +
      path(rct(tx + 3.5, 41.4, 6.5, tb - 45) + rct(tx + 4.5, cy - 8.8, 7.5, 17.8), `fill="#000" opacity=".11"`) +
      path(arch(tx - 5, 42.6, 3, 5.4) + arch(tx + 2, 42.6, 3, 5.4) + arch(tx - 5, 50, 3, 3.8) + arch(tx + 2, 50, 3, 3.8), `fill="${P.glass}"`) +
      path(arch(tx - 6, cy - 17.2, 3.6, 5) + arch(tx + 2.4, cy - 17.2, 3.6, 5), `fill="${P.ink}" opacity=".55"`) +
      (night ? `<circle cx="${tx}" cy="${cy}" r="14" fill="${P.lamp}" opacity=".2"/>` : "") +
      path(ell(tx, cy, clr, clr) + rct(tx - .5, cy - 31.6, 1, 3.6), `fill="${P.metal3}"`) +
      `<circle cx="${tx}" cy="${cy}" r="${clr - 1.1}" fill="${night ? P.lamp : P.light}"/>` +
      path(ell(tx, cy - 5.4, .7, .7) + ell(tx + 5.4, cy, .7, .7) + ell(tx, cy + 5.4, .7, .7) + ell(tx - 5.4, cy, .7, .7) + ell(tx, cy, .9, .9), `fill="${P.ink}"`) +
      `<path d="M${tx} ${cy}V${cy - 4.6}M${tx} ${cy}L${tx + 3.6} ${cy + 1.6}" stroke="${P.ink}" stroke-width="1.1" stroke-linecap="round"/>` +
      // spire
      `<path d="M${tx - 11} ${cy - 18.2}L${tx} ${cy - 28.6}L${tx + 11} ${cy - 18.2}Z" fill="${P.cloth4}"/>` +
      `<path d="M${tx} ${cy - 28.6}L${tx + 11} ${cy - 18.2}H${tx}Z" fill="#000" opacity=".18"/>`;

    // street lamps (glow at night) and two street trees on the right pavement
    const T = { post: "", head: "", bulb: "", glow: "", glow2: "" };
    for (const [side, z] of lamps) {
      const x = X(side, KERB + 6, z), yb2 = Y(GROUND, z), yt = Y(30, z);
      const w = 1.6 / z, hx = x - side * 7 / z;
      // post, foot, and the arm curving over the pavement as a filled band
      const e = w * .4 * side, t = w * .4, ya = yt + 1 / z, yc = yt - 2.4 / z, ye = yt - 1 / z;
      T.post += rct(x - w / 2, yt, w, yb2 - yt) + rct(x - w, yb2 - 2 / z, w * 2, 2 / z) +
                `M${j(x + e, ya)}Q${j(x + e, yc - t, hx, ye - t)}L${j(hx, ye + t)}Q${j(x - e, yc + t, x - e, ya)}Z`;
      T.head += `M${f(hx - 2.6 / z)} ${f(yt)}Q${f(hx)} ${f(yt - 2.8 / z)} ${f(hx + 2.6 / z)} ${f(yt)}Z`;
      T.bulb += ell(hx, yt + .2 / z, 2 / z, .8 / z);
      if (night) { T.glow += ell(hx, yt + 1 / z, 9 / z, 9 / z); T.glow2 += ell(hx, yt + 1 / z, 4.5 / z, 4.5 / z); }
    }
    const R = { sh: "", trunk: "", crown: "", hi: "", lo: "", snow: "" };
    for (const z of [2.9, 1.8]) {
      const x = X(1, KERB + 8, z), y0 = Y(GROUND, z), r = 11 / z, cyc = y0 - 28 / z;
      R.sh += ell(x, y0, r * .8, r * .18);
      R.trunk += rct(x - 1 / z, y0 - 20 / z, 2 / z, 20 / z);
      R.crown += ell(x, cyc, r, r);
      R.hi += ell(x - r * .35, y0 - 31 / z, r * .6, r * .6);
      R.lo += ell(x + r * .3, y0 - 24.5 / z, r * .62, r * .62);
      R.snow += `M${f(x - r * .9)} ${f(cyc - r * .3)}Q${f(x)} ${f(cyc - r * 1.25)} ${f(x + r * .9)} ${f(cyc - r * .3)}Q${f(x)} ${f(cyc - r * .75)} ${f(x - r * .9)} ${f(cyc - r * .3)}Z`;
    }
    // trees first: no lamp overlaps a nearer tree
    const furniture =
      path(R.sh, `fill="#000" opacity=".2"`) + path(R.trunk, `fill="${P.wood2}"`) +
      path(R.crown, `fill="${mix(P.cloth4, P.mid, .5)}"`) + path(R.hi, `fill="${P.light}" opacity=".14"`) +
      path(R.lo, `fill="${P.near}" opacity=".7"`) + (winter ? path(R.snow, `fill="${P.light}"`) : "") +
      path(T.glow, `fill="${P.lamp}" opacity=".2"`) + path(T.glow2, `fill="${P.lamp}" opacity=".35"`) +
      path(T.post, `fill="${P.ink}" opacity=".85"`) +
      path(T.head, `fill="${P.ink}" opacity=".9"`) + path(T.bulb, `fill="${night ? P.lamp : P.metal}"`);

    const subject = `<g>${tower}${buildings}${furniture}</g>`;

    /* ---------------- extra: a car parked at the left kerb ---------------- */
    // modelled at the right kerb and mirrored: a small box seen from behind
    // (rear, inner side and, below eye level, the top and roof)
    const Q = (lat, hh, z) => [X(1, lat, z), Y(hh, z)];
    const c0 = 1.04, c1 = 1.68, cl = 19, cr = 41, hb = GROUND - 3.5, ht = GROUND - 10, hr = GROUND - 17;
    const k0 = c0 + .16, k1 = c1 - .14, kl = cl + 2.4, kr = cr - 2.4;
    const tail = "#e8473c"; // tail lights stay red in every palette
    // a blue car (teal in winter, where P.cloth turns red and the tail lights would vanish)
    const body = winter ? P.cloth4 : P.cloth, flank = winter ? dark(P.cloth4, .25) : P.cloth2;
    const quad = (lat1, lat2, h1, h2, z) => poly([Q(lat1, h1, z), Q(lat2, h1, z), Q(lat2, h2, z), Q(lat1, h2, z)]);
    const wheel = (lat, z) => { const [x, y] = Q(lat, GROUND, z); return ell(x, y - 2.4 / z, 1.6 / z, 3 / z); };
    const [rx1, ry1] = Q(cl, GROUND, c0), [rx2] = Q(cr, GROUND, c0);
    const car =
      `<g transform="translate(160 0) scale(-1 1)">` +
      `<ellipse cx="${f((rx1 + rx2) / 2 - 3)}" cy="${f(ry1)}" rx="${f((rx2 - rx1) * .72)}" ry="${f(2.2 / c0)}" fill="#000" opacity=".3"/>` +
      // wheels: two on the inner side, two peeking under the bumper
      path(wheel(cl, c0 + .12) + wheel(cl, c1 - .12) + quad(cl + 1, cl + 5, GROUND, hb, c0 + .02) + quad(cr - 5, cr - 1, GROUND, hb, c0 + .02), `fill="${P.ink}"`) +
      path(poly([Q(cl, hb, c0), Q(cl, hb, c1), Q(cl, ht, c1), Q(cl, ht, c0)]), `fill="${flank}"`) +
      // body top, rear and roof
      path(poly([Q(cl, ht, c0), Q(cr, ht, c0), Q(cr, ht, c1), Q(cl, ht, c1)]) + quad(cl, cr, hb, ht, c0) +
           poly([Q(kl + 1, hr, k0 + .1), Q(kr - 1, hr, k0 + .1), Q(kr - 1, hr, k1 - .08), Q(kl + 1, hr, k1 - .08)]), `fill="${body}"`) +
      path(poly([Q(cl, ht, c0), Q(cr, ht, c0), Q(cr, ht, c1), Q(cl, ht, c1)]), `fill="${P.light}" opacity=".18"`) +
      // side and rear windows, a glint, the lit roof
      path(poly([Q(kl, ht, k0), Q(kl, ht, k1), Q(kl + 1, hr, k1 - .08), Q(kl + 1, hr, k0 + .1)]) +
           poly([Q(kl, ht, k0), Q(kr, ht, k0), Q(kr - 1, hr, k0 + .1), Q(kl + 1, hr, k0 + .1)]), `fill="${night ? P.metal3 : P.glass2}"`) +
      path(poly([Q(kl + 1, ht - 1, k0 + .02), Q(kl + 7, ht - 1, k0 + .02), Q(kl + 9, hr, k0 + .1), Q(kl + 4, hr, k0 + .1)]) +
           poly([Q(kl + 1, hr, k0 + .1), Q(kr - 1, hr, k0 + .1), Q(kr - 1, hr, k1 - .08), Q(kl + 1, hr, k1 - .08)]), `fill="${P.light}" opacity=".3"`) +
      // bumper, number plate (a blank bar), tail lights and their glow at night
      path(quad(cl, cr, hb, hb - 2, c0), `fill="${P.ink}" opacity=".45"`) +
      path(quad(cl + 8, cr - 8, hb - 3, hb - 5.4, c0), `fill="${P.light}"`) +
      (night ? path(ell(X(1, cl + 3, c0), Y(ht + 2.4, c0), 6 / c0, 3.4 / c0) + ell(X(1, cr - 3, c0), Y(ht + 2.4, c0), 6 / c0, 3.4 / c0), `fill="${tail}" opacity=".35"`) : "") +
      path(quad(cl + .6, cl + 5.6, ht + 1.2, ht + 3.6, c0) + quad(cr - 5.6, cr - .6, ht + 1.2, ht + 3.6, c0), `fill="${tail}"`) +
      `</g>`;

    return { bg, subject, extra: car, face: { x: 80, y: 30, r: 11 } };
  });
})();

/* ---- interior ---- */
/* PromptSnap preview scene: "interior"
 * A bright living room (real-estate / interior-design look): wood floor, a big
 * window whose view is the sky (dark outside at night), abstract wall art.
 * subject = the furniture group (sofa with cushions, rug, coffee table, arc
 * floor lamp that glows at night, potted plant on the right); extra = clutter
 * on the left, in front of the door (a stack of cardboard boxes and a laundry
 * basket), so remove-object shows it on the "before" half.
 * Options: empty (true = an unfurnished room, for virtual-staging previews). */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  A.scene("interior", (P, o, h) => {
    o = o || {};
    const night = !!P.night;
    const FL = 71;   // where the wall meets the floor
    // white trim (window frame, door frame, skirting); muted at night so it does not glare
    const trim = night ? P.metal2 : P.light;

    /* ---------------- background: wall, floor, window, art ---------------- */
    // floor boards radiate from a point above the room so the floor reads in perspective
    let boards = "";
    for (let x = -60; x <= 220; x += 14) boards += `M${x} ${FL + 1} L${80 + (x - 80) * 1.9} 100 `;
    const floor =
      `<rect y="${FL}" width="160" height="${100 - FL}" fill="${P.wood}"/>` +
      `<path d="${boards}" stroke="${P.wood2}" stroke-width=".5" opacity=".45"/>` +
      `<path d="M0 ${FL + 9} H160 M0 ${FL + 20} H160" stroke="${P.wood2}" stroke-width=".35" opacity=".25"/>` +
      `<rect y="${FL}" width="160" height="3" fill="#000" opacity=".08"/>`;
    // window: frame, sky view (h.skyFill so it is dark at night), hills, mullions, sill, curtains
    const wx = 100, wy = 8, ww = 48, wh = 50;
    const gx = wx + 3, gy = wy + 3, gw = ww - 6, gh = wh - 6;
    const view =
      `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" fill="${h.skyFill(P)}"/>` +
      (night ? `<g fill="${P.light}" opacity=".85"><circle cx="${gx + 6}" cy="${gy + 6}" r=".55"/><circle cx="${gx + 15}" cy="${gy + 12}" r=".45"/><circle cx="${gx + 27}" cy="${gy + 5}" r=".5"/><circle cx="${gx + 9}" cy="${gy + 19}" r=".4"/></g>` : "") +
      h.sunOrMoon(P, gx + 32, gy + 10, 3.6) +
      (night ? "" : `<g fill="${P.cloud}" opacity=".9"><ellipse cx="${gx + 10}" cy="${gy + 9}" rx="5" ry="2.2"/><ellipse cx="${gx + 13}" cy="${gy + 7.6}" rx="3.4" ry="2.4"/></g>`) +
      `<path d="M${gx} ${gy + gh - 10} Q${gx + 10} ${gy + gh - 17} ${gx + 22} ${gy + gh - 12} Q${gx + 32} ${gy + gh - 18} ${gx + gw} ${gy + gh - 13} V${gy + gh} H${gx}Z" fill="${P.far}"/>` +
      `<path d="M${gx} ${gy + gh - 5} Q${gx + 14} ${gy + gh - 9} ${gx + 26} ${gy + gh - 6} T${gx + gw} ${gy + gh - 6} V${gy + gh} H${gx}Z" fill="${P.mid}"/>` +
      `<g fill="${P.near}"><path d="M${gx + 33} ${gy + gh - 4} L${gx + 36} ${gy + gh - 15} L${gx + 39} ${gy + gh - 4}Z"/><path d="M${gx + 6} ${gy + gh - 4} L${gx + 8.4} ${gy + gh - 12} L${gx + 10.8} ${gy + gh - 4}Z"/></g>` +
      // a soft reflection across the glass
      `<path d="M${gx + 4} ${gy + gh} L${gx + 18} ${gy} H${gx + 24} L${gx + 10} ${gy + gh}Z" fill="#fff" opacity="${night ? .04 : .14}"/>`;
    const win =
      `<rect x="${wx - 1.4}" y="${wy + 1.4}" width="${ww + 2.8}" height="${wh}" rx="1.4" fill="#000" opacity=".06"/>` +
      `<rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" rx="1.4" fill="${trim}"/>` + view +
      `<path d="M${wx + ww / 2} ${gy} V${gy + gh} M${gx} ${gy + gh * .42} H${gx + gw}" stroke="${trim}" stroke-width="1.8"/>` +
      `<rect x="${wx - 3}" y="${wy + wh - 1}" width="${ww + 6}" height="3" rx="1" fill="${trim}"/>` +
      `<rect x="${wx - 3}" y="${wy + wh + 2}" width="${ww + 6}" height="1.2" fill="#000" opacity=".08"/>` +
      // curtains on a rod
      `<rect x="${wx - 9}" y="${wy - 4}" width="${ww + 18}" height="1.6" rx=".8" fill="${P.metal3}"/>` +
      `<path d="M${wx - 8} ${wy - 3} H${wx + 3} Q${wx + 1} ${wy + 30} ${wx + 4} ${FL - 1} H${wx - 9} Q${wx - 7} ${wy + 30} ${wx - 8} ${wy - 3}Z" fill="${P.wall2}"/>` +
      `<path d="M${wx - 4.6} ${wy - 3} Q${wx - 3.4} ${wy + 30} ${wx - 4} ${FL - 1}" stroke="#000" stroke-width="1.2" opacity=".08" fill="none"/>` +
      `<path d="M${wx + ww + 8} ${wy - 3} H${wx + ww - 3} Q${wx + ww - 1} ${wy + 30} ${wx + ww - 4} ${FL - 1} H${wx + ww + 9} Q${wx + ww + 7} ${wy + 30} ${wx + ww + 8} ${wy - 3}Z" fill="${P.wall2}"/>` +
      `<path d="M${wx + ww + 4.6} ${wy - 3} Q${wx + ww + 3.4} ${wy + 30} ${wx + ww + 4} ${FL - 1}" stroke="#000" stroke-width="1.2" opacity=".08" fill="none"/>`;
    // a door in the left wall (behind the clutter)
    const door =
      `<rect x="5" y="22" width="26" height="${FL - 22}" rx="1" fill="${trim}"/>` +
      `<rect x="7.6" y="24.6" width="20.8" height="${FL - 24.6}" fill="${P.wall2}"/>` +
      `<path d="M10.4 28h15.2v14H10.4zM10.4 46h15.2v20H10.4z" fill="#000" opacity=".06"/>` +
      `<rect x="24" y="48" width="2.6" height="1.4" rx=".7" fill="${P.metal3}"/>`;
    // abstract wall art above the sofa (no text)
    const ax = 46, ay = 13, aw = 40, ah = 26;
    const art =
      `<rect x="${ax + 1.4}" y="${ay + 1.8}" width="${aw}" height="${ah}" rx="1" fill="#000" opacity=".1"/>` +
      `<rect x="${ax}" y="${ay}" width="${aw}" height="${ah}" rx="1" fill="${P.wood2}"/>` +
      `<rect x="${ax + 1.6}" y="${ay + 1.6}" width="${aw - 3.2}" height="${ah - 3.2}" fill="${P.paper}"/>` +
      `<circle cx="${ax + 13}" cy="${ay + 12}" r="7" fill="${P.accent}"/>` +
      `<path d="M${ax + 1.6} ${ay + ah - 1.6} Q${ax + 14} ${ay + 12} ${ax + 26} ${ay + 18} T${ax + aw - 1.6} ${ay + 10} V${ay + ah - 1.6}Z" fill="${P.cloth}" opacity=".85"/>` +
      `<path d="M${ax + 1.6} ${ay + ah - 1.6} Q${ax + 18} ${ay + 17} ${ax + aw - 1.6} ${ay + ah - 6} V${ay + ah - 1.6}Z" fill="${P.cloth4}"/>` +
      `<circle cx="${ax + 29}" cy="${ay + 8}" r="3.4" fill="${P.sun}"/>`;
    // daylight patch on the floor from the window / lamp light washing the wall at night
    const light = night
      ? `<circle cx="104" cy="30" r="44" fill="${P.lamp}" opacity=".07"/><circle cx="104" cy="30" r="26" fill="${P.lamp}" opacity=".08"/>` +
        `<ellipse cx="104" cy="88" rx="40" ry="8" fill="${P.lamp}" opacity=".1"/>`
      : `<path d="M98 ${FL + 1} H150 L170 100 H112Z" fill="${P.light}" opacity=".14"/>`;
    const bg =
      `<rect width="160" height="100" fill="${P.wall}"/>` +
      `<rect width="160" height="5" fill="#000" opacity=".04"/>` +
      door + art + win + floor +
      `<rect y="${FL - 2.6}" width="160" height="3" fill="${trim}"/>` +
      `<rect y="${FL - 2.6}" width="160" height=".7" fill="#000" opacity=".06"/>` +
      light;

    /* ---------------- subject: the furniture group ---------------- */
    const sofaC = P.cloth, sofaD = P.cloth2;
    const rug =
      `<path d="M42 78 H116 L134 97 H26Z" fill="${P.wall2}"/>` +
      `<path d="M45.4 80 H112.6 L128.6 95 H31.4Z" fill="none" stroke="${P.light}" stroke-width="1" opacity=".8"/>` +
      `<path d="M50 84 H108 M44 90 H116" stroke="${P.metal2}" stroke-width=".6" opacity=".7"/>`;
    // potted plant to the right of the lamp (leaves drawn around x = px)
    const px = 141, L = (x) => x + px - 27;
    const plant =
      `<ellipse cx="${px}" cy="88.4" rx="8" ry="1.8" fill="#000" opacity=".22"/>` +
      `<g fill="${P.cloth4}">` +
        `<ellipse cx="${L(20)}" cy="62" rx="3.6" ry="11" transform="rotate(-28 ${L(20)} 62)"/>` +
        `<ellipse cx="${L(34)}" cy="60" rx="3.6" ry="11" transform="rotate(26 ${L(34)} 60)"/>` +
        `<ellipse cx="${px}" cy="54" rx="3.8" ry="12.5"/>` +
        `<ellipse cx="${L(17.6)}" cy="72" rx="3" ry="8.2" transform="rotate(-40 ${L(17.6)} 72)"/>` +
        `<ellipse cx="${L(36.4)}" cy="71" rx="3" ry="8.2" transform="rotate(42 ${L(36.4)} 71)"/>` +
      `</g>` +
      `<g fill="${P.mid}" opacity=".55"><ellipse cx="${L(34)}" cy="60" rx="3.6" ry="11" transform="rotate(26 ${L(34)} 60)"/><ellipse cx="${L(36.4)}" cy="71" rx="3" ry="8.2" transform="rotate(42 ${L(36.4)} 71)"/></g>` +
      `<path d="M${px} 76V44M${px} 72L${L(19)} 58M${px} 72L${L(35)} 57" stroke="#000" stroke-width=".5" opacity=".15"/>` +
      `<path d="M${L(20.6)} 76H${L(33.4)}L${L(32)} 88.6H${L(22)}Z" fill="${P.cloth3}"/>` +
      `<path d="M${px} 76H${L(33.4)}L${L(32)} 88.6H${px}Z" fill="#000" opacity=".12"/>` +
      `<rect x="${L(20)}" y="75" width="14" height="2.4" rx="1" fill="${P.cloth3}"/>`;
    const sofa =
      `<ellipse cx="78" cy="81.4" rx="44" ry="3" fill="#000" opacity=".22"/>` +
      `<g fill="${P.wood2}"><rect x="43" y="77" width="2.2" height="4.6" rx=".8"/><rect x="110.8" y="77" width="2.2" height="4.6" rx=".8"/></g>` +
      // back + back cushions
      `<rect x="42" y="44" width="72" height="26" rx="6" fill="${sofaD}"/>` +
      `<rect x="45.6" y="46.6" width="31.6" height="20" rx="4.6" fill="${sofaC}"/>` +
      `<rect x="78.8" y="46.6" width="31.6" height="20" rx="4.6" fill="${sofaC}"/>` +
      `<rect x="47.6" y="48" width="27.6" height="3" rx="1.5" fill="${P.light}" opacity=".16"/><rect x="80.8" y="48" width="27.6" height="3" rx="1.5" fill="${P.light}" opacity=".16"/>` +
      // seat + front
      `<rect x="44" y="63" width="68" height="9" rx="3" fill="${sofaC}"/>` +
      `<rect x="44" y="63" width="68" height="2.4" rx="1.2" fill="${P.light}" opacity=".14"/>` +
      `<path d="M78 63.4 V71.6" stroke="${sofaD}" stroke-width=".8"/>` +
      `<rect x="40" y="70.4" width="76" height="7.4" rx="2.4" fill="${sofaD}"/>` +
      // arms
      `<rect x="35.4" y="54" width="12" height="23.8" rx="5" fill="${sofaC}"/>` +
      `<rect x="35.4" y="54" width="12" height="4" rx="2" fill="${P.light}" opacity=".16"/>` +
      `<rect x="42.4" y="58" width="5" height="19.8" rx="2.5" fill="#000" opacity=".1"/>` +
      `<rect x="108.6" y="54" width="12" height="23.8" rx="5" fill="${sofaC}"/>` +
      `<rect x="108.6" y="54" width="12" height="4" rx="2" fill="${P.light}" opacity=".16"/>` +
      `<rect x="108.6" y="58" width="5" height="19.8" rx="2.5" fill="#000" opacity=".1"/>` +
      // throw cushions
      `<rect x="49" y="53.6" width="13" height="11" rx="3.4" fill="${P.sun}" transform="rotate(-10 55.5 59)"/>` +
      `<rect x="49" y="53.6" width="13" height="11" rx="3.4" fill="#000" opacity=".08" transform="rotate(-10 55.5 59) translate(0 6)" />` +
      `<rect x="94" y="53.6" width="13" height="11" rx="3.4" fill="${P.cloth3}" transform="rotate(9 100.5 59)"/>` +
      `<rect x="84" y="56" width="10" height="8.6" rx="3" fill="${P.light}" transform="rotate(6 89 60)"/>`;
    const table =
      `<ellipse cx="78" cy="92.6" rx="21" ry="2.2" fill="#000" opacity=".2"/>` +
      `<g fill="${P.wood2}"><rect x="62.4" y="84" width="2" height="8.6" rx=".8"/><rect x="91.6" y="84" width="2" height="8.6" rx=".8"/><rect x="68" y="84" width="1.6" height="6" rx=".6" opacity=".7"/><rect x="86.4" y="84" width="1.6" height="6" rx=".6" opacity=".7"/></g>` +
      `<ellipse cx="78" cy="83.6" rx="20" ry="3.4" fill="${P.metal2}"/>` +
      `<ellipse cx="78" cy="82.6" rx="20" ry="3.4" fill="${P.light}"/>` +
      // books, a mug and a vase with a sprig
      `<rect x="64" y="79.6" width="11" height="2.2" rx=".6" fill="${P.cloth4}"/><rect x="65" y="77.6" width="9" height="2.2" rx=".6" fill="${P.accent}"/>` +
      `<rect x="80.6" y="78.6" width="3.2" height="3.4" rx=".8" fill="${P.cloth}"/>` +
      `<path d="M88.4 82 Q87 77 89.6 74.6 Q92.2 77 90.8 82Z" fill="${P.ink}" opacity=".75"/>` +
      `<path d="M89.6 75 Q89 69 86 66.4 M89.6 74 Q91 70 94 68.6" stroke="${P.cloth4}" stroke-width=".9" fill="none" stroke-linecap="round"/>` +
      `<g fill="${P.cloth4}"><ellipse cx="86.4" cy="67" rx="1.6" ry=".9"/><ellipse cx="93.6" cy="68.8" rx="1.6" ry=".9"/></g>`;
    // arc floor lamp; the shade glows at night
    const lampGlow = night
      ? `<circle cx="104" cy="32" r="16" fill="${P.lamp}" opacity=".18"/><circle cx="104" cy="32" r="8" fill="${P.lamp}" opacity=".35"/>`
      : "";
    const lamp =
      `<ellipse cx="122" cy="88.6" rx="7" ry="1.6" fill="#000" opacity=".22"/>` +
      `<path d="M122 88V40Q122 18 104 22.6" stroke="${P.ink}" stroke-width="1.5" fill="none" stroke-linecap="round"/>` +
      `<ellipse cx="122" cy="87.6" rx="5.4" ry="1.6" fill="${P.ink}"/>` +
      lampGlow +
      `<path d="M96.4 31Q96.6 22 104 21.4Q111.4 22 111.6 31Z" fill="${P.ink}"/>` +
      `<path d="M104 21.4Q111.4 22 111.6 31H104Z" fill="#fff" opacity=".1"/>` +
      `<ellipse cx="104" cy="31" rx="7.6" ry="1.6" fill="${night ? P.lamp : P.paper}"/>`;
    const subject = o.empty ? "" : `<g>${rug}${plant}${sofa}${table}${lamp}</g>`;

    /* ---------------- extra: clutter, on the left ---------------- */
    // cardboard boxes stacked in front of the door, a laundry basket before them;
    // all of it left of the rug and the sofa, so none of it hides behind them
    const box = (x, y, w, hh, flaps) =>
      `<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx=".8" fill="${P.wood}"/>` +
      // kraft card: lighter than the wood floor it stands on
      `<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx=".8" fill="${P.light}" opacity=".34"/>` +
      `<rect x="${x + w * .62}" y="${y}" width="${w * .38}" height="${hh}" fill="#000" opacity=".12"/>` +
      `<rect x="${x + w / 2 - 1.2}" y="${y}" width="2.4" height="${hh * .45}" fill="${P.paper}" opacity=".8"/>` +
      (flaps ? `<path d="M${x} ${y}L${x - 2.4} ${y - 3.6}M${x + w} ${y}L${x + w + 2.4} ${y - 3.6}" stroke="${P.wood2}" stroke-width="1.4" stroke-linecap="round"/>` : "");
    const extra =
      `<g>` +
      `<ellipse cx="19" cy="89.6" rx="14" ry="1.8" fill="#000" opacity=".22"/>` +
      box(7, 72, 23, 17.6) + box(10, 58.4, 16.4, 13.6, true) +
      // laundry basket with clothes spilling out
      `<ellipse cx="13" cy="97.8" rx="12" ry="1.8" fill="#000" opacity=".25"/>` +
      `<path d="M5 81Q9 75 14 79Q17 74 21 80" fill="${P.cloth3}"/>` +
      `<path d="M3.6 82Q7 77.6 11 81L6 83Z" fill="${P.light}"/>` +
      `<path d="M15 81Q19 76 23 81Z" fill="${P.cloth}"/>` +
      // light wicker
      `<path d="M2 82H24L22 98H4Z" fill="${P.paper}"/>` +
      `<path d="M2 82H24L22 98H4Z" fill="${P.wood}" opacity=".4"/>` +
      `<path d="M3 86H23M3.6 90H22.4M4 94H22" stroke="${P.wood2}" stroke-width=".7" opacity=".6"/>` +
      `<rect x="1" y="81" width="24" height="2.6" rx="1.3" fill="${P.wood2}"/>` +
      `<path d="M23 98.6Q26 95 30 97.6Q28 100 23 98.6Z" fill="${P.cloth4}"/>` +
      `</g>`;

    return { bg, subject, extra, face: { x: 78, y: 52, r: 22 } };
  });
})();

/* ---- product ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Product: a skincare set — a dropper bottle and a jar on a round stone
     plinth, on a wooden vanity by a window (a shelf with a plant and a
     candle behind). option color: the bottle / lid colour (hex).
     extra: a bud vase with eucalyptus on the left of the counter. */
  A.scene("product", (P, o, h) => {
    o = o || {};
    const N = !!P.night;
    const c = typeof o.color === "string" && /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(o.color.trim()) ? o.color.trim() : P.accent2;
    const dim = (d) => N ? `<path d="${d}" fill="#0a1430" opacity=".28"/>` : "";

    /* ---------- background: vanity by a window ---------- */
    let tiles = "";
    for (let r = 0; r < 3; r++) {
      const y = 45 + r * 6;
      for (let x = (r % 2) * 6 - 6; x < 160; x += 12) tiles += `M${x} ${y}v6`;
    }
    const st = (x, y, r) => `M${x - r} ${y}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`;
    const bg =
      // warm plaster wall over a cream tiled splash-back
      `<rect width="160" height="100" fill="${P.wall}"/><rect width="160" height="63" fill="${P.wood}" opacity="${N ? .12 : .24}"/>` +
      `<rect y="45" width="160" height="18" fill="${P.paper}" opacity="${N ? .05 : .6}"/>` +
      `<path d="M0 45H160M0 51H160M0 57H160${tiles}" stroke="${P.wall2}" stroke-width=".8" fill="none"/>` +
      // the decor is drawn mirrored: window on the right (the "after" half shows
      // the sky change), shelf with plant and candle on the left
      `<g transform="matrix(-1 0 0 1 160 0)">` +
      // window
      `<rect x="10" y="2" width="44" height="40" rx="2" fill="${P.light}"/>` +
      `<rect x="13" y="5" width="38" height="34" fill="${h.skyFill(P)}"/>` +
      h.sunOrMoon(P, 41, 14, 4) +
      (N ? `<path d="${st(18, 10, .6)}${st(25, 19, .5)}${st(47, 25, .5)}${st(30, 9, .45)}" fill="#fff" opacity=".85"/>` : "") +
      `<path d="M13 39V31Q22 26 31 30T51 28V39Z" fill="${P.far}"/>` +
      `<path d="M13 39V35Q19 32 25 35Q33 32 40 36Q46 33 51 35V39Z" fill="${P.mid}"/>` +
      `<path d="M32 5V39M13 22H51" stroke="${P.light}" stroke-width="2"/>` +
      `<rect x="8" y="40" width="48" height="3" rx="1" fill="${P.light}"/><rect x="9" y="43" width="46" height="1.4" fill="${P.shade}"/>` +
      // sheer curtain
      `<path d="M3 0H17Q13 22 18 46H3Z" fill="${P.paper}" opacity=".75"/><path d="M8 0Q7 24 10 45M13 0Q11 24 14 45" stroke="${P.wall2}" stroke-width=".8" fill="none" opacity=".7"/>` +
      // shelf with a plant and a candle
      `<rect x="110" y="32" width="46" height="3" rx="1" fill="${P.wood}"/><rect x="111" y="35" width="44" height="1.6" fill="${P.wood2}"/>` +
      `<path d="M122 24C116 21 113 15 115 10C120 13 122 18 122 24ZM123 24C123 17 126 11 131 9C132 15 128 21 123 24ZM122.5 24C119 18 121 10 123 6C126 11 126 18 122.5 24Z" fill="${P.cloth4}"/>` +
      `<path d="M122.5 24C121 18 122 11 123 6C126 11 126 18 122.5 24Z" fill="#000" opacity=".14"/>` +
      `<path d="M117.5 24H127.5L126.5 32H118.5Z" fill="${P.paper}"/><path d="M123.5 24H127.5L126.5 32H123Z" fill="#000" opacity=".1"/>` +
      (N ? `<g fill="${P.lamp}"><circle cx="143" cy="23" r="10" opacity=".07"/><circle cx="143" cy="23" r="7.4" opacity=".1"/><circle cx="143" cy="23" r="5" opacity=".16"/><circle cx="143" cy="23" r="2.8" opacity=".45"/></g><ellipse cx="143" cy="32.6" rx="9" ry="1.2" fill="${P.lamp}" opacity=".3"/>` : "") +
      `<rect x="138" y="25" width="10" height="7" rx="1.5" fill="${P.metal2}"/><rect x="139" y="26" width="8" height="3" rx="1" fill="${P.paper}"/>` +
      `<path d="M143 21.2Q144.6 23.4 143 25Q141.4 23.4 143 21.2Z" fill="${N ? P.lamp : P.sun}"/>` +
      `</g>` +
      // counter, with the window light falling across it
      `<rect y="63" width="160" height="29" fill="${P.wood}"/><rect y="63" width="160" height="1.6" fill="${P.shade}"/>` +
      `<path d="M0 71Q40 69 80 72T160 70M0 81Q50 79 100 82T160 80" stroke="${P.wood2}" stroke-width=".6" fill="none" opacity=".4"/>` +
      (N ? "" : `<path d="M146 64H104L82 91H130Z" fill="${P.light}" opacity=".16"/>`) +
      `<rect y="91" width="160" height="9" fill="${P.wood2}"/><rect y="91" width="160" height="1" fill="${P.light}" opacity=".2"/>`;

    /* ---------- subject: plinth, dropper bottle, jar ---------- */
    const bottle = "M66 75V54Q66 48.5 71 48.5H77Q82 48.5 82 54V75Q82 77 80 77H68Q66 77 66 75Z";
    const lid = "M87.5 61.5V66.6A10.5 2.3 0 0 0 108.5 66.6V61.5Z";
    const subject =
      h.shadow(94.5, 86.6, 39, 4, .24) +
      // scaled up and set so the bottle straddles the 50% divider
      `<g transform="matrix(1.2 0 0 1.2 -9.8 -17.4)">` +
      // plinth
      // mid-tone stone, so the white jar and the label keep a clear edge
      `<path d="M57 73V83A27 5 0 0 0 111 83V73Z" fill="${P.metal3}"/>` +
      `<path d="M100 77Q106 76 111 73V83Q107 86 100 87Z" fill="#000" opacity=".12"/>` +
      `<ellipse cx="84" cy="73" rx="27" ry="5" fill="${P.metal2}"/>` +
      `<path d="M60 75.6V83.4" stroke="${P.light}" stroke-width="1.4" opacity=".3" stroke-linecap="round"/>` +
      h.shadow(75, 77, 9.5, 1.8, .16) + h.shadow(99, 79.2, 12, 2.2, .16) +
      // dropper bottle
      `<path d="M71 42V35Q71 30 74 30Q77 30 77 35V42Z" fill="${P.ink}"/>` +
      `<rect x="72" y="32" width="1.4" height="7" rx=".7" fill="#fff" opacity=".3"/>` +
      `<rect x="70" y="41" width="8" height="8" rx="1.3" fill="${P.metal2}"/><rect x="71" y="42" width="2" height="6" rx="1" fill="#fff" opacity=".55"/>` +
      `<path d="${bottle}" fill="${c}"/>` +
      `<path d="M77 48.5Q82 48.5 82 54V75Q82 77 80 77H77Z" fill="#000" opacity=".16"/>` +
      `<path d="M68 52a1 1 0 0 1 2 0v3a1 1 0 0 1 -2 0zM68 72a1 1 0 0 1 2 0v2a1 1 0 0 1 -2 0z" fill="#fff" opacity=".5"/>` +
      `<rect x="67.5" y="58" width="13" height="12" rx="2" fill="${P.paper}"/>` +
      `<rect x="70" y="61.5" width="8" height="2" rx="1" fill="${c}"/><rect x="71.25" y="65.4" width="5.5" height="1.4" rx=".7" fill="${P.metal2}"/>` +
      dim(bottle) +
      // jar
      `<path d="M88 66.5V77.5A10 2.4 0 0 0 108 77.5V66.5Z" fill="${P.paper}"/>` +
      `<path d="M101.5 66.5H108V77.5Q106 79.3 101.5 79.8Z" fill="#000" opacity=".09"/>` +
      `<rect x="90.5" y="70" width="9" height="5" rx="1.5" fill="${c}" opacity=".3"/>` +
      `<path d="${lid}" fill="${c}"/><ellipse cx="98" cy="61.5" rx="10.5" ry="2.3" fill="${c}"/>` +
      `<ellipse cx="98" cy="61.5" rx="10.5" ry="2.3" fill="#fff" opacity=".28"/>` +
      `<path d="M102 63.6Q106 63.2 108.5 61.5V66.6Q106 68.5 102 68.8Z" fill="#000" opacity=".14"/>` +
      dim(lid + "M87.5 61.5A10.5 2.3 0 0 1 108.5 61.5A10.5 2.3 0 0 1 87.5 61.5Z") +
      `</g>`;

    /* ---------- extra: eucalyptus in a bud vase ---------- */
    const lf = (x, y, r) => `M${x - r} ${y}a${r} ${r * .85} 0 1 0 ${2 * r} 0a${r} ${r * .85} 0 1 0 ${-2 * r} 0`;
    const leaves = [[29, 47, 2.4], [32, 52, 2.6], [27.5, 54, 2.2], [34, 58, 2.5], [44, 45, 2.4], [41, 50, 2.6], [45, 53, 2.3], [39, 57, 2.4], [36.5, 49, 2.2], [37, 43, 2.3], [35, 63, 2]];
    const extra =
      h.shadow(38, 79.4, 8, 1.6, .18) +
      `<path d="M37 72C36 62 32 54 27 45M37 72C38 61 41 52 45 44M37 72C37 64 36 54 37 42" stroke="${P.cloth4}" stroke-width=".9" fill="none"/>` +
      // dusty sage: the leaf green softened with grey, unlike the shelf plant
      `<path d="${leaves.map(l => lf(...l)).join("")}" fill="${P.cloth4}"/><path d="${leaves.map(l => lf(...l)).join("")}" fill="${P.metal2}" opacity=".5"/>` +
      `<path d="${leaves.filter((_, i) => i % 2).map(l => lf(...l)).join("")}" fill="#fff" opacity=".22"/>` +
      `<path d="M35 66Q31.5 71 32 75.5Q33 79.2 38 79.2Q43 79.2 44 75.5Q44.5 71 41 66Z" fill="${P.metal}" opacity=".7"/>` +
      `<path d="M32.4 73Q38 74 43.6 73Q44 76 42.8 77.6Q38 79.6 33.2 77.6Q32.2 76 32.4 73Z" fill="${P.water}" opacity=".45"/>` +
      `<rect x="34.6" y="64.5" width="6.8" height="2" rx="1" fill="${P.metal2}"/>` +
      `<path d="M34 70Q33 74 34.4 77" stroke="#fff" stroke-width=".9" opacity=".6" fill="none" stroke-linecap="round"/>`;

    return { bg, subject, extra, face: { x: 79, y: 59.5, r: 13 } };
  });
})();

/* ---- food ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Food: a burger with fries on a plate and a glass of cola, on a café
     table under a pendant lamp, a window behind.
     extra: table clutter on the left — a phone and a crumpled napkin. */
  A.scene("food", (P, o, h) => {
    o = o || {};
    const N = !!P.night;

    /* ---------- background: café wall, window, lamp, table ---------- */
    let panels = "";
    for (let x = 14; x < 160; x += 22) panels += `M${x} 44V55`;
    const bg =
      // warm cream wall over a green café wainscot
      `<rect width="160" height="100" fill="${P.wall}"/><rect width="160" height="41" fill="${P.lamp}" opacity="${N ? .06 : .22}"/>` +
      `<rect y="41" width="160" height="16" fill="${P.cloth4}"/><rect y="41" width="160" height="16" fill="#000" opacity=".3"/>` +
      `<rect y="41" width="160" height="1.4" fill="${P.light}" opacity="${N ? .2 : .55}"/>` +
      `<path d="${panels}" stroke="#000" stroke-width=".8" opacity=".18"/>` +
      // window with a street view
      `<rect x="6" y="3" width="48" height="36" rx="2" fill="${P.light}"/>` +
      `<rect x="9" y="6" width="42" height="30" fill="${h.skyFill(P)}"/>` +
      h.sunOrMoon(P, 42, 13, 3.6) +
      `<path d="M9 36V22H16V18H23V36ZM26 36V25H33V20H40V36ZM42 36V27H51V36Z" fill="${P.far}"/>` +
      `<path d="M11 24h2v2h-2zM18 21h2v2h-2zM18 27h2v2h-2zM28 27h2v2h-2zM35 23h2v2h-2zM35 29h2v2h-2zM45 30h2v2h-2z" fill="${P.glass}" opacity="${N ? 1 : .7}"/>` +
      `<path d="M30 6V36" stroke="${P.light}" stroke-width="2"/>` +
      `<rect x="4" y="38" width="52" height="3" rx="1" fill="${P.light}"/>` +
      // framed print
      `<rect x="137" y="6" width="19" height="24" rx="1" fill="${P.wood2}"/><rect x="139" y="8" width="15" height="20" fill="${P.paper}"/>` +
      `<circle cx="148.5" cy="15" r="3" fill="${P.accent}" opacity=".85"/><path d="M140.5 26.5V22Q144 18 147.5 21.5Q150 19.5 152.5 22V26.5Z" fill="${P.cloth4}"/>` +
      // pendant lamp over the plate, clear of the 50% divider so it is whole
      // on the "after" half (it lights up at night)
      `<path d="M101 0V8" stroke="${P.ink}" stroke-width=".8"/>` +
      (N ? `<path d="M92 16L73 62H129L110 16Z" fill="${P.lamp}" opacity=".1"/><g fill="${P.lamp}"><circle cx="101" cy="16" r="9" opacity=".12"/><circle cx="101" cy="16" r="5.5" opacity=".2"/></g>` : "") +
      `<path d="M90 17Q90 8 101 7.5Q112 8 112 17Z" fill="${P.ink}"/><path d="M101 7.5Q112 8 112 17H105Q105 10 101 7.5Z" fill="#fff" opacity=".1"/>` +
      `<ellipse cx="101" cy="17" rx="4" ry="2" fill="${N ? P.lamp : P.metal}"/>` +
      // table
      `<rect y="56" width="160" height="44" fill="${P.wood}"/><rect y="56" width="160" height="2" fill="${P.wood2}" opacity=".6"/>` +
      `<path d="M0 65H160M0 77H160M0 92H160" stroke="${P.wood2}" stroke-width=".7" opacity=".45"/>` +
      (N ? `<ellipse cx="98" cy="78" rx="46" ry="13" fill="${P.lamp}" opacity=".12"/>` : "");

    /* ---------- subject: plate, burger, fries, glass ---------- */
    const bunLo = P.wood2;
    // toasted bun tone mixed from palette colours (wood + accent + lamp)
    const toast = (d) => `<path d="${d}" fill="${P.wood}"/><path d="${d}" fill="${P.accent}" opacity=".45"/><path d="${d}" fill="${P.lamp}" opacity=".35"/>`;
    // fries as thin slanted sticks
    const fries = [[95, 48, -3], [98, 45, 1], [101, 47, 4], [104, 50, 7], [96.5, 52, -6], [100, 51, 2], [103, 54, 9], [94, 55, -9]];
    const fry = ([x, y, d]) => `M${x} ${y}l2.4 0l${-d * .5 + .4} 14l-2.6 0z`;
    const seeds = [[66, 47, -20], [72, 45, 0], [78, 46.5, 15], [84, 49, 30], [62, 51.5, -35], [70, 50, -5], [76, 51, 10]];
    const lettuce = "M52.6 63.4Q56 61.4 59 63.2Q62 61 65.5 63Q69 61 72.5 63.2Q76 61 79.5 63.2Q83 61 86.5 63.2Q90 61 93.6 63.4Q94 66 91 66.2Q88 67.6 85 66.2Q81.5 67.8 78.5 66.2Q75 67.8 72 66.2Q68.5 67.8 65.5 66.2Q62 67.8 59 66.2Q56 67.6 54 66.4Q52 65.6 52.6 63.4Z";
    const dome = "M55 59.4Q54 42 73 41.4Q92 42 91 59.4Q91 61 89 61H57Q55 61 55 59.4Z";
    const subject =
      // glass shadow + plate shadow
      h.shadow(127, 80.4, 9, 2.2, .2) + h.shadow(81, 84, 41, 7, .2) +
      // glass of cola (behind the plate, right)
      `<path d="M118 38H136L134 79Q127 81 120 79Z" fill="${P.light}" opacity=".35"/>` +
      `<path d="M118.6 47H135.4L134 78.4Q127 80.4 120 78.4Z" fill="${P.wood2}"/>` +
      `<ellipse cx="127" cy="47" rx="8.4" ry="1.6" fill="${P.wood}"/>` +
      `<path d="M121 50.5l5 -1.6l1.6 4.6l-5 1.6zM127.5 52l4.6 .8l-.8 4.6l-4.6 -.8z" fill="#fff" opacity=".32"/>` +
      `<g fill="#fff" opacity=".55"><circle cx="124" cy="64" r=".7"/><circle cx="130" cy="69" r=".6"/><circle cx="126" cy="73" r=".8"/><circle cx="131" cy="60" r=".5"/></g>` +
      `<path d="M131 26L127.6 58" stroke="${P.light}" stroke-width="2.4" stroke-linecap="round"/>` +
      `<path d="M131 26L127.6 58" stroke="${P.accent}" stroke-width="2.4" stroke-dasharray="2.2 2.2"/>` +
      `<rect x="119.6" y="40" width="1.8" height="36" rx=".9" fill="#fff" opacity=".55"/>` +
      `<circle cx="119" cy="40" r="5.2" fill="${P.lamp}"/><circle cx="119" cy="40" r="4" fill="${P.paper}" opacity=".55"/>` +
      `<path d="M119 36.4V43.6M115.4 40H122.6M116.5 37.5L121.5 42.5M121.5 37.5L116.5 42.5" stroke="${P.lamp}" stroke-width=".6"/>` +
      `<ellipse cx="127" cy="38" rx="9" ry="1.7" fill="none" stroke="${P.light}" stroke-width=".6" opacity=".8"/>` +
      // plate
      `<ellipse cx="81" cy="81.6" rx="41" ry="11.4" fill="${P.metal2}"/>` +
      `<ellipse cx="81" cy="80.6" rx="41" ry="10.8" fill="${P.light}"/>` +
      `<ellipse cx="81" cy="80.8" rx="31" ry="7.6" fill="${P.metal}"/>` +
      // fries in a carton
      `<path d="${fries.map(fry).join("")}" fill="${P.lamp}"/>` +
      `<path d="${fries.filter((_, i) => i % 2).map(fry).join("")}" fill="${P.wood2}" opacity=".28"/>` +
      `<path d="M92 60Q95.5 63 99.5 60.6Q103.5 63 107.5 60L105.2 80H94.4Z" fill="${P.cloth3}"/>` +
      `<path d="M100.5 61.5Q104 63 107.5 60L105.2 80H100Z" fill="#000" opacity=".12"/>` +
      `<path d="M93.6 70.5H106.2L105.9 73H93.9Z" fill="${P.light}" opacity=".85"/>` +
      // burger
      `<path d="M55 74Q55 81 62 81H84Q91 81 91 74Z" fill="${bunLo}"/><path d="M55 74Q55 81 62 81H84Q91 81 91 74Z" fill="${P.accent}" opacity=".3"/>` +
      toast("M55 74H91Q91 77 88 77.6H58Q55 77 55 74Z") +
      `<rect x="53.5" y="65.6" width="39" height="9" rx="4.5" fill="${P.hair}"/>` +
      `<path d="M57 69.5h3M66 71.5h4M77 69h3M84 71h3" stroke="${P.wood2}" stroke-width="1" stroke-linecap="round" opacity=".7"/>` +
      `<path d="M54 65.5H92.4Q93 67 90.6 68.6L88 71.6Q86.4 73 85.4 71.2L84 68.8Q81 70.4 78 69Q74 74 71 69.2Q67 70.4 63.5 68.8L61.8 72.4Q60.6 74 59.6 72L58 68.8Q54 68.4 54 65.5Z" fill="${P.lamp}"/>` +
      `<path d="${lettuce}" fill="${P.cloth4}"/>` +
      `<path d="${lettuce}" fill="${P.lamp}" opacity=".35"/>` +
      `<path d="M54 60H92Q93.8 61.8 92 63.6H54Q52.2 61.8 54 60Z" fill="${P.cloth3}"/>` +
      toast(dome) +
      `<path d="M91 59.4Q92 42 73 41.4Q86 45 86 61H89Q91 61 91 59.4Z" fill="${bunLo}" opacity=".45"/>` +
      `<ellipse cx="66" cy="49" rx="6" ry="3.2" transform="rotate(-25 66 49)" fill="${P.light}" opacity=".3"/>` +
      `<path d="${seeds.map(([x, y, a]) => { const r = a * Math.PI / 180, dx = Math.cos(r) * 1.1, dy = Math.sin(r) * 1.1; return `M${(x - dx).toFixed(2)} ${(y - dy).toFixed(2)}L${(x + dx).toFixed(2)} ${(y + dy).toFixed(2)}`; }).join("")}" stroke="${P.paper}" stroke-width="1.2" stroke-linecap="round"/>` +
      "";

    /* ---------- extra: phone + crumpled napkin ---------- */
    const extra =
      // a crumpled paper napkin: an angular ball with shaded facets
      h.shadow(37, 73.4, 10, 2, .18) +
      `<path d="M28.6 72L27.6 67L30.4 62.6L35.6 60.8L41 61.6L45.4 64.4L46.6 69L43.6 72.6L36.4 73.8Z" fill="${P.paper}"/>` +
      `<path d="M35.6 60.8L37.4 66.4L46.6 69L45.4 64.4L41 61.6ZM28.6 72L32.8 67.6L37.4 66.4L36.4 73.8Z" fill="#000" opacity=".12"/>` +
      `<path d="M37.4 66.4L43.6 72.6M30.4 62.6L32.8 67.6" stroke="#000" stroke-width=".7" stroke-linecap="round" opacity=".16"/>` +
      h.shadow(22.5, 86.9, 18, 3.2, .2) +
      `<g transform="translate(21.5 82.5) rotate(-9) skewX(-24)">` +
      `<rect x="-14" y="-6.4" width="28" height="12.8" rx="2.6" fill="${P.ink}"/>` +
      `<rect x="-12.6" y="-5" width="25.2" height="10" rx="1.6" fill="#2f6fdc"/>` +
      `<rect x="-10.6" y="-3.4" width="10" height="2" rx="1" fill="${P.light}" opacity=".75"/>` +
      `<rect x="-10.6" y=".2" width="15" height="1.6" rx=".8" fill="${P.light}" opacity=".4"/>` +
      `<path d="M2 -5H8L0 5H-6Z" fill="#fff" opacity=".12"/>` +
      `</g>`;

    return { bg, subject, extra, face: { x: 73, y: 61, r: 15 } };
  });
})();

/* ---- object ---- */
(() => {
  const A = window.PSNAP_ART; if (!A) return;
  /* Object: a vintage film SLR (silver top, black leatherette, big lens,
     leather strap) product-shot on a wooden desk. Behind: instant photos
     on a string of fairy lights and a small plant.
     extra: a 35 mm film canister with its leader out, left of the camera. */
  A.scene("object", (P, o, h) => {
    o = o || {};
    const N = !!P.night;
    const circ = (x, y, r) => `M${x - r} ${y}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`;

    /* ---------- background: wall, fairy lights + photos, desk ---------- */
    const bulbs = [[98, 8.6], [108, 11.6], [118, 13.6], [128, 14.4], [138, 13.6], [148, 11.4], [157, 8.4]];
    const photo = (x, y, a, scene) =>
      `<g transform="rotate(${a} ${x} ${y})">` +
      `<rect x="${x - 8.6}" y="${y - 9.4}" width="17.2" height="20" rx=".8" fill="#000" opacity=".12" transform="translate(.8 1)"/>` +
      `<rect x="${x - 8.6}" y="${y - 9.4}" width="17.2" height="20" rx=".8" fill="${P.paper}"/>` +
      `<rect x="${x - 7.2}" y="${y - 8}" width="14.4" height="13" fill="${h.skyFill(P)}"/>` + scene +
      `<rect x="${x - 1.2}" y="${y - 11}" width="2.4" height="3.6" rx=".6" fill="${P.wood}"/>` +
      `</g>`;
    const bg =
      // blush backdrop: mid-tone, so both the silver and the black read
      `<rect width="160" height="100" fill="${P.wall}"/><rect width="160" height="68" fill="${P.cloth3}" opacity=".32"/>` +
      // window light on the wall, tinted by the sun (warm at golden hour)
      (N ? "" : `<path d="M8 6H26L18 58H0V36ZM32 6H44L36 58H24Z" fill="${P.light}" opacity=".3"/><path d="M8 6H26L18 58H0V36ZM32 6H44L36 58H24Z" fill="${P.sun}" opacity=".16"/>`) +
      // string of lights with two instant photos
      `<path d="M94 6Q126 20 160 6" stroke="${P.ink}" stroke-width=".5" fill="none" opacity=".7"/>` +
      photo(113, 23, -7, `<path d="M105.8 28V24L109 19L113 23L116 20L120.2 25V28Z" fill="${P.far}"/>` +
        `<circle cx="116" cy="18" r="1.8" fill="${P.sun}"/>`) +
      photo(141, 22, 6, `<rect x="${141 - 7.2}" y="${22 + 1}" width="14.4" height="4" fill="${P.water}"/><circle cx="141" cy="21.8" r="2.6" fill="${P.sun}"/>` +
        `<path d="M133.8 27V25.4Q141 24 148.2 25.4V27Z" fill="${P.wall2}"/>`) +
      (N ? `<path d="${bulbs.map(([x, y]) => circ(x, y + .4, 4)).join("")}" fill="${P.lamp}" opacity=".12"/><path d="${bulbs.map(([x, y]) => circ(x, y + .4, 2.4)).join("")}" fill="${P.lamp}" opacity=".3"/>` : "") +
      `<path d="${bulbs.map(([x, y]) => circ(x, y + .4, 1.1)).join("")}" fill="${N ? P.lamp : P.light}"/>` +
      `<path d="${bulbs.map(([x, y]) => circ(x, y + .4, 1.1)).join("")}" fill="none" stroke="${P.metal2}" stroke-width=".35" opacity="${N ? 0 : 1}"/>` +
      // small plant at the back right of the desk
      `<path d="M141 60C135 58 133 52 135 47C139 50 141 55 141 60ZM142 60C142 54 145 49 150 47C151 53 147 58 142 60ZM141.5 60C139 54 140 47 142 43C145 47 145 54 141.5 60Z" fill="${P.cloth4}"/>` +
      `<path d="M141.5 60C140 54 141 48 142 43C145 47 145 54 141.5 60Z" fill="#000" opacity=".14"/>` +
      h.shadow(142, 71, 9, 1.6, .16) +
      `<path d="M135.5 59.6H148.5L147 71H137Z" fill="${P.paper}"/><path d="M142.6 59.6H148.5L147 71H142.4Z" fill="#000" opacity=".1"/><rect x="135" y="59" width="14" height="2.4" rx="1" fill="${P.paper}"/>` +
      // desk
      `<rect y="68" width="160" height="32" fill="${P.wood}"/><rect y="68" width="160" height="1.6" fill="${P.shade}"/>` +
      `<path d="M0 76Q50 74 100 77T160 75M0 86Q40 84 90 87T160 85" stroke="${P.wood2}" stroke-width=".6" fill="none" opacity=".4"/>` +
      `<rect y="94" width="160" height="6" fill="${P.wood2}"/><rect y="94" width="160" height="1" fill="${P.light}" opacity=".2"/>`;

    /* ---------- subject: the camera ---------- */
    const strap = "M44.5 50C40 55 39.5 65 46.5 73.5M115.5 50C122.5 56 126 70 120 80.5C113 89.5 92 92.5 78 89C70 87 65.5 82 68 75.5";
    const subject =
      h.shadow(80, 77.6, 40, 3.4, .26) +
      // strap, dropped casually: the left end tucks behind the body, the right
      // end loops loosely on the desk in front and runs back under the camera
      `<path d="${strap}" stroke="${P.wood2}" stroke-width="3.8" fill="none" stroke-linecap="round"/>` +
      `<path d="${strap}" stroke="${P.wood}" stroke-width=".5" stroke-dasharray="1.2 1.2" fill="none" opacity=".8"/>` +
      // top plate + prism
      `<path d="M48 46.5V42Q48 40 50 40H66.5L70 30Q70.8 28 73 28H87Q89.2 28 90 30L93.5 40H110Q112 40 112 42V46.5Z" fill="${P.metal}"/>` +
      `<path d="M80 28H87Q89.2 28 90 30L93.5 40H110Q112 40 112 42V46.5H80Z" fill="#000" opacity=".08"/>` +
      `<path d="M66.5 40L70 30Q70.8 28 73 28H74L71.6 40ZM93.5 40L90 30Q89.2 28 87 28H86L88.4 40Z" fill="${P.metal2}"/>` +
      `<rect x="74" y="32" width="12" height="3" rx="1.5" fill="${P.ink}" opacity=".75"/>` +
      `<path d="M48 44.6H112V46.5H48Z" fill="${P.metal2}"/>` +
      // knobs and dials
      `<rect x="52" y="35" width="10" height="5" rx="1" fill="${P.metal2}"/><rect x="51" y="33.4" width="12" height="2.2" rx="1" fill="${P.metal3}"/>` +
      `<rect x="97" y="35.4" width="10" height="4.6" rx="1" fill="${P.metal2}"/><rect x="96.4" y="34" width="11.2" height="2" rx="1" fill="${P.metal3}"/>` +
      `<path d="M99 36.4v3M101.5 36.4v3M104 36.4v3" stroke="${P.metal3}" stroke-width=".6"/>` +
      `<rect x="108.4" y="36.4" width="3" height="3.6" rx="1" fill="${P.metal3}"/><path d="M102 34.4L111.4 32.4" stroke="${P.metal3}" stroke-width="1.5" stroke-linecap="round"/>` +
      // body
      `<rect x="44" y="45.5" width="72" height="28" rx="3" fill="${P.ink}"/>` +
      `<rect x="44" y="45.5" width="72" height="3" rx="1.5" fill="#fff" opacity=".1"/>` +
      `<rect x="45" y="71" width="70" height="5" rx="2.2" fill="${P.metal2}"/><rect x="45" y="71" width="70" height="1.2" fill="${P.metal}" opacity=".8"/>` +
      `<rect x="42.6" y="48.6" width="3" height="4.4" rx="1" fill="${P.metal2}"/><rect x="114.4" y="48.6" width="3" height="4.4" rx="1" fill="${P.metal2}"/>` +
      `<path d="M52 51.5h5v3.2h-5z" fill="${P.metal2}"/>` +
      `<circle cx="104.5" cy="53" r="2.2" fill="${P.metal3}"/><circle cx="104.5" cy="53" r="1.2" fill="${P.water}"/>` +
      // lens
      `<circle cx="80" cy="60" r="16.5" fill="${P.metal2}"/>` +
      `<path d="M63.5 60A16.5 16.5 0 0 1 96.5 60A16.5 16.5 0 0 0 63.5 60Z" fill="#fff" opacity=".2"/>` +
      `<circle cx="80" cy="60" r="14.4" fill="${P.ink}"/>` +
      `<circle cx="80" cy="60" r="13.4" fill="none" stroke="${P.metal3}" stroke-width="1.6" stroke-dasharray=".9 .9"/>` +
      `<circle cx="80" cy="60" r="11.6" fill="${P.metal}"/>` +
      `<circle cx="80" cy="60" r="10.2" fill="${P.ink}"/>` +
      `<circle cx="80" cy="60" r="8.4" fill="${P.metal3}" opacity=".5"/>` +
      `<circle cx="80" cy="60" r="7.6" fill="${P.ink}"/>` +
      `<path d="M87.1 61.3A7.2 7.2 0 0 1 78.8 67.1Q83.6 65 87.1 61.3Z" fill="${P.water}" opacity=".85"/>` +
      `<path d="M74.8 56A6.6 6.6 0 0 1 82.6 53.2Q78 55.4 76.6 59.2Z" fill="#fff" opacity=".55"/>` +
      `<circle cx="84" cy="57" r="1.1" fill="#fff" opacity=".7"/>`;

    /* ---------- extra: a film canister with its leader out ---------- */
    // the leader lies on the desk pointing left, away from the camera strap
    const extra =
      h.shadow(21, 89.4, 15, 2.2, .2) +
      `<path d="M19 84L7.6 85Q4.6 86.6 6.6 88.6L19 88.8Z" fill="${P.hair}"/>` +
      `<path d="M9.4 85.6h1.3v1h-1.3zM12.6 85.3h1.3v1h-1.3zM15.8 85h1.3v1h-1.3z" fill="${P.wood}" opacity=".8"/>` +
      `<rect x="23.7" y="64.6" width="4.6" height="4" rx=".8" fill="${P.metal3}"/>` +
      `<rect x="18" y="70.6" width="16" height="17" fill="${P.lamp}"/>` +
      `<rect x="18" y="75.8" width="16" height="5.6" fill="${P.accent}"/>` +
      `<rect x="20" y="73" width="2.2" height="12.6" rx="1.1" fill="#fff" opacity=".35"/>` +
      `<rect x="28.4" y="70.6" width="5.6" height="17" fill="#000" opacity=".14"/>` +
      (N ? `<rect x="18" y="70.6" width="16" height="17" fill="#0a1430" opacity=".3"/>` : "") +
      `<rect x="17" y="67.8" width="18" height="3.4" rx="1.4" fill="${P.ink}"/><rect x="17" y="87" width="18" height="3" rx="1.2" fill="${P.ink}"/>`;

    return { bg, subject, extra, face: { x: 80, y: 60, r: 14 } };
  });
})();

/* ---- aircraft ---- */
/* PromptSnap preview scene: "aircraft"
 * A twin-engine airliner standing on the apron/runway, side-on, nose to the
 * right. bg = sky, hills, control tower and terminal on the horizon, tarmac
 * with runway markings (edge lights glow at night). subject = the aircraft
 * and its ground shadow. extra = a fuel truck parked under the tail.
 * Options: livery (hex) — colour of the tail fin, winglet, cheatline and
 * engine band (default P.cloth, a classic blue).
 */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  const f = (v) => Math.round(v * 100) / 100;
  const hexOf = (v) => (typeof v === "string" && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim())) ? v.trim() : null;
  const rgb = (c) => { c = c.slice(1); if (c.length === 3) c = c.replace(/./g, "$&$&"); return [0, 2, 4].map((i) => parseInt(c.substr(i, 2), 16)); };
  const mix = (a, b, t) => { const p = rgb(a), q = rgb(b); return "#" + p.map((v, i) => Math.round(v + (q[i] - v) * t).toString(16).padStart(2, "0")).join(""); };
  // subpath helpers so many same-colour shapes share one <path>
  const dot = (x, y, r) => `M${f(x - r)} ${f(y)}a${f(r)} ${f(r)} 0 1 0 ${f(2 * r)} 0a${f(r)} ${f(r)} 0 1 0 ${f(-2 * r)} 0z`;
  const pill = (x, y, w, hh) => { const r = w / 2; return `M${f(x)} ${f(y + r)}a${f(r)} ${f(r)} 0 0 1 ${f(w)} 0v${f(hh - w)}a${f(r)} ${f(r)} 0 0 1 ${f(-w)} 0z`; };
  const rr = (x, y, w, hh, r) => `M${f(x + r)} ${f(y)}h${f(w - 2 * r)}a${r} ${r} 0 0 1 ${r} ${r}v${f(hh - 2 * r)}a${r} ${r} 0 0 1 ${-r} ${r}h${f(2 * r - w)}a${r} ${r} 0 0 1 ${-r} ${-r}v${f(2 * r - hh)}a${r} ${r} 0 0 1 ${r} ${-r}z`;

  // livery colour, adapted to the time of day so a custom hex still sits in the scene
  function livery(P, o) {
    const c = hexOf(o && o.livery) || "#2f7de1";
    const tint = { night: ["#16223f", .45], golden: ["#ff9a50", .12], sunset: ["#6a3f86", .16] }[P.id];
    const L = tint ? mix(c, tint[0], tint[1]) : c;
    return [L, mix(L, "#000000", .24)];
  }

  A.scene("aircraft", (P, o, h) => {
    o = o || {};
    const night = !!P.night;
    const [L, L2] = livery(P, o);
    const RED = "#ff3b30", GREEN = "#2ee67a";

    /* ---------------- background ---------------- */
    let bg = h.sky(P) + h.stars(P) + h.sunOrMoon(P, 134, 17, 6) + h.cloud(P, 74, 16, .8) + h.cloud(P, 112, 30, .5);
    // hills
    bg += `<path d="M0 64C12 58 24 58 36 62C50 56 62 56 76 61C92 54 112 52 130 59C142 54 152 53 160 54V73H0Z" fill="${P.far}"/>`;
    // control tower (left of centre, above the fuselage line) and terminal
    bg += `<path d="M54 34h4.6v38h-4.6z" fill="${P.wall2}"/>` +
          `<path d="M50.2 28.4h12.2l-1.6 6.2h-9z" fill="${P.glass2}"/>` +
          `<path d="M50.6 29.6h11.4l-.5 2.2h-10.4z" fill="${P.glass}" opacity="${night ? 1 : .7}"/>` +
          `<path d="M49.6 26.4h13.4l-.6 2h-12.2z M55.8 26.4v-4.4h1v4.4z" fill="${P.metal3}"/>` +
          `<path d="M0 72V63.4C6 59.4 22 59.4 28 63.4V72z" fill="${P.wall2}"/>` +
          `<path d="M66 72V61.6h94V72z" fill="${P.wall2}"/>` +
          `<path d="M66 60.4h94v1.6H66z" fill="${P.metal3}"/>` +
          `<path d="M68 63.6h90v3.4H68z" fill="${P.glass}" opacity="${night ? .9 : .75}"/>`;
    // grass and tarmac
    bg += `<rect y="70.6" width="160" height="2.6" fill="${P.ground}"/>` +
          `<rect y="73" width="160" height="27" fill="${P.road}"/>` +
          `<rect y="73" width="160" height="6" fill="${P.line}" opacity=".07"/>`;
    // runway markings: far edge, centreline dashes, near edge
    let dashes = "";
    for (let x = -2; x < 160; x += 17) dashes += `M${x} 92h10v1.5h-10z`;
    bg += `<path d="M0 74.6h160v.5H0z M0 98.4h160v1H0z ${dashes}" fill="${P.line}" opacity="${night ? .5 : .85}"/>`;
    // edge lights glow at night
    if (night) {
      let far = "", near = "";
      for (let x = 4; x < 160; x += 11) far += dot(x, 74.9, .55);
      for (let x = 6; x < 160; x += 18) near += dot(x, 98.9, 1);
      let halo = "";
      for (let x = 4; x < 160; x += 11) halo += dot(x, 74.9, 1.8);
      for (let x = 6; x < 160; x += 18) halo += dot(x, 98.9, 3.2);
      bg += `<path d="${halo}" fill="${P.lamp}" opacity=".22"/><path d="${far}${near}" fill="${P.lamp}"/>`;
      // taxi light pool ahead of the nose gear
      bg += `<ellipse cx="152" cy="85.6" rx="13" ry="2.6" fill="${P.lamp}" opacity=".13"/>`;
    }

    /* ---------------- subject: the airliner ---------------- */
    const FUS = "M151.4 60.5C151.4 53.6 146 49 135 49L46 49C32 49 20 48 12 48.5L11 52.6C24 54 36 66 50 66L138 66C146.4 66 151.4 64 151.4 60.5Z";
    let s = h.shadow(86, 84.4, 66, 2.8, .22) + h.shadow(84, 84.2, 6.4, 1.1, .25) + h.shadow(137.4, 84.2, 4.6, .9, .25);
    // tail fin + rudder (livery)
    s += `<path d="M45 49.4C37 47.6 27 37 20.5 25C20 24.1 19.3 23.6 18.4 23.6L12.4 23.6C11.3 23.6 10.6 24.4 10.7 25.4L12.4 49Z" fill="${L}"/>` +
         `<path d="M12.4 49L10.7 25.4C10.6 24.4 11.3 23.6 12.4 23.6H15.4L16.6 49Z" fill="${L2}"/>`;
    // fuselage: body, belly tone, top highlight, cheatline
    s += `<path d="${FUS}" fill="${P.metal}"/>` +
         `<path d="M35 61.6H144C147.6 61.6 150.2 61 151.4 59.8C151.4 63 146.4 66 138 66H50C44 66 39 64 35 61.6Z" fill="${P.metal2}"/>` +
         `<path d="M40 49.7H135C138 49.7 140.6 50 142.6 50.6L40 51.4Z" fill="${P.light}" opacity="${night ? .25 : .7}"/>` +
         `<path d="M31 58.2H142C145.8 58.2 149 58.8 151.2 59.6L151.3 60.6C148.6 60.2 145.6 60 142 60H34Z" fill="${L}"/>`;
    // fin emblem, horizontal stabiliser
    s += `<circle cx="20" cy="37.4" r="4.4" fill="${P.light}" opacity=".92"/>` +
         `<path d="M16.4 39.8C18.4 34.4 22.4 33.4 23.8 35.2C21.4 35 19.2 36.4 16.4 39.8Z" fill="${L}"/>` +
         `<path d="M36 53.2L17.5 49.8C15 49.4 12.6 49.6 12 50.4L13.6 53Z" fill="${P.metal2}"/>`;
    // cabin windows (lit at night), doors, cockpit
    let win = "";
    for (let x = 47; x < 128; x += 3.3) win += pill(x, 52.6, 1.6, 2.7);
    if (night) s += `<rect x="45" y="51.6" width="84" height="4.6" rx="2.3" fill="${P.glass}" opacity=".13"/>`;
    s += `<path d="${win}" fill="${night ? P.glass : P.ink}" opacity="${night ? 1 : .72}"/>`;
    s += `<path d="${rr(130.4, 51.2, 3.2, 12, 1.2)}${rr(40, 51.4, 3, 11, 1.1)}" fill="none" stroke="${P.metal3}" stroke-width=".4"/>`;
    s += `<path d="M136 52.4H143.4C145.8 52.7 147.7 53.8 148.9 55.4H136.4Z" fill="${P.ink}"/>` +
         `<path d="M140 52.4V55.4M144.6 52.8L145.2 55.4" stroke="${P.metal}" stroke-width=".5"/>`;
    // near wing (seen a little from above): surface, leading-edge light, flaps, winglet
    s += `<path d="M108.6 60.2L80 61.8L57 71.6Q55.6 72.3 56.8 72.7H64Q66.2 72.7 67.2 71.8Z" fill="${P.metal2}"/>` +
         `<path d="M108.6 60.2L67.2 71.8L65.4 71.4L103 61Z" fill="${P.light}" opacity="${night ? .22 : .6}"/>` +
         `<path d="M80 61.8L57 71.6L60.2 71.4L82.6 62.4Z" fill="${P.metal3}" opacity=".55"/>` +
         `<path d="M58.4 72.5L54.2 64.6C54 64 54.6 63.6 55.2 64L62.4 71.6Z" fill="${L}"/>`;
    // engine: pylon, nacelle, belly tone, livery band, intake, exhaust
    s += `<path d="M100 62L113.4 60.4L118 65H104Z" fill="${P.metal2}"/>` +
         `<path d="M123 64.4H106C101.4 64.4 98.4 66.6 97 69.7C98.4 72.8 101.4 75 106 75H123Z" fill="${P.metal}"/>` +
         `<path d="M97.6 71.2H123V75H106C101.8 75 99 73.4 97.6 71.2Z" fill="${P.metal2}"/>` +
         `<path d="M117.4 64.4h1.8V75h-1.8z" fill="${L}"/>` +
         `<ellipse cx="123.2" cy="69.7" rx="2.1" ry="5.3" fill="${P.metal3}"/>` +
         `<ellipse cx="123.8" cy="69.7" rx="1.1" ry="4.1" fill="${P.ink}"/>` +
         `<path d="M97.6 68.1L93 69.1C92.6 69.4 92.6 70 93 70.3L97.6 71.3Z" fill="${P.metal3}"/>`;
    // landing gear
    s += `<path d="M83 64h2.1v15h-2.1z M136.7 65.4h1.4v14h-1.4z" fill="${P.metal3}"/>` +
         `<path d="${dot(84, 80.4, 3.6)}${dot(137.4, 81.2, 2.8)}" fill="${P.ink}"/>` +
         `<path d="${dot(84, 80.4, 1.4)}${dot(137.4, 81.2, 1.1)}" fill="${P.metal2}"/>`;
    // lights: beacons (red), nav (green), tail strobe and taxi light at night
    if (night) {
      s += `<path d="${dot(92, 48.7, 3.4)}${dot(90, 66.3, 3)}" fill="${RED}" opacity=".35"/>` +
           `<path d="${dot(64.6, 72.5, 3)}" fill="${GREEN}" opacity=".35"/>` +
           `<path d="${dot(11.2, 50.6, 3)}${dot(140, 78.2, 2.8)}" fill="#fff" opacity=".3"/>`;
    }
    s += `<path d="${dot(92, 48.7, .9)}${dot(90, 66.3, .8)}" fill="${RED}"/>` +
         `<path d="${dot(64.6, 72.5, .8)}" fill="${GREEN}"/>` +
         (night ? `<path d="${dot(11.2, 50.6, .8)}${dot(140, 78.2, .9)}" fill="#fff"/>` : "");

    /* ---------------- extra: fuel truck under the tail ---------------- */
    let x = `<g transform="translate(0 4)">` + h.shadow(26, 80.4, 22, 1.8, .22) +
      // chassis
      `<path d="M6 75.4h38.6v2.6H6z" fill="${P.metal3}"/>` +
      // tank with a band
      `<path d="${rr(16.4, 65.6, 28.4, 10.4, 4.6)}" fill="${P.metal}"/>` +
      `<path d="M17 71.8h27.2v2.6H17z" fill="${P.cloth3}"/>` +
      `<path d="M20 64.6h16v1.4H20z" fill="${P.metal3}"/>` +
      // cab facing left
      `<path d="M7.2 78V70.4C7.2 68.4 8.4 67.2 10.4 67.2H15.6V78Z" fill="${P.cloth3}"/>` +
      `<path d="M8.4 70.6C8.4 69.4 9.2 68.6 10.4 68.6H13.8V71.8H8.4Z" fill="${P.glass2}"/>` +
      `<path d="${dot(11.4, 78.2, 2.3)}${dot(26, 78.2, 2.3)}${dot(38.6, 78.2, 2.3)}" fill="${P.ink}"/>` +
      `<path d="${dot(11.4, 78.2, .9)}${dot(26, 78.2, .9)}${dot(38.6, 78.2, .9)}" fill="${P.metal2}"/>` +
      // amber beacon on the cab, headlight at night
      (night ? `<path d="${dot(12, 65.8, 2.6)}" fill="#ffb020" opacity=".35"/><path d="M7.2 73.4L-1 71.6V78.8L7.2 75.6Z" fill="${P.lamp}" opacity=".16"/><path d="${dot(7.4, 74.5, .75)}" fill="${P.lamp}"/>` : "") +
      `<path d="M10.8 67.2h2.4v-1.4c0-.6-.4-1-1.2-1s-1.2.4-1.2 1z" fill="#ffb020"/></g>`;

    return { bg, subject: `<g>${s}</g>`, extra: `<g>${x}</g>`, face: { x: 117, y: 55, r: 16 } };
  });
})();

/* ---- aircraft-sky ---- */
/* PromptSnap preview scene: "aircraft-sky"
 * An airliner in flight, three-quarter front view from slightly above,
 * banking gently over a deck of clouds. bg = sky, sun/moon, clouds.
 * subject = the aircraft (and its contrails when asked for). extra = a small
 * distant aircraft with its own contrail, top left.
 * Options: livery (hex) — tail, winglets, cheatline, engine bands (default a
 * classic blue); contrail (true) — white contrails trailing from the engines.
 */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  const f = (v) => Math.round(v * 100) / 100;
  const hexOf = (v) => (typeof v === "string" && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim())) ? v.trim() : null;
  const rgb = (c) => { c = c.slice(1); if (c.length === 3) c = c.replace(/./g, "$&$&"); return [0, 2, 4].map((i) => parseInt(c.substr(i, 2), 16)); };
  const mix = (a, b, t) => { const p = rgb(a), q = rgb(b); return "#" + p.map((v, i) => Math.round(v + (q[i] - v) * t).toString(16).padStart(2, "0")).join(""); };
  const dot = (x, y, r) => `M${f(x - r)} ${f(y)}a${f(r)} ${f(r)} 0 1 0 ${f(2 * r)} 0a${f(r)} ${f(r)} 0 1 0 ${f(-2 * r)} 0z`;
  const pill = (x, y, w, hh) => { const r = w / 2; return `M${f(x)} ${f(y + r)}a${f(r)} ${f(r)} 0 0 1 ${f(w)} 0v${f(hh - w)}a${f(r)} ${f(r)} 0 0 1 ${f(-w)} 0z`; };

  function livery(P, o) {
    const c = hexOf(o && o.livery) || "#2f7de1";
    const tint = { night: ["#16223f", .45], golden: ["#ff9a50", .12], sunset: ["#6a3f86", .16] }[P.id];
    const L = tint ? mix(c, tint[0], tint[1]) : c;
    return [L, mix(L, "#000000", .24)];
  }

  // fuselage edges in the unrotated drawing frame (tail x=31 → nose x=118)
  const topY = (x) => 40.2 + (37 - 40.2) * (x - 31) / 87;
  const botY = (x) => 47.6 + (57 - 47.6) * (x - 31) / 87;

  A.scene("aircraft-sky", (P, o, h) => {
    o = o || {};
    const night = !!P.night;
    const [L, L2] = livery(P, o);
    const RED = "#ff3b30", GREEN = "#2ee67a";

    /* ---------------- background: sky and cloud deck ---------------- */
    let bg = h.sky(P) + h.stars(P) + h.sunOrMoon(P, 138, 16, 6.5) + h.cloud(P, 120, 34, .7) + h.cloud(P, 150, 52, .5);
    bg += `<path d="M0 70C8 65 18 66 24 69C32 63 44 63 50 68C58 63 70 64 74 68C84 62 96 63 102 68C110 63 122 63 128 67C136 62 148 62 154 66C157 65 159 65 160 65.4V100H0Z" fill="${P.cloud}" opacity="${night ? .5 : .55}"/>` +
          `<path d="M0 80C8 74 18 74 24 78C30 71 42 70 48 76C56 71 66 72 70 77C78 71 90 71 96 77C104 72 116 72 120 77C128 71 140 71 146 76C152 73 158 74 160 75V100H0Z" fill="${P.cloud}" opacity="${night ? .85 : 1}"/>` +
          `<path d="M0 89C14 85 26 90 40 87C54 84 66 90 80 87C94 84 108 90 122 87C136 84 148 89 160 86V100H0Z" fill="${P.wall2}" opacity=".55"/>`;

    /* ---------------- subject: the airliner ---------------- */
    let s = "";
    // contrails (behind everything else of the aircraft)
    if (o.contrail === true) {
      const ca = night ? .3 : .8;
      // a faint shaded underside keeps the white trails readable over the white cloud deck
      s += (night ? "" : `<path d="M66 68.8L-4 68V69.4L66 69.2Z M73 36.2L-4 34.6V35.8L73 36.5Z" fill="${P.far}" opacity=".55"/>`) +
           `<path d="M64 67.6L-4 63.6V69.6L64 69.4Z M72 35.4L-4 31.6V35.6L72 36.6Z" fill="#fff" opacity="${ca * .35}"/>` +
           `<path d="M66 68.2L-4 65.2V68L66 68.8Z M73 35.7L-4 32.6V34.6L73 36.2Z" fill="#fff" opacity="${ca}"/>`;
    }
    // far engine (peeks above the fuselage) and far wing
    s += `<path d="M90 32.2H80C77.6 32.2 76 34 76 36S77.6 39.8 80 39.8H90Z" fill="${P.metal2}"/>` +
         `<path d="M86.4 32.2h1.4v7.6h-1.4z" fill="${L}"/>` +
         `<ellipse cx="90.2" cy="36" rx="1.8" ry="3.8" fill="${P.metal3}"/><ellipse cx="90.7" cy="36" rx="1" ry="3" fill="${P.ink}"/>` +
         `<path d="M92 38.8L58.6 19.8Q56.4 18.8 55 19.6L52.6 20.8L70 40.4Z" fill="${P.metal2}"/>` +
         `<path d="M92 38.8L58.6 19.8L58.2 21L88.4 38.6Z" fill="${P.metal}" opacity=".8"/>` +
         `<path d="M54.6 20.4L52.4 13.4C52.3 12.8 52.9 12.6 53.3 13L57.6 19.8Z" fill="${L}"/>`;
    // tail: far stabiliser, fin + rudder
    s += `<path d="M42 41.2L22 36.8C20.4 36.5 19.8 37.4 20.8 38.2L32 42.4Z" fill="${P.metal3}"/>` +
         `<path d="M52 39.6C44 37 36.6 27 33 17.6C32.6 16.6 31.8 16 30.8 16H25.8C24.6 16 23.8 17 24 18.2L28.4 40.4Z" fill="${L}"/>` +
         `<path d="M28.4 40.4L24 18.2C23.8 17 24.6 16 25.8 16H28.4L31.6 40.2Z" fill="${L2}"/>` +
         `<circle cx="34.6" cy="28.6" r="3.4" fill="${P.light}" opacity=".92"/>` +
         `<path d="M32 30.4C33.4 26.4 36.4 25.6 37.4 27C35.6 26.8 34 27.8 32 30.4Z" fill="${L}"/>`;
    // fuselage: body, belly tone, top highlight, nose sheen, cheatline
    s += `<path d="M31 40.2L118 37C127.6 36.6 135.6 41.6 135.8 47.4C136 53 128.6 57.2 118 57L31 47.6C27.4 47 26.6 41.4 31 40.2Z" fill="${P.metal}"/>` +
         `<path d="M31 46L118 52.6C126 52.8 132 51.6 135.4 49.8C134 54.6 127.4 57.2 118 57L31 47.6C29.6 47.4 28.8 46.8 31 46Z" fill="${P.metal2}"/>` +
         `<path d="M36 40.6L118 37.6C122 37.5 125 37.8 127.4 38.6L118 39L36 41.6Z" fill="${P.light}" opacity="${night ? .25 : .75}"/>` +
         `<ellipse cx="129.6" cy="45.6" rx="3.6" ry="4.6" fill="${P.light}" opacity="${night ? .12 : .35}"/>` +
         `<path d="M31 44.4L118 48.6C124.4 48.5 130 47.6 134.8 45.8L135.4 47.8C130.6 50 124.6 51.1 118 51.2L31 45.8Z" fill="${L}"/>`;
    // cabin windows, smaller toward the tail
    let win = "", x = 112;
    while (x > 40) {
      const k = (botY(x) - topY(x)) / 20, y = topY(x) + (botY(x) - topY(x)) * .3;
      win += pill(x, y, 1.6 * k, 2.8 * k);
      x -= 3.9 * k;
    }
    if (night) s += `<path d="M40 41.4L114 40.2V45.4L40 44Z" fill="${P.glass}" opacity=".13"/>`;
    s += `<path d="${win}" fill="${night ? P.glass : P.ink}" opacity="${night ? 1 : .72}"/>`;
    // door and cockpit
    s += `<path d="M112.2 41.4C112.2 40.4 112.8 39.8 113.8 39.8H115C116 39.8 116.6 40.4 116.6 41.4V52C116.6 53 116 53.6 115 53.6H113.8C112.8 53.6 112.2 53 112.2 52Z" fill="none" stroke="${P.metal3}" stroke-width=".4"/>` +
         `<path d="M120.4 40.4C124.4 39.4 128.8 39.8 131.8 42.2L132.6 44.4C129 43 124.6 42.8 120.6 43.6Z" fill="${P.ink}"/>` +
         `<path d="M124.6 39.9L124.8 43.1M128.6 40.7L129.2 43.4" stroke="${P.metal}" stroke-width=".5"/>`;
    // near stabiliser
    s += `<path d="M44 46.6L20.4 51.8C18.6 52.2 17.8 51.4 18.8 50.4L32 45Z" fill="${P.metal2}"/>`;
    // near engine (under the wing, intake facing us)
    s += `<path d="M80.6 63H93L96.4 54.4L84 58.2Z" fill="${P.metal3}"/>` +
         `<path d="M94 62.4H80.4C76.6 62.4 74 65.4 74 68.4S76.6 74.4 80.4 74.4H94Z" fill="${P.metal}"/>` +
         `<path d="M74.6 70.6C75.6 72.8 77.8 74.4 80.4 74.4H94V70.6Z" fill="${P.metal2}"/>` +
         `<path d="M88.6 62.4h2v12h-2z" fill="${L}"/>` +
         `<path d="M74.4 66.8L70.4 67.6C69.8 68 69.8 68.8 70.4 69.2L74.4 70Z" fill="${P.metal3}"/>` +
         `<ellipse cx="94.4" cy="68.4" rx="3.4" ry="6.2" fill="${P.metal3}"/>` +
         `<ellipse cx="95" cy="68.5" rx="2.4" ry="5" fill="${P.ink}"/>` +
         `<circle cx="95.6" cy="68.7" r="1.2" fill="${P.metal2}"/>`;
    // near wing: surface, flaps, leading-edge light, winglet
    s += `<path d="M100 53.4L43.6 79Q41.6 80.2 39.6 80L34.4 79.2L72.4 48.8Z" fill="${P.metal}"/>` +
         `<path d="M72.4 48.8L34.4 79.2L38.6 79.6L75.6 50.2Z" fill="${P.metal2}"/>` +
         `<path d="M100 53.4L43.6 79L42.4 78.2L97 53.2Z" fill="${P.light}" opacity="${night ? .2 : .7}"/>` +
         `<path d="M40.4 79.8L35.4 68C35.1 67.3 35.8 66.8 36.4 67.3L43.6 78.6Z" fill="${L}"/>`;
    // lights: beacons, nav (green near tip = starboard, red far tip = port), strobes
    if (night) {
      s += `<path d="${dot(86, 38.4, 3.4)}${dot(84, 53.8, 3)}${dot(53, 19.6, 3)}" fill="${RED}" opacity=".35"/>` +
           `<path d="${dot(42.4, 80, 3.2)}" fill="${GREEN}" opacity=".35"/>` +
           `<path d="${dot(24.4, 39.6, 2.6)}${dot(98, 55.6, 2.4)}" fill="#fff" opacity=".3"/>`;
    }
    s += `<path d="${dot(86, 38.4, .9)}${dot(84, 53.8, .8)}${dot(53, 19.6, .7)}" fill="${RED}"/>` +
         `<path d="${dot(42.4, 80, .9)}" fill="${GREEN}"/>` +
         (night ? `<path d="${dot(24.4, 39.6, .7)}${dot(98, 55.6, .7)}" fill="#fff"/>` : "");
    const subject = `<g transform="rotate(-6 84 50)">${s}</g>`;

    /* ---------------- extra: a small distant aircraft, top left ---------------- */
    const ex = `<g>` +
      `<path d="M-2 13L21.4 11.4V12.6L-2 14.4Z" fill="#fff" opacity="${night ? .25 : .75}"/>` +
      `<g transform="translate(32 11.2) rotate(-4) scale(.55)">` +
      `<path d="M-6 3L8 -6.4C9 -7 10.6 -6.8 10 -5.8L3 3Z" fill="${P.metal2}"/>` +
      `<path d="M-20 -1.6C-20 -3 -18.6 -3.4 -17 -3.4H14C18 -3.4 21 -2 22 .2C21 2 18 3.4 14 3.4H-14C-17.6 3.4 -20 2 -20 -1.6Z" fill="${P.metal}"/>` +
      `<path d="M-13 -3.2L-18.6 -11.6C-19 -12.2 -18.6 -12.6 -18 -12.6H-15.6C-15 -12.6 -14.6 -12.4 -14.2 -11.8L-7 -3.2Z" fill="${L}"/>` +
      `<path d="M-4 1.6L-12 9C-12.6 9.6 -11.8 10.2 -11 9.8L4 2Z M2 3.4h6v2.4h-6z" fill="${P.metal2}"/>` +
      `<path d="M15.4 -2.4H19L20.4 -.6H16.2Z" fill="${P.ink}"/>` +
      (night ? `<path d="${dot(-11.4, 9.6, 2.6)}" fill="${GREEN}" opacity=".5"/><path d="${dot(0, -3.8, 2.4)}" fill="${RED}" opacity=".5"/>` : "") +
      `</g></g>`;

    return { bg, subject, extra: ex, face: { x: 110, y: 50, r: 16 } };
  });
})();

/* ---- airport ---- */
/* PromptSnap preview scene: "airport"
 * Inside a terminal at the gate: a tall glass wall looking out at the apron,
 * where an airliner stands side-on; two rows of gate seats on a polished
 * floor. bg = ceiling, glass-wall frame, sky, apron, floor. subject = the
 * aircraft outside, the seats and (option) the departure board. extra = a
 * traveller pulling a rolling suitcase, left.
 * Options: board (true) — a large freestanding departure board in the
 * foreground (rows of rounded bars and coloured status dots, no text).
 */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  const f = (v) => Math.round(v * 10) / 10;
  const rgb = (c) => { c = c.slice(1); if (c.length === 3) c = c.replace(/./g, "$&$&"); return [0, 2, 4].map((i) => parseInt(c.substr(i, 2), 16)); };
  const mix = (a, b, t) => { const p = rgb(a), q = rgb(b); return "#" + p.map((v, i) => Math.round(v + (q[i] - v) * t).toString(16).padStart(2, "0")).join(""); };
  const dot = (x, y, r) => `M${f(x - r)} ${f(y)}a${f(r)} ${f(r)} 0 1 0 ${f(2 * r)} 0a${f(r)} ${f(r)} 0 1 0 ${f(-2 * r)} 0z`;
  const pill = (x, y, w, hh) => { const r = w / 2; return `M${f(x)} ${f(y + r)}a${f(r)} ${f(r)} 0 0 1 ${f(w)} 0v${f(hh - w)}a${f(r)} ${f(r)} 0 0 1 ${f(-w)} 0z`; };
  const rr = (x, y, w, hh, r) => `M${f(x + r)} ${f(y)}h${f(w - 2 * r)}a${r} ${r} 0 0 1 ${r} ${r}v${f(hh - 2 * r)}a${r} ${r} 0 0 1 ${-r} ${r}h${f(2 * r - w)}a${r} ${r} 0 0 1 ${-r} ${-r}v${f(2 * r - hh)}a${r} ${r} 0 0 1 ${r} ${-r}z`;

  A.scene("airport", (P, o, h) => {
    o = o || {};
    const night = !!P.night, board = o.board === true;
    const tint = { night: ["#16223f", .45], golden: ["#ff9a50", .12], sunset: ["#6a3f86", .16] }[P.id];
    const L = tint ? mix("#2f7de1", tint[0], tint[1]) : "#2f7de1", L2 = mix(L, "#000000", .24);
    const SILL = 63;

    /* ---------------- background: outside view, glass wall, ceiling, floor ---------------- */
    let bg = h.sky(P) + h.stars(P) + h.sunOrMoon(P, 19, 29, 5) + h.cloud(P, 94, 27, .7);
    // far hills, hangar and apron
    bg += `<path d="M0 54C14 48 30 48 44 52C60 46 80 46 96 51C112 45 136 45 160 50V60H0Z" fill="${P.far}"/>` +
          `<path d="M136 56V49.6C142 45.6 154 45.6 160 49.6V56Z" fill="${P.wall2}"/>` +
          `<rect y="54" width="160" height="${SILL - 54}" fill="${P.road}"/>` +
          `<path d="M0 56.4h160v.5H0z" fill="${P.line}" opacity=".45"/>`;
    // apron floodlight poles in the side panes
    bg += `<path d="M5.4 34h1.2v20.4h-1.2z M145.4 34h1.2v20.4h-1.2z" fill="${P.metal3}"/>` +
          `<path d="M3.4 32.4h5.2v2h-5.2z M143.4 32.4h5.2v2h-5.2z" fill="${night ? P.lamp : P.metal2}"/>` +
          (night ? `<path d="${dot(6, 33.6, 4.6)}${dot(146, 33.6, 4.6)}" fill="${P.lamp}" opacity=".22"/>` : "");
    // glass wall frame: header beam, transom, mullions, sill
    bg += `<path d="M0 8h160v2.4H0z M0 17.6h160v1.4H0z M31.4 8h2v${SILL - 8}h-2z M132.6 8h2v${SILL - 8}h-2z" fill="${P.metal3}"/>` +
          `<path d="M3 12L13 12L2 23Z M137 12L150 12L136 26Z M135.4 40L147 22H150L136 44Z" fill="${P.light}" opacity="${night ? .06 : .22}"/>` +
          `<path d="M0 ${SILL - 1.6}h160v3H0z" fill="${P.metal3}"/>`;
    // hanging gate sign (no text: a badge and a bar)
    bg += `<path d="M50 8v2.4M68 8v2.4" stroke="${P.metal3}" stroke-width=".6"/>` +
          `<rect x="45" y="10" width="28" height="6.6" rx="1.6" fill="${P.ink}"/>` +
          `<rect x="46.6" y="11.2" width="4.4" height="4.2" rx="1" fill="#ffcf5a"/>` +
          `<path d="M53.6 13.3h12.6" stroke="#fff" stroke-width="1.6" stroke-linecap="round" opacity=".85"/>`;
    // ceiling with downlights
    bg += `<rect width="160" height="8" fill="${P.wall2}"/>` +
          `<path d="M0 6.6h160v1.4H0z" fill="#000" opacity=".1"/>`;
    let lamps = "", halo = "";
    for (let x = 10; x < 160; x += 20) { lamps += `M${x - 3} 3.6h6v1.6h-6z`; halo += `M${x - 6} 5.2h12l-3 2.8h-6z`; }
    // at night the lit hall glows warm against the dark apron: lamp spill under the ceiling
    bg += (night ? `<path d="${halo}" fill="${P.lamp}" opacity=".2"/>` : "") +
          `<path d="${lamps}" fill="${night ? P.lamp : P.light}"/>`;
    // polished floor: base, window reflection, tile joints
    bg += `<rect y="${SILL + 1.4}" width="160" height="${100 - SILL}" fill="${P.floor}"/>` +
          `<rect y="${SILL + 1.4}" width="160" height="9" fill="${night ? P.lamp : P.light}" opacity="${night ? .05 : .28}"/>` +
          (night ? `<rect y="${SILL + 1.4}" width="160" height="${100 - SILL}" fill="${P.lamp}" opacity=".08"/>` : "") +
          `<rect y="${SILL + 10.4}" width="160" height="10" fill="${P.light}" opacity="${night ? .03 : .12}"/>` +
          `<path d="M31.4 ${SILL + 1.4}h2l1 16h-4z M132.6 ${SILL + 1.4}h2l1 16h-4z" fill="${P.metal3}" opacity=".22"/>`;
    let joints = "";
    for (const y of [69, 76, 86]) joints += `M0 ${y}H160`;
    for (let x = -40; x <= 200; x += 30) joints += `M${f(80 + (x - 80) * .45)} ${SILL + 1.4}L${f(x)} 100`;
    bg += `<path d="${joints}" stroke="${P.metal2}" stroke-width=".35" opacity=".5"/>`;

    /* ---------------- subject ---------------- */
    // the aircraft outside (same airliner as the "aircraft" scene, further away)
    let ac = `<g transform="translate(31.4 7.7) scale(.62)">` +
      h.shadow(86, 84.4, 66, 2.8, .2) +
      `<path d="M45 49.4C37 47.6 27 37 20.5 25C20 24.1 19.3 23.6 18.4 23.6L12.4 23.6C11.3 23.6 10.6 24.4 10.7 25.4L12.4 49Z" fill="${L}"/>` +
      `<path d="M12.4 49L10.7 25.4C10.6 24.4 11.3 23.6 12.4 23.6H15.4L16.6 49Z" fill="${L2}"/>` +
      `<path d="M151.4 60.5C151.4 53.6 146 49 135 49L46 49C32 49 20 48 12 48.5L11 52.6C24 54 36 66 50 66L138 66C146.4 66 151.4 64 151.4 60.5Z" fill="${P.metal}"/>` +
      `<path d="M35 61.6H144C147.6 61.6 150.2 61 151.4 59.8C151.4 63 146.4 66 138 66H50C44 66 39 64 35 61.6Z" fill="${P.metal2}"/>` +
      `<path d="M31 58.2H142C145.8 58.2 149 58.8 151.2 59.6L151.3 60.6C148.6 60.2 145.6 60 142 60H34Z" fill="${L}"/>` +
      `<circle cx="20" cy="37.4" r="4.4" fill="${P.light}" opacity=".92"/>` +
      `<path d="M36 53.2L17.5 49.8C15 49.4 12.6 49.6 12 50.4L13.6 53Z" fill="${P.metal2}"/>`;
    let win = "";
    for (let x = 47; x < 128; x += 4.4) win += pill(x, 52.4, 2, 3);
    ac += `<path d="${win}" fill="${night ? P.glass : P.ink}" opacity="${night ? 1 : .72}"/>` +
      `<path d="M136 52.4H143.4C145.8 52.7 147.7 53.8 148.9 55.4H136.4Z" fill="${P.ink}"/>` +
      `<path d="M108.6 60.2L80 61.8L57 71.6Q55.6 72.3 56.8 72.7H64Q66.2 72.7 67.2 71.8Z" fill="${P.metal2}"/>` +
      `<path d="M58.4 72.5L54.2 64.6C54 64 54.6 63.6 55.2 64L62.4 71.6Z" fill="${L}"/>` +
      `<path d="M100 62L113.4 60.4L118 65H104Z" fill="${P.metal2}"/>` +
      `<path d="M123 64.4H106C101.4 64.4 98.4 66.6 97 69.7C98.4 72.8 101.4 75 106 75H123Z" fill="${P.metal}"/>` +
      `<path d="M117.4 64.4h1.8V75h-1.8z" fill="${L}"/>` +
      `<ellipse cx="123.2" cy="69.7" rx="2.1" ry="5.3" fill="${P.metal3}"/>` +
      `<path d="M83 64h2.1v15h-2.1z M136.7 65.4h1.4v14h-1.4z" fill="${P.metal3}"/>` +
      `<path d="${dot(84, 80.4, 3.6)}${dot(137.4, 81.2, 2.8)}" fill="${P.ink}"/>` +
      (night ? `<path d="${dot(92, 48.7, 4)}" fill="#ff3b30" opacity=".35"/>` : "") +
      `<path d="${dot(92, 48.7, 1.2)}" fill="#ff3b30"/>` +
      `</g>`;

    // gate seats: a far row and a near row, facing us. Rounded shapes are drawn
    // as small rects with a round-joined stroke of the same colour (compact markup).
    const box = (x, y, w, hh, r) => `M${f(x + r)} ${f(y + r)}h${f(w - 2 * r)}v${f(hh - 2 * r)}h${f(2 * r - w)}z`;
    const seats = (x0, n, pitch, w, top, back, pan, floor) => {
      const r = w * .2, rp = pan * .4, py = top + back - pan * .35;
      let backs = "", tops = "", pans = "", arms = "";
      for (let i = 0; i < n; i++) {
        const x = x0 + i * pitch;
        backs += box(x, top, w, back, r);
        tops += `M${f(x + r)} ${f(top + .9)}h${f(w - 2 * r)}`;
        pans += box(x - w * .04, py, w * 1.08, pan, rp);
        if (i) arms += `M${f(x - (pitch - w) / 2)} ${f(py - pan * .3)}v${f(pan * .7)}`;
      }
      const x1 = x0 + (n - 1) * pitch + w, by = top + back + pan * .6, bh = pan * .32, lw = w * .1;
      let legs = `M${f(x0 + 1)} ${f(by)}H${f(x1 - 1)}v${f(bh)}H${f(x0 + 1)}z`;
      for (const lx of [x0 + w * .3, (x0 + x1) / 2, x1 - w * .4]) legs += `M${f(lx)} ${f(by)}h${f(lw)}V${floor}h${f(-lw)}z`;
      const st = (c, sw) => `fill="${c}" stroke="${c}" stroke-width="${f(sw)}" stroke-linejoin="round"`;
      return h.shadow((x0 + x1) / 2, floor + .3, (x1 - x0) / 2 + 3, pan * .4, .2) +
        `<path d="${legs}" fill="${P.metal3}"/>` +
        `<path d="${backs}" ${st(P.cloth4, 2 * r)}/>` +
        `<path d="${tops}" stroke="${P.light}" stroke-width="${f(w * .1)}" stroke-linecap="round" opacity=".3"/>` +
        `<path d="${pans}" ${st(P.cloth4, 2 * rp)}/><path d="${pans}" ${st("#000", 2 * rp)} opacity=".13"/>` +
        `<path d="${arms}" stroke="${P.metal2}" stroke-width="${f(w * .12)}" stroke-linecap="round"/>`;
    };
    let s = ac + seats(46, 7, 11, 9, 63.6, 9.4, 3, 77) + seats(40, 6, 15.4, 13, 70.4, 13.4, 4.4, 94);

    // optional departure board on a stand, in the foreground (bars and dots are
    // round-capped strokes: short markup)
    if (board) {
      const G = "#2fd27a", Y = "#ffb020", R = "#ff5a4f";
      const rows = [[G, 22], [G, 16], [Y, 24], [G, 18], [R, 14], [G, 20]];
      let amber = "", dest = "", gate = "", sep = "";
      const dots = { [G]: "", [Y]: "", [R]: "" };
      rows.forEach(([c, w], i) => {
        const y = f(34.4 + i * 4.3);
        amber += `M92 ${y}h5`; dest += `M101.4 ${y}h${w - 2}`; gate += `M127.4 ${y}h4`;
        dots[c] += `M139.4 ${y}h0`;
        if (i) sep += `M90.4 ${f(y - 2.15)}h53.2`;
      });
      const ln = (d, c, sw, op) => `<path d="${d}" stroke="${c}" stroke-width="${sw}" stroke-linecap="round"${op ? ` opacity="${op}"` : ""}/>`;
      // the stand reaches lower than the near seat row's feet: the board stands in front of it
      s += h.shadow(117, 98.6, 25, 1.4, .24) +
        `<path d="M98.4 58h2.4v39.4h-2.4z M133.2 58h2.4v39.4h-2.4z" fill="${P.metal3}"/>` + ln("M95.4 97.6h7.6M131.2 97.6h7.6", P.metal3, 1.8) +
        `<rect x="86" y="22" width="62" height="40" rx="3" fill="${P.metal3}"/>` +
        `<rect x="88" y="24" width="58" height="36" rx="2" fill="#162033"/>` +
        `<rect x="90.4" y="26.4" width="53.2" height="4.6" rx="1.4" fill="#2f7de1"/>` +
        ln("M94 28.7h16", "#fff", 1.8, .85) +
        `<path d="M138 28.7l2.8-.9 1.4-1.8h.8l-.7 1.9 2-.6.6-.8h.5l-.3 1.4.3 1.4h-.5l-.6-.8-2-.6.7 1.9h-.8l-1.4-1.8z" fill="#fff" opacity=".9"/>` +
        `<path d="${sep}" stroke="#fff" stroke-width=".3" opacity=".08"/>` +
        ln(amber, "#ffcf5a", 2) + ln(dest, "#e9eef5", 2, .9) + ln(gate, "#e9eef5", 2, .5) +
        Object.keys(dots).map((c) => ln(dots[c], c, 2.5)).join("") +
        `<path d="M88 24h58v5L88 46z" fill="#fff" opacity=".04"/>`;
    }

    /* ---------------- extra: traveller with a rolling suitcase ---------------- */
    const ex = `<g>` + h.shadow(20, 96, 15, 1.8, .22) +
      // suitcase, handle, wheels
      `<path d="M15.6 79.4h1.1v-6.8h-1.1z M19.4 79.4h1.1v-6.8h-1.1z M15.6 72.6h4.9v1h-4.9z" fill="${P.metal3}"/>` +
      `<path d="${rr(9.6, 79, 13.4, 15, 2.4)}" fill="${P.cloth}"/>` +
      `<path d="M13.4 80.6v11.6M19.2 80.6v11.6" stroke="#000" stroke-width=".8" opacity=".2"/>` +
      `<path d="${dot(12.4, 95, 1.2)}${dot(20.2, 95, 1.2)}" fill="${P.ink}"/>` +
      // legs, shoes
      `<path d="M25.4 78h3.6l-.4 17h-3z M30 78h3.6l.6 17h-3z" fill="${P.cloth2}"/>` +
      `<path d="M24.2 94.4h4.6v1.6h-4.6z M30.6 94.4h4.8v1.6h-4.8z" fill="${P.ink}"/>` +
      // jacket with the arm reaching back to the handle
      `<path d="M24.4 80V64.4C24.4 61.4 26.4 59.6 29.4 59.6C32.4 59.6 34.6 61.4 34.6 64.4V80Z" fill="${P.cloth3}"/>` +
      `<path d="M25.6 64.2C24 66 20.8 70 18.6 72.4L19.8 73.8C22.4 71.8 25.6 69 27.4 67Z" fill="${P.cloth3}"/>` +
      `<path d="M29.4 59.6l-1.6 3.4 1.6 1.8 1.6-1.8z" fill="${P.light}" opacity=".85"/>` +
      `<path d="${dot(18.6, 73.2, 1.2)}" fill="${P.skin2}"/>` +
      // head and hair
      `<rect x="28" y="56.6" width="3" height="3.6" rx="1.2" fill="${P.skin2}"/>` +
      `<circle cx="29.6" cy="53.4" r="4.2" fill="${P.skin}"/>` +
      `<path d="M25.4 53.2C25 49 28 47.8 30 47.8C33 47.8 34.6 50 33.8 52.6C32.4 51 29.4 50.4 27 51.4C26.4 52 26 52.6 25.4 53.2Z" fill="${P.hair}"/>` +
      `</g>`;

    const face = board ? { x: 117, y: 44, r: 20 } : { x: 112, y: 42, r: 12 };
    return { bg, subject: `<g>${s}</g>`, extra: ex, face };
  });
})();

/* ---- cabin ---- */
/* PromptSnap preview scene: "cabin"
 * Aircraft cabin interior seen from the aisle: rows of seats receding to a
 * vanishing point, overhead bins, small rounded windows (they show the sky
 * of the time of day; at night the cabin gets soft mood lighting).
 * Drawn with a simple perspective projection (metres → screen).
 * bg = cabin shell (ceiling, walls, windows, floor, bulkhead); subject = all
 * seat rows and overhead bins. extra = a flight attendant with a trolley in
 * the aisle, left of centre. The extra is drawn under the subject, so when it
 * is shown (o.extra) the rows and bins BEYOND her move into the extra, under
 * her, and only the nearer ones stay in the subject: she is hidden by nearer
 * seats and covers farther ones, and remove-bg still keeps every seat.
 */
(() => {
  const A = window.PSNAP_ART; if (!A) return;

  const f = (v) => Math.round(v * 10) / 10;
  // camera: slightly right of the aisle centre, standing eye height
  const F = 80, VX = 68, VY = 40, XC = .22, EY = 1.5;
  const px = (X, Z) => VX + (X - XC) * F / Z;
  const py = (Y, Z) => VY + (EY - Y) * F / Z;
  const pt = (X, Y, Z) => `${f(px(X, Z))} ${f(py(Y, Z))}`;
  // a quad running along the cabin between cross-section points (X1,Y1) and (X2,Y2)
  const strip = (X1, Y1, X2, Y2, Z1, Z2) => `M${pt(X1, Y1, Z1)}L${pt(X1, Y1, Z2)}L${pt(X2, Y2, Z2)}L${pt(X2, Y2, Z1)}Z`;
  // a rect in a cross-section plane (facing us) at depth Z
  const face = (X1, X2, Y1, Y2, Z, inset) => {
    const k = F / Z, i = (inset || 0) * k;
    const x = px(X1, Z) + i, y = py(Y2, Z) + i, w = (X2 - X1) * k - 2 * i, hh = (Y2 - Y1) * k - 2 * i;
    return `M${f(x)} ${f(y)}h${f(w)}v${f(hh)}h${f(-w)}z`;
  };
  const ell = (cx, cy, rx, ry) => `M${f(cx - rx)} ${f(cy)}a${f(rx)} ${f(ry)} 0 1 0 ${f(2 * rx)} 0a${f(rx)} ${f(ry)} 0 1 0 ${f(-2 * rx)} 0z`;

  const ZN = .4, ZF = 10, ROWS = [2, 2.8, 3.6, 4.4, 5.2, 6, 6.8, 7.6, 8.4, 9.2];
  const SPLIT = 2.85;           // rows/bins nearer than this are in front of the attendant
  const BLOCKS = [-1.7, .3];    // left and right seat blocks start (each 1.4 m wide, 3 seats)

  A.scene("cabin", (P, o, h) => {
    o = o || {};
    const night = !!P.night;
    const MOOD = "#9d86ff";
    // seat fabric: P.cloth, but keep the day blue in the winter palette (snow outside, same seats inside)
    const C1 = P.id === "winter" ? A.PAL.day.cloth : P.cloth, C2 = P.id === "winter" ? A.PAL.day.cloth2 : P.cloth2;
    const st = (c, w) => `fill="${c}" stroke="${c}" stroke-width="${f(w)}" stroke-linejoin="round"`;

    // one row of seats (both blocks), seen from behind
    const row = (Z) => {
      const k = F / Z, r = .07;
      let backs = "", covers = "", screens = "", sides = "", under = "";
      for (const b of BLOCKS) {
        for (let j = 0; j < 3; j++) {
          const a = b + j * .48;
          backs += face(a, a + .44, .4, 1.12, Z, r);
          covers += face(a, a + .44, .95, 1.12, Z, r);
          if (k > 14) screens += face(a + .12, a + .32, .74, .9, Z, .02);
        }
        if (k > 16) under += strip(b, 0, b + 1.4, 0, Z, Z + .5);
      }
      // the aisle side of the left block's aisle seat (armrest and seat side)
      sides += `M${pt(-.3, .66, Z)}L${pt(-.3, .66, Z + .46)}L${pt(-.3, .18, Z + .46)}L${pt(-.3, .18, Z)}Z`;
      return (under ? `<path d="${under}" fill="#000" opacity=".16"/>` : "") +
        `<path d="${sides}" fill="${C2}"/>` +
        `<path d="${backs}" ${st(C1, 2 * r * k)}/>` +
        `<path d="${covers}" ${st(P.light, 2 * r * k)} opacity=".92"/>` +
        (screens ? `<path d="${screens}" ${st(night ? "#5aa0ff" : P.ink, .04 * k)}${night ? "" : ` opacity=".8"`}/>` : "");
    };
    // overhead bins between two depths: shaded underside with reading lights, lip, door face, seams, latches
    const bins = (Z1, Z2) => {
      let seams = "", latch = "", lights = "";
      for (const z of ROWS.concat([1.2])) {
        if (z >= Z1 && z < Z2) seams += `M${pt(-.78, 1.62, z)}L${pt(-.73, 2.08, z)}M${pt(.78, 1.62, z)}L${pt(.73, 2.08, z)}`;
        const zm = z + .4;
        if (zm >= Z1 && zm < Z2 && F / zm > 9) {
          latch += `M${pt(-.775, 1.76, zm - .07)}L${pt(-.775, 1.76, zm + .07)}M${pt(.775, 1.76, zm - .07)}L${pt(.775, 1.76, zm + .07)}`;
          lights += `M${pt(-1.05, 1.62, zm)}h0M${pt(1.05, 1.62, zm)}h0`;
        }
      }
      return `<path d="${strip(-1.64, 1.62, -.78, 1.62, Z1, Z2)}${strip(.78, 1.62, 1.64, 1.62, Z1, Z2)}" fill="${P.metal3}"/>` +
        `<path d="${strip(-.78, 1.62, -.73, 2.08, Z1, Z2)}${strip(.78, 1.62, .73, 2.08, Z1, Z2)}" fill="${P.metal}"/>` +
        `<path d="${strip(-.78, 1.62, -.772, 1.7, Z1, Z2)}${strip(.78, 1.62, .772, 1.7, Z1, Z2)}" fill="${P.metal2}"/>` +
        (night ? `<path d="${strip(-.78, 1.62, -.73, 2.08, Z1, Z2)}${strip(.78, 1.62, .73, 2.08, Z1, Z2)}" fill="${MOOD}" opacity=".16"/>` : "") +
        (seams ? `<path d="${seams}" stroke="${P.metal2}" stroke-width=".45"/>` : "") +
        (latch ? `<path d="${latch}" stroke="${P.metal3}" stroke-width="1" stroke-linecap="round"/>` : "") +
        (lights ? `<path d="${lights}" stroke="${night ? P.lamp : P.light}" stroke-width="1.3" stroke-linecap="round"${night ? "" : ` opacity=".7"`}/>` : "");
    };

    /* ---------------- background: cabin shell ---------------- */
    let bg = `<rect width="160" height="100" fill="${P.wall2}"/>`;
    // ceiling, light strip (mood light at night)
    bg += `<path d="${strip(-.74, 2.08, .74, 2.08, ZN, ZF)}" fill="${P.wall}"/>` +
          `<path d="${strip(-.2, 2.1, .2, 2.1, ZN, ZF)}" fill="${night ? MOOD : P.light}" opacity="${night ? .32 : .9}"/>`;
    if (night) bg += `<path d="${strip(-.74, 2.08, .74, 2.08, ZN, ZF)}" fill="${MOOD}" opacity=".12"/>`;
    // side walls: upper (window belt) and lower panels
    bg += `<path d="${strip(-1.64, 1.62, -1.88, .62, ZN, ZF)}${strip(1.64, 1.62, 1.88, .62, ZN, ZF)}" fill="${P.wall}"/>` +
          `<path d="${strip(-1.88, .62, -1.78, 0, ZN, ZF)}${strip(1.88, .62, 1.78, 0, ZN, ZF)}" fill="${P.wall2}"/>`;
    // windows: bezel and glass (glass shows the sky of the palette)
    let bez = "", gl = "";
    for (const z of [1.2].concat(ROWS)) for (const X of [-1.87, 1.87]) {
      const zc = z + .4, k = F / zc;
      const cx = px(X, zc), cy = py(1.13, zc), rx = Math.abs(px(X, zc - .12) - px(X, zc + .12)) / 2, ry = .19 * k;
      if (cx < -6 || cx > 166) continue;
      bez += ell(cx, cy, rx + .05 * k * .5, ry + .05 * k);
      gl += ell(cx, cy, rx, ry);
    }
    bg += `<path d="${bez}" fill="${P.metal2}"/><path d="${gl}" fill="${h.skyFill(P)}"/>`;
    if (night) bg += `<path d="${strip(-1.86, 1.5, -1.86, .8, ZN, ZF)}${strip(1.86, 1.5, 1.86, .8, ZN, ZF)}" fill="${MOOD}" opacity=".07"/>`;
    // floor and aisle carpet with path lights
    bg += `<path d="${strip(-1.78, 0, 1.78, 0, ZN, ZF)}" fill="${P.metal3}"/>` +
          `<path d="${strip(-.27, 0, .27, 0, ZN, ZF)}" fill="${C2}"/>` +
          `<path d="M${pt(-.25, 0, ZN)}L${pt(-.25, 0, ZF)}M${pt(.25, 0, ZN)}L${pt(.25, 0, ZF)}" stroke="${night ? P.lamp : P.metal2}" stroke-width="${night ? .9 : .5}" opacity="${night ? .9 : .6}"/>`;
    // bulkhead at the front with a curtained galley opening
    bg += `<path d="${face(-1.8, 1.8, 0, 2.1, ZF)}" fill="${P.wall2}"/>` +
          `<path d="${face(-.32, .32, 0, 1.86, ZF)}" fill="${night ? MOOD : C2}" opacity="${night ? .55 : 1}"/>` +
          `<path d="${face(-.18, .18, 1.92, 2.02, ZF)}" fill="#2fd27a"/>`;

    /* ---------------- subject: overhead bins and seat rows ---------------- */
    // far = beyond the attendant, near = in front of her (each drawn back to front)
    let far = bins(SPLIT, ZF), near = bins(ZN, SPLIT);
    for (let i = ROWS.length - 1; i >= 0; i--) if (ROWS[i] >= SPLIT) far += row(ROWS[i]); else near += row(ROWS[i]);
    const s = (o.extra === true ? "" : far) + near;

    /* ---------------- extra: flight attendant behind a trolley ---------------- */
    const za = 3.2, ka = F / za, ax = px(0, za);
    const top = py(1.68, za), sh = py(1.42, za);
    let ex = `<g>${far}` +
      // body (uniform), arms, scarf, head, hair bun
      `<path d="M${f(ax - .2 * ka)} ${f(py(.9, za))}V${f(sh + .06 * ka)}Q${f(ax - .2 * ka)} ${f(sh)} ${f(ax - .12 * ka)} ${f(sh)}H${f(ax + .12 * ka)}Q${f(ax + .2 * ka)} ${f(sh)} ${f(ax + .2 * ka)} ${f(sh + .06 * ka)}V${f(py(.9, za))}Z" fill="${P.cloth3}"/>` +
      `<path d="M${f(ax - .05 * ka)} ${f(sh)}l${f(.05 * ka)} ${f(.1 * ka)} ${f(.05 * ka)} ${f(-.1 * ka)}z" fill="${P.light}"/>` +
      `<rect x="${f(ax - .045 * ka)}" y="${f(py(1.5, za))}" width="${f(.09 * ka)}" height="${f(.1 * ka)}" fill="${P.skin2}"/>` +
      `<ellipse cx="${f(ax)}" cy="${f(py(1.565, za))}" rx="${f(.085 * ka)}" ry="${f(.105 * ka)}" fill="${P.skin}"/>` +
      `<path d="M${f(ax - .09 * ka)} ${f(py(1.56, za))}C${f(ax - .1 * ka)} ${f(top - .01 * ka)} ${f(ax + .1 * ka)} ${f(top - .01 * ka)} ${f(ax + .09 * ka)} ${f(py(1.56, za))}C${f(ax + .04 * ka)} ${f(py(1.62, za))} ${f(ax - .04 * ka)} ${f(py(1.62, za))} ${f(ax - .09 * ka)} ${f(py(1.56, za))}Z" fill="${P.hair}"/>` +
      `<circle cx="${f(ax + .07 * ka)}" cy="${f(top + .02 * ka)}" r="${f(.05 * ka)}" fill="${P.hair}"/>`;
    // trolley: top tray with cups, front face with drawer lines, wheels
    const z1 = 2.75, z2 = 3.15, k1 = F / z1;
    ex += `<path d="M${pt(-.16, 1, z1)}L${pt(-.16, 1, z2)}L${pt(.16, 1, z2)}L${pt(.16, 1, z1)}Z" fill="${P.metal2}"/>` +
      `<path d="${face(-.12, -.04, 1, 1.09, 2.9)}${face(0, .08, 1, 1.09, 3)}" fill="${P.light}"/>` +
      `<path d="M${f(ax - .19 * ka)} ${f(py(1.04, za))}l${f(.06 * ka)} ${f(-.1 * ka)}M${f(ax + .19 * ka)} ${f(py(1.04, za))}l${f(-.06 * ka)} ${f(-.1 * ka)}" stroke="${P.cloth3}" stroke-width="${f(.07 * ka)}" stroke-linecap="round"/>` +
      `<path d="${face(-.16, .16, .04, 1, z1)}" ${st(P.metal, .03 * k1)}/>` +
      `<path d="M${pt(-.13, .72, z1)}H${f(px(.13, z1))}M${pt(-.13, .44, z1)}H${f(px(.13, z1))}" stroke="${P.metal2}" stroke-width="${f(.02 * k1)}"/>` +
      `<path d="${face(-.16, .16, .88, .94, z1)}" fill="${P.cloth3}"/>` +
      `<path d="${face(-.06, .06, .76, .8, z1)}" fill="${P.metal3}"/>` +
      `<path d="${ell(px(-.11, z1), py(.02, z1), .03 * k1, .02 * k1)}${ell(px(.11, z1), py(.02, z1), .03 * k1, .02 * k1)}" fill="${P.ink}"/>` +
      `</g>`;

    return { bg, subject: `<g>${s}</g>`, extra: ex, face: { x: f(VX), y: VY + 2, r: 12 } };
  });
})();
